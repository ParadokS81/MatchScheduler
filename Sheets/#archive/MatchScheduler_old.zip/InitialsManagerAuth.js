/**
 * Schedule Manager - Initials Manager Auth (PHASE 2: AUTH-ONLY SIMPLIFIED + CELL PROTECTION)
 * 
 * @version 2.1.0 (2025-05-25) - PHASE 2 COMPLETE - CELL PROTECTION INTEGRATED
 * 
 * Description: Authentication-only initials management with cell protection bypass
 * PHASE 1: Removed dual-mode complexity, direct auth-only calls, maintained all superior functionality
 * PHASE 2: Integrated cell protection bypass flags for secure sidebar editing
 * BREAKING: No longer supports open/guest mode - Google auth required
 */

// ========== CORE AUTH-AWARE INITIALS FUNCTIONS (PHASE 2 ENHANCED) ==========

/**
 * Adds the authenticated user's initials to selected cells (NO PROMPTING!)
 * PHASE 2: Now includes cell protection bypass for secure editing
 * @return {Object} Result with success status and message
 */
function addMyInitialsAuth() {
  try {
    // Step 1: Ensure we're in auth mode
    if (!isAuthenticationRequired()) {
      return {success: false, message: "Authentication mode not active"};
    }
    
    // Step 2: Get authenticated user
    const user = requireAuthentication(false);
    if (!user) {
      return {success: false, message: "Please log into your Google account to mark availability"};
    }
    
    // Step 3: Get user's claimed player info
    const playerInfo = getCurrentUserPlayerInfo();
    if (!playerInfo) {
      return {
        success: false, 
        message: "You haven't claimed a player slot yet. Please claim a slot first via the sidebar."
      };
    }
    
    const userInitials = playerInfo.initials;
    Logger.log(`Auth: Adding initials "${userInitials}" for user ${user.email}`);
    
    // Step 4: Get selected cells
    const sheet = SpreadsheetApp.getActiveSpreadsheet().getActiveSheet();
    const selection = sheet.getSelection();
    
    if (!selection) {
      return {success: false, message: "Please select cells in the schedule grid first"};
    }
    
    const ranges = selection.getActiveRangeList().getRanges();
    if (!ranges || ranges.length === 0) {
      return {success: false, message: "Please select cells in the schedule grid first"};
    }
    
    // Step 5: Process each selected range with PHASE 2 native protection bypass
    let cellsModified = 0;
    let invalidCells = 0;
    
    // PHASE 2: Use native protection bypass instead of flags
    const result = withProtectionBypass(() => {
      for (let i = 0; i < ranges.length; i++) {
        const range = ranges[i];
        const values = range.getValues();
        const startRow = range.getRow();
        const startCol = range.getColumn();
        
        // Process each cell in the range
        for (let r = 0; r < values.length; r++) {
          for (let c = 0; c < values[0].length; c++) {
            const cellRow = startRow + r;
            const cellCol = startCol + c;
            
            // Validate cell is in a valid grid area
            if (!isInValidBlockGrid(cellRow, cellCol)) {
              invalidCells++;
              continue;
            }
            
            const value = values[r][c];
            const text = String(value);
            
            // Skip header cells or time cells
            if (isHeaderOrTimeCell(text)) {
              invalidCells++;
              continue;
            }
            
            // Process the cell - add initials if not already present
            const entries = text ? text.toUpperCase().split(/[,\s]+/).filter(e => e.trim()) : [];
            
            if (!entries.includes(userInitials)) {
              entries.push(userInitials);
              values[r][c] = entries.join(", ");
              cellsModified++;
            }
          }
        }
        
        // Update this range with modified values
        range.setValues(values);
      }
      
      return { cellsModified, invalidCells };
    }, "Add User Initials");
    
    // Extract results from bypass operation
    cellsModified = result.cellsModified;
    invalidCells = result.invalidCells;
    
    // Step 6: Apply colors if any changes were made
    if (cellsModified > 0) {
      Logger.log(`Auth: Modified ${cellsModified} cells, applying colors...`);
      
      // Apply colors to all blocks
      if (!applyColorToAllBlocks()) {
        // If global coloring fails, try to apply colors just to the modified ranges
        for (const range of ranges) {
          applyColorsToSelectedRange(range);
        }
      }
      
      // Set up smart batch timers for automatic sharing
      try {
        setupSmartBatchTimers();
        Logger.log("Auth: Batch timers set up after adding initials");
      } catch (e) {
        Logger.log(`Auth: Could not set up batch timers: ${e.message}`);
        // Don't fail the operation if timer setup fails
      }
    }
    
    // Step 7: Return results with smart messaging
    let message = "";
    if (cellsModified > 0) {
      message = `✅ Added your availability (${userInitials}) to ${cellsModified} cell${cellsModified > 1 ? 's' : ''}`;
      
      if (invalidCells > 0) {
        message += `. ${invalidCells} cell${invalidCells > 1 ? 's' : ''} skipped (not in schedule grid)`;
      }
    } else if (invalidCells > 0) {
      message = "No changes made. Selected cells are outside the schedule grid";
    } else {
      message = "No changes made. Your initials are already present in selected cells";
    }
    
    return {
      success: cellsModified > 0,
      message: message,
      cellsModified: cellsModified,
      userInitials: userInitials
    };
    
  } catch (e) {
    Logger.log(`Auth: Error adding initials: ${e.message}`);
    return {success: false, message: "System error: " + e.message};
  }
}

/**
 * Removes the authenticated user's initials from selected cells (NO PROMPTING!)
 * PHASE 2: Now includes cell protection bypass for secure editing
 * @return {Object} Result with success status and message
 */
function removeMyInitialsAuth() {
  try {
    // Step 1: Ensure we're in auth mode
    if (!isAuthenticationRequired()) {
      return {success: false, message: "Authentication mode not active"};
    }
    
    // Step 2: Get authenticated user
    const user = requireAuthentication(false);
    if (!user) {
      return {success: false, message: "Please log into your Google account to modify availability"};
    }
    
    // Step 3: Get user's claimed player info
    const playerInfo = getCurrentUserPlayerInfo();
    if (!playerInfo) {
      return {
        success: false, 
        message: "You haven't claimed a player slot yet. Please claim a slot first via the sidebar."
      };
    }
    
    const userInitials = playerInfo.initials;
    Logger.log(`Auth: Removing initials "${userInitials}" for user ${user.email}`);
    
    // Step 4: Get selected cells
    const sheet = SpreadsheetApp.getActiveSpreadsheet().getActiveSheet();
    const selection = sheet.getSelection();
    
    if (!selection) {
      return {success: false, message: "Please select cells in the schedule grid first"};
    }
    
    const ranges = selection.getActiveRangeList().getRanges();
    if (!ranges || ranges.length === 0) {
      return {success: false, message: "Please select cells in the schedule grid first"};
    }
    
    // Step 5: Process each selected range with PHASE 2 native protection bypass
    let cellsModified = 0;
    let invalidCells = 0;
    
    // PHASE 2: Use native protection bypass instead of flags
    const result = withProtectionBypass(() => {
      for (let i = 0; i < ranges.length; i++) {
        const range = ranges[i];
        const values = range.getValues();
        const startRow = range.getRow();
        const startCol = range.getColumn();
        
        // Process each cell in the range
        for (let r = 0; r < values.length; r++) {
          for (let c = 0; c < values[0].length; c++) {
            const cellRow = startRow + r;
            const cellCol = startCol + c;
            
            // Validate cell is in a valid grid area
            if (!isInValidBlockGrid(cellRow, cellCol)) {
              invalidCells++;
              continue;
            }
            
            const value = values[r][c];
            const text = String(value);
            
            // Skip header cells or time cells
            if (isHeaderOrTimeCell(text)) {
              invalidCells++;
              continue;
            }
            
            // Process the cell - remove initials if present
            const entries = text ? text.toUpperCase().split(/[,\s]+/).filter(e => e.trim()) : [];
            const newEntries = entries.filter(e => e !== userInitials);
            
            if (entries.length !== newEntries.length) {
              values[r][c] = newEntries.join(", ");
              cellsModified++;
            }
          }
        }
        
        // Update this range with modified values
        range.setValues(values);
      }
      
      return { cellsModified, invalidCells };
    }, "Remove User Initials");
    
    // Extract results from bypass operation
    cellsModified = result.cellsModified;
    invalidCells = result.invalidCells;
    
    // Step 6: Apply colors if any changes were made
    if (cellsModified > 0) {
      Logger.log(`Auth: Modified ${cellsModified} cells, applying colors...`);
      
      // Apply colors to all blocks
      if (!applyColorToAllBlocks()) {
        // If global coloring fails, try to apply colors just to the modified ranges
        for (const range of ranges) {
          applyColorsToSelectedRange(range);
        }
      }
      
      // Set up smart batch timers for automatic sharing
      try {
        setupSmartBatchTimers();
        Logger.log("Auth: Batch timers set up after removing initials");
      } catch (e) {
        Logger.log(`Auth: Could not set up batch timers: ${e.message}`);
        // Don't fail the operation if timer setup fails
      }
    }
    
    // Step 7: Return results with smart messaging
    let message = "";
    if (cellsModified > 0) {
      message = `✅ Removed your availability (${userInitials}) from ${cellsModified} cell${cellsModified > 1 ? 's' : ''}`;
      
      if (invalidCells > 0) {
        message += `. ${invalidCells} cell${invalidCells > 1 ? 's' : ''} skipped (not in schedule grid)`;
      }
    } else if (invalidCells > 0) {
      message = "No changes made. Selected cells are outside the schedule grid";
    } else {
      message = "No changes made. Your initials are not present in selected cells";
    }
    
    return {
      success: cellsModified > 0,
      message: message,
      cellsModified: cellsModified,
      userInitials: userInitials
    };
    
  } catch (e) {
    Logger.log(`Auth: Error removing initials: ${e.message}`);
    return {success: false, message: "System error: " + e.message};
  }
}

// ========== HELPER FUNCTIONS (UNCHANGED) ==========

/**
 * Gets the current authenticated user's initials automatically
 * @return {string|null} User's initials or null if not claimed
 */
function getCurrentUserInitialsAuth() {
  try {
    const playerInfo = getCurrentUserPlayerInfo();
    return playerInfo ? playerInfo.initials : null;
  } catch (e) {
    Logger.log(`Auth: Error getting current user initials: ${e.message}`);
    return null;
  }
}

/**
 * Validates that a user can edit a specific cell (future feature)
 * @param {number} row - Cell row
 * @param {number} col - Cell column  
 * @param {string} userEmail - User email
 * @return {Object} Validation result
 */
function validateCellEditPermission(row, col, userEmail) {
  try {
    // For now, allow all authenticated users to edit any valid grid cell
    // Future: Could implement team-specific restrictions
    
    if (!isInValidBlockGrid(row, col)) {
      return {
        canEdit: false,
        reason: "Cell is outside schedule grid area"
      };
    }
    
    const user = getCurrentAuthenticatedUser();
    if (!user || user.email !== userEmail) {
      return {
        canEdit: false,
        reason: "User authentication mismatch"
      };
    }
    
    return {
      canEdit: true,
      reason: "Permission granted"
    };
    
  } catch (e) {
    Logger.log(`Auth: Error validating cell edit permission: ${e.message}`);
    return {
      canEdit: false,
      reason: "Validation error: " + e.message
    };
  }
}

/**
 * Provides user feedback for auth-based actions
 * @param {Object} result - Result from add/remove operations
 * @param {boolean} showAlert - Whether to show UI alert
 */
function showUserFeedbackAuth(result, showAlert = false) {
  try {
    // Log the result
    Logger.log(`Auth: Operation result - Success: ${result.success}, Message: ${result.message}`);
    
    // Show UI alert if requested
    if (showAlert && result.message) {
      const ui = SpreadsheetApp.getUi();
      const icon = result.success ? "✅" : "❌";
      ui.alert(`${icon} ${result.message}`);
    }
    
  } catch (e) {
    Logger.log(`Auth: Error showing user feedback: ${e.message}`);
  }
}

// ========== PHASE 2: SIMPLIFIED AUTH-ONLY ROUTING FUNCTIONS ==========

/**
 * PHASE 2 SIMPLIFIED: Add initials function for menu/UI calls
 * Now calls auth system directly - no more dual-mode routing
 * @return {boolean} Success indicator for backward compatibility
 */
function addMyInitials() {
  try {
    const result = addMyInitialsAuth();
    
    // Show UI feedback for menu calls
    if (result.message) {
      try {
        SpreadsheetApp.getUi().alert('Add Availability', result.message, SpreadsheetApp.getUi().ButtonSet.OK);
      } catch (e) {
        Logger.log(`UI feedback: ${result.message}`);
      }
    }
    
    return result.success || false;
    
  } catch (e) {
    Logger.log(`Error in addMyInitials: ${e.message}`);
    SpreadsheetApp.getUi().alert('Error adding initials: ' + e.message);
    return false;
  }
}

/**
 * PHASE 2 SIMPLIFIED: Remove initials function for menu/UI calls  
 * Now calls auth system directly - no more dual-mode routing
 * @return {boolean} Success indicator for backward compatibility
 */
function removeMyInitials() {
  try {
    const result = removeMyInitialsAuth();
    
    // Show UI feedback for menu calls
    if (result.message) {
      try {
        SpreadsheetApp.getUi().alert('Remove Availability', result.message, SpreadsheetApp.getUi().ButtonSet.OK);
      } catch (e) {
        Logger.log(`UI feedback: ${result.message}`);
      }
    }
    
    return result.success || false;
    
  } catch (e) {
    Logger.log(`Error in removeMyInitials: ${e.message}`);
    SpreadsheetApp.getUi().alert('Error removing initials: ' + e.message);
    return false;
  }
}

// ========== DEBUG FUNCTIONS (UNCHANGED) ==========

/**
 * Debug function to test auth initials system
 */
function debugAuthInitialsSystem() {
  const ui = SpreadsheetApp.getUi();
  
  try {
    const user = getCurrentAuthenticatedUser();
    const playerInfo = getCurrentUserPlayerInfo();
    const accessMode = getAccessMode();
    
    let message = `🎯 AUTH INITIALS SYSTEM DEBUG:\n\n`;
    message += `Access Mode: ${accessMode}\n`;
    message += `User: ${user ? user.email : 'Not authenticated'}\n`;
    message += `Player Info: ${playerInfo ? `${playerInfo.name} (${playerInfo.initials})` : 'Not claimed'}\n\n`;
    
    if (playerInfo) {
      message += `READY FOR USE:\n`;
      message += `✅ User authenticated\n`;
      message += `✅ Player slot claimed\n`;
      message += `✅ Initials available: ${playerInfo.initials}\n\n`;
      message += `Select cells and click "Add Me" - no prompting needed!`;
    } else if (user) {
      message += `SETUP NEEDED:\n`;
      message += `✅ User authenticated\n`;
      message += `❌ No player slot claimed\n\n`;
      message += `Please claim a player slot via the sidebar first.`;
    } else {
      message += `AUTHENTICATION NEEDED:\n`;
      message += `❌ User not authenticated\n\n`;
      message += `Please log into your Google account.`;
    }
    
    ui.alert("Auth Initials Debug", message, ui.ButtonSet.OK);
    
  } catch (e) {
    ui.alert("Debug error: " + e.message);
  }
}

/**
 * Test function for auth initials - add to selected cells
 */
function testAddInitialsAuth() {
  try {
    const result = addMyInitialsAuth();
    
    const ui = SpreadsheetApp.getUi();
    const icon = result.success ? "✅" : "❌";
    ui.alert(`${icon} Test Result`, result.message, ui.ButtonSet.OK);
    
    return result;
  } catch (e) {
    SpreadsheetApp.getUi().alert("Test error: " + e.message);
    return {success: false, message: "Test failed: " + e.message};
  }
}

/**
 * Test function for auth initials - remove from selected cells
 */
function testRemoveInitialsAuth() {
  try {
    const result = removeMyInitialsAuth();
    
    const ui = SpreadsheetApp.getUi();
    const icon = result.success ? "✅" : "❌";
    ui.alert(`${icon} Test Result`, result.message, ui.ButtonSet.OK);
    
    return result;
  } catch (e) {
    SpreadsheetApp.getUi().alert("Test error: " + e.message);
    return {success: false, message: "Test failed: " + e.message};
  }
}

// ========== PHASE 2 TEST FUNCTION ==========

/**
 * PHASE 2: Test function to verify simplified routing works correctly
 */
function testPhase2Routing() {
  try {
    console.log("=== PHASE 2 ROUTING TEST ===");
    
    // Test simplified routing
    console.log("Testing addMyInitials()...");
    const addResult = addMyInitials();
    console.log("Add Result:", addResult);
    
    console.log("Testing removeMyInitials()...");
    const removeResult = removeMyInitials();
    console.log("Remove Result:", removeResult);
    
    console.log("=== PHASE 2 TESTS COMPLETE ===");
    
    // Show results in UI for admin
    const ui = SpreadsheetApp.getUi();
    ui.alert(
      'Phase 2 Test Results',
      `Add Result: ${addResult}\nRemove Result: ${removeResult}\n\nCheck console logs for details.`,
      ui.ButtonSet.OK
    );
    
  } catch (e) {
    console.error("Phase 2 Test Error:", e.message);
    SpreadsheetApp.getUi().alert("Phase 2 Test Error: " + e.message);
  }
}

// ========== DEPRECATED FUNCTIONS REMOVED IN PHASE 2 ==========
// The following functions were removed to eliminate dual-mode complexity:
// - addMyInitialsModeAware() [~30 lines] - Replaced by addMyInitials()
// - removeMyInitialsModeAware() [~30 lines] - Replaced by removeMyInitials()
// Total reduction: ~60 lines of dual-mode routing code