/**
 * Schedule Manager - Configuration
 * 
 * @version 1.1.2 (2025-05-22) - 2x5 ROSTER LAYOUT + SPACE OPTIMIZATION
 * 
 * Description: System-wide configuration settings - Updated for 2x5 roster layout (10 players)
 * UPDATED: MAX_PLAYERS increased to 10, added 2x5 layout constants + space optimization
 * OPTIMIZED: Removed buffer columns for efficient screen space usage (A-T total width)
 */

// Global configuration - accessible to all modules
const BLOCK_CONFIG = {
  // Time settings
  TIME: {
    DEFAULT_START: "18:00",
    DEFAULT_END: "23:00",
    INTERVAL_MINUTES: 30,
    TIMEZONE: "CET",
    STANDARD_SLOTS: [
      "18:00", "18:30", "19:00", "19:30", "20:00", 
      "20:30", "21:00", "21:30", "22:00", "22:30", "23:00"
    ]
  },
  
  // Visual settings
  COLORS: {
    MONTH_HEADER: "#F2F2F2",         // Light grey for month headers
    WEEK_HEADER: "#F2F2F2",          // Light grey for week headers
    DAY_HEADER: "#F9F9F9",           // Light grey for day headers
    TIME_COLUMN: "#EEEEEE",          // Grey for time column
    WEEKEND: "#F0F7FF",              // Light blue for weekend cells
    WEEKDAY: "#FFFFFF",              // White for weekday cells
    ONE_PLAYER: "#FFCCCC",           // Red for 1 player
    TWO_TO_THREE: "#FFFF99",         // Yellow for 2-3 players
    FOUR_PLUS: "#CCFFCC",            // Green for 4+ players
    TEAM_HEADER: "#E6E6E6",          // Dark grey for team headers
    TEAM_NAME: "#b6d7a8",            // Light green for team name (B3)
    PLAYER_INITIALS: "#cfe2f3",      // Light blue for player initials (A4-A8, C4-C8)
    PLAYER_NAMES: "#fff2cc"          // Light yellow for player names (B4-B8, D4-D8)
  },
  
  // Block layout settings - UPDATED for 2x5 roster
  LAYOUT: {
    TEAM_SPACING: 15,                // Rows between team blocks
    TEAM_ROW_START: 3,               // First team starts at row 3
    BLOCK_WIDTH: 7,                  // 7 days per week
    LEFT_RIGHT_GAP: 1,               // Columns between left and right week
    WEEK_PAIR_WIDTH: 16,             // Total width of a week pair (left+right)
    TEAM_NAME_COL: 2,                // Column for team names
    MAX_PLAYERS: 10,                 // UPDATED: Maximum number of players per team (2x5 layout)
    DAYS: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
    
    // NEW: 2x5 Roster Layout Constants
    ROSTER: {
      COLUMNS: 4,                    // A, B, C, D for roster
      ROWS: 5,                       // 5 rows of players (4-8)
      SLOTS_PER_COLUMN: 5,           // 5 slots per column
      LEFT_INITIALS_COL: 1,          // Column A
      LEFT_NAMES_COL: 2,             // Column B  
      RIGHT_INITIALS_COL: 3,         // Column C
      RIGHT_NAMES_COL: 4,            // Column D
      LOGO_START_ROW: 9,             // Logo starts at row 9 (A9)
      LOGO_WIDTH: 4,                 // Logo spans A9:D15 (4 columns)
      LOGO_HEIGHT: 7                 // Logo spans 7 rows (9-15)
    },
    
    // NEW: Column Width Standards
    COLUMN_WIDTHS: {
      INITIALS: 50,                  // A, C columns (2 character initials)
      NAMES: 100,                    // B, D columns (12 character max names)
      TIME: 60,                      // Time columns
      SCHEDULE_DAY: 95               // Schedule grid days
    }
  },
  
  // Hub configuration
  HUB: {
    SPREADSHEET_ID: "1j7DTZ87aijQcr5SkvcNWIqOYVlZTw9XYoq8nutTn1bE", // Verify this ID is correct
    MASTERLIST_SHEET: "Masterlist",
    DATA_SHEET: "TeamData",
    
    // Column indices for Masterlist (0-based)
    COLUMNS: {
      TEAM_NAME: 0,        // Column A
      SHEET_URL: 1,        // Column B
      SHEET_ID: 2,         // Column C
      DIVISION: 3,         // Column D
      LAST_UPDATED: 4,     // Column E
      PLAYER_LIST: 5,      // Column F
      SHARING_STATUS: 6,   // Column G
      WEEKS_AVAILABLE: 7,  // Column H
      LOGO_URL: 8          // Column I - ADDED for logo support
    }
  }
};

/**
 * NEW: Gets slot position for 2x5 roster layout
 * @param {Number} slotNumber - Slot number (1-10)
 * @return {Object} Position information with row and column details
 */
function getSlotPosition(slotNumber) {
  if (slotNumber < 1 || slotNumber > 10) {
    throw new Error(`Invalid slot number: ${slotNumber}. Must be 1-10.`);
  }
  
  const layout = BLOCK_CONFIG.LAYOUT.ROSTER;
  const isRightColumn = slotNumber > 5;
  const rowIndex = isRightColumn ? slotNumber - 5 : slotNumber;
  
  return {
    slotNumber: slotNumber,
    row: 3 + rowIndex,                                    // Rows 4-8
    initialsCol: isRightColumn ? layout.RIGHT_INITIALS_COL : layout.LEFT_INITIALS_COL,   // A or C  
    nameCol: isRightColumn ? layout.RIGHT_NAMES_COL : layout.LEFT_NAMES_COL,             // B or D
    isRightColumn: isRightColumn,
    columnPair: isRightColumn ? "right" : "left",
    displayName: `Slot ${slotNumber} (${isRightColumn ? 'Right' : 'Left'} ${rowIndex})`
  };
}

/**
 * Gets all slot positions for the 2x5 layout
 * @return {Object[]} Array of all 10 slot positions
 */
function getAllSlotPositions() {
  const positions = [];
  for (let i = 1; i <= BLOCK_CONFIG.LAYOUT.MAX_PLAYERS; i++) {
    positions.push(getSlotPosition(i));
  }
  return positions;
}

/**
 * UPDATED: Gets the standard position for a team block (adjusted for 2x5 roster)
 * @param {Number} teamIndex - 0-based team index
 * @param {Boolean} isRightWeek - Whether this is the right week block
 * @return {Object} Position information
 */
function getStandardBlockPosition(teamIndex, isRightWeek) {
  const layout = BLOCK_CONFIG.LAYOUT;
  const teamRowStart = layout.TEAM_ROW_START + (teamIndex * layout.TEAM_SPACING);
  
  // LAYOUT: Roster(A-D) + Time(E) + Week(F-L) || Time(M) + Week(N-T) - NO BUFFER COLUMNS
  const leftTimeCol = 5;   // Column E
  const leftStartCol = 6;  // Column F  
  const rightTimeCol = 13; // Column M
  const rightStartCol = 14; // Column N
  
  const timeCol = isRightWeek ? rightTimeCol : leftTimeCol;
  const startCol = isRightWeek ? rightStartCol : leftStartCol;
  
  return {
    row: teamRowStart,
    col: startCol,
    timeCol: timeCol,
    teamNameCol: layout.TEAM_NAME_COL,
    teamNameRow: teamRowStart
  };
}

/**
 * DEBUG FUNCTION: Validates that BLOCK_CONFIG is properly defined
 * @return {Object} Configuration status
 */
function debugConfigurationStatus() {
  try {
    Logger.log("=== DEBUG CONFIGURATION STATUS (v1.1.0) ===");
    
    const results = {
      mainConfig: false,
      timeConfig: false,
      layoutConfig: false,
      rosterConfig: false,
      hubConfig: false,
      logoSupport: false,
      maxPlayers: null,
      slotPositions: false,
      error: null
    };
    
    // Check main BLOCK_CONFIG
    if (typeof BLOCK_CONFIG === 'undefined') {
      results.error = "BLOCK_CONFIG is undefined";
      Logger.log("CRITICAL ERROR: BLOCK_CONFIG is undefined!");
      return results;
    }
    results.mainConfig = true;
    Logger.log("✓ BLOCK_CONFIG exists");
    
    // Check TIME config
    if (BLOCK_CONFIG.TIME && BLOCK_CONFIG.TIME.STANDARD_SLOTS) {
      results.timeConfig = true;
      Logger.log("✓ TIME config exists with " + BLOCK_CONFIG.TIME.STANDARD_SLOTS.length + " slots");
    } else {
      Logger.log("✗ TIME config missing or incomplete");
    }
    
    // Check LAYOUT config
    if (BLOCK_CONFIG.LAYOUT) {
      results.layoutConfig = true;
      results.maxPlayers = BLOCK_CONFIG.LAYOUT.MAX_PLAYERS;
      Logger.log("✓ LAYOUT config exists");
      Logger.log("  - MAX_PLAYERS: " + BLOCK_CONFIG.LAYOUT.MAX_PLAYERS);
      Logger.log("  - TEAM_SPACING: " + BLOCK_CONFIG.LAYOUT.TEAM_SPACING);
      Logger.log("  - TEAM_ROW_START: " + BLOCK_CONFIG.LAYOUT.TEAM_ROW_START);
    } else {
      Logger.log("✗ LAYOUT config missing");
    }
    
    // Check NEW ROSTER config
    if (BLOCK_CONFIG.LAYOUT.ROSTER) {
      results.rosterConfig = true;
      Logger.log("✓ ROSTER config exists");
      Logger.log("  - COLUMNS: " + BLOCK_CONFIG.LAYOUT.ROSTER.COLUMNS);
      Logger.log("  - SLOTS_PER_COLUMN: " + BLOCK_CONFIG.LAYOUT.ROSTER.SLOTS_PER_COLUMN);
      Logger.log("  - LOGO_WIDTH: " + BLOCK_CONFIG.LAYOUT.ROSTER.LOGO_WIDTH);
    } else {
      Logger.log("✗ ROSTER config missing");
    }
    
    // Check slot position functions
    try {
      const testPosition = getSlotPosition(1);
      const allPositions = getAllSlotPositions();
      results.slotPositions = (allPositions.length === 10);
      Logger.log("✓ Slot position functions working (" + allPositions.length + " positions)");
    } catch (e) {
      Logger.log("✗ Slot position functions error: " + e.message);
    }
    
    // Check HUB config
    if (BLOCK_CONFIG.HUB && BLOCK_CONFIG.HUB.SPREADSHEET_ID) {
      results.hubConfig = true;
      Logger.log("✓ HUB config exists");
      Logger.log("  - SPREADSHEET_ID: " + BLOCK_CONFIG.HUB.SPREADSHEET_ID);
      
      // Check LOGO_URL column definition
      if (BLOCK_CONFIG.HUB.COLUMNS && typeof BLOCK_CONFIG.HUB.COLUMNS.LOGO_URL !== 'undefined') {
        results.logoSupport = true;
        Logger.log("✓ LOGO_URL column defined (Column " + String.fromCharCode(65 + BLOCK_CONFIG.HUB.COLUMNS.LOGO_URL) + ")");
      } else {
        Logger.log("✗ LOGO_URL column definition missing");
      }
    } else {
      Logger.log("✗ HUB config missing or incomplete");
    }
    
    Logger.log("=== CONFIGURATION STATUS COMPLETE (v1.1.0) ===");
    return results;
    
  } catch (e) {
    Logger.log("=== CONFIGURATION DEBUG ERROR: " + e.message + " ===");
    return { error: e.message };
  }
}

/**
 * Gets today's date as of midnight
 * @return {Date} Today at midnight
 */
function getTodayAtMidnight() {
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  return today;
}

/**
 * Gets Monday of the current week
 * @return {Date} Monday at midnight
 */
function getCurrentMonday() {
  const today = getTodayAtMidnight();
  const day = today.getDay(); // 0 = Sunday, 1 = Monday, etc.
  const diff = day === 0 ? 6 : day - 1; // Adjust for Sunday
  
  const monday = new Date(today);
  monday.setDate(today.getDate() - diff);
  return monday;
}

/**
 * Gets Monday of the next week
 * @return {Date} Next Monday at midnight
 */
function getNextMonday() {
  const monday = getCurrentMonday();
  monday.setDate(monday.getDate() + 7);
  return monday;
}

/**
 * Gets the ISO week number for a date
 * @param {Date} date - The date to check
 * @return {Number} Week number (1-53)
 */
function getISOWeekNumber(date) {
  const d = new Date(date.getTime());
  d.setHours(0, 0, 0, 0);
  d.setDate(d.getDate() + 4 - (d.getDay() || 7));
  const yearStart = new Date(d.getFullYear(), 0, 1);
  const weekNo = Math.ceil((((d - yearStart) / 86400000) + 1) / 7);
  return weekNo;
}

/**
 * Gets the ordinal suffix for a number
 * @param {Number} n - The number
 * @return {String} Ordinal suffix (st, nd, rd, th)
 */
function getOrdinalSuffix(n) {
  if (n > 3 && n < 21) return "th";
  switch (n % 10) {
    case 1: return "st";
    case 2: return "nd";
    case 3: return "rd";
    default: return "th";
  }
}