/**
 * Schedule Manager - Slot Manager (PHASE 2: NATIVE PROTECTION INTEGRATED)
 * 
 * @version 1.1.0 (2025-05-25) - PHASE 2 COMPLETE - NATIVE PROTECTION BYPASS
 * 
 * Description: Core slot adoption and management system with native protection bypass
 * PHASE 2: All display functions use native protection bypass for secure operations
 * ARCHITECTURE: Replaces fixed roster with dynamic slot adoption system
 */

/**
 * Adopts a player slot for the current user
 * @param {number} slotNumber - Slot number (1-10) to adopt
 * @param {string} playerName - Player display name
 * @param {string} initials - Player initials (2 characters)
 * @return {boolean} Success indicator
 */
function adoptPlayerSlot(slotNumber, playerName, initials) {
  try {
    Logger.log(`SlotManager: Adopting slot ${slotNumber} for player ${playerName} (${initials})`);
    
    // Validate inputs
    if (!slotNumber || slotNumber < 1 || slotNumber > BLOCK_CONFIG.LAYOUT.MAX_PLAYERS) {
      throw new Error(`Invalid slot number: ${slotNumber}. Must be 1-${BLOCK_CONFIG.LAYOUT.MAX_PLAYERS}`);
    }
    
    if (!playerName || String(playerName).trim().length === 0) {
      throw new Error("Player name is required");
    }
    
    if (!initials || String(initials).trim().length !== 2) {
      throw new Error("Initials must be exactly 2 characters");
    }
    
    // Get current user
    const userEmail = getCurrentUserEmail();
    if (!userEmail) {
      throw new Error("Unable to identify current user");
    }
    
    // Check if slot is available
    if (!isSlotAvailable(slotNumber)) {
      throw new Error(`Slot ${slotNumber} is already adopted`);
    }
    
    // Check if user already has a slot
    const existingSlot = getUserAdoptedSlot(userEmail);
    if (existingSlot) {
      throw new Error(`You have already adopted slot ${existingSlot.slotNumber}. Release it first.`);
    }
    
    // Get current slot data
    const slotData = getSlotData();
    
    // Create adoption entry
    const adoptionEntry = {
      slotNumber: slotNumber,
      adoptedBy: userEmail,
      playerName: String(playerName).trim(),
      initials: String(initials).trim().toUpperCase(),
      adoptedAt: new Date().toISOString(),
      status: "google_adopted"
    };
    
    // Add to slot data
    slotData.slots = slotData.slots || [];
    
    // Remove any existing entry for this slot
    slotData.slots = slotData.slots.filter(slot => slot.slotNumber !== slotNumber);
    
    // Add new adoption
    slotData.slots.push(adoptionEntry);
    
    // Save slot data
    saveSlotData(slotData);
    
    // Update spreadsheet display
    updateSlotDisplay(slotNumber, playerName, initials);
    
    Logger.log(`SlotManager: Successfully adopted slot ${slotNumber} for ${userEmail}`);
    return true;
    
  } catch (e) {
    Logger.log(`SlotManager: Error adopting slot ${slotNumber}: ${e.message}`);
    throw e;
  }
}

/**
 * Releases a player slot for the current user
 * @param {number} slotNumber - Slot number to release
 * @return {boolean} Success indicator
 */
function releasePlayerSlot(slotNumber) {
  try {
    Logger.log(`SlotManager: Releasing slot ${slotNumber}`);
    
    // Get current user
    const userEmail = getCurrentUserEmail();
    if (!userEmail) {
      throw new Error("Unable to identify current user");
    }
    
    // Get current slot data
    const slotData = getSlotData();
    
    // Find the slot
    const slotIndex = slotData.slots.findIndex(slot => 
      slot.slotNumber === slotNumber && slot.adoptedBy === userEmail
    );
    
    if (slotIndex === -1) {
      throw new Error(`You don't own slot ${slotNumber} or it doesn't exist`);
    }
    
    // Remove the slot
    slotData.slots.splice(slotIndex, 1);
    
    // Save updated data
    saveSlotData(slotData);
    
    // Clear spreadsheet display
    clearSlotDisplay(slotNumber);
    
    Logger.log(`SlotManager: Successfully released slot ${slotNumber} for ${userEmail}`);
    return true;
    
  } catch (e) {
    Logger.log(`SlotManager: Error releasing slot ${slotNumber}: ${e.message}`);
    throw e;
  }
}

/**
 * Updates player information for an adopted slot
 * @param {number} slotNumber - Slot number to update
 * @param {string} newName - New player name
 * @param {string} newInitials - New initials
 * @return {boolean} Success indicator
 */
function updatePlayerInfo(slotNumber, newName, newInitials) {
  try {
    Logger.log(`SlotManager: Updating slot ${slotNumber} info`);
    
    // Get current user
    const userEmail = getCurrentUserEmail();
    if (!userEmail) {
      throw new Error("Unable to identify current user");
    }
    
    // Validate inputs
    if (!newName || String(newName).trim().length === 0) {
      throw new Error("Player name is required");
    }
    
    if (!newInitials || String(newInitials).trim().length !== 2) {
      throw new Error("Initials must be exactly 2 characters");
    }
    
    // Get current slot data
    const slotData = getSlotData();
    
    // Find the slot
    const slot = slotData.slots.find(slot => 
      slot.slotNumber === slotNumber && slot.adoptedBy === userEmail
    );
    
    if (!slot) {
      throw new Error(`You don't own slot ${slotNumber} or it doesn't exist`);
    }
    
    // Update the slot info
    slot.playerName = String(newName).trim();
    slot.initials = String(newInitials).trim().toUpperCase();
    slot.lastUpdated = new Date().toISOString();
    
    // Save updated data
    saveSlotData(slotData);
    
    // Update spreadsheet display
    updateSlotDisplay(slotNumber, slot.playerName, slot.initials);
    
    Logger.log(`SlotManager: Successfully updated slot ${slotNumber} info`);
    return true;
    
  } catch (e) {
    Logger.log(`SlotManager: Error updating slot ${slotNumber}: ${e.message}`);
    throw e;
  }
}

/**
 * Gets list of adopted players for current team
 * @return {Object[]} Array of adopted player objects
 */
function getAdoptedPlayers() {
  try {
    const slotData = getSlotData();
    
    return (slotData.slots || [])
      .filter(slot => slot.status === "google_adopted")
      .sort((a, b) => a.slotNumber - b.slotNumber)
      .map(slot => ({
        slotNumber: slot.slotNumber,
        playerName: slot.playerName,
        initials: slot.initials,
        adoptedBy: slot.adoptedBy,
        adoptedAt: slot.adoptedAt
      }));
    
  } catch (e) {
    Logger.log(`SlotManager: Error getting adopted players: ${e.message}`);
    return [];
  }
}

/**
 * Gets the slot adopted by a specific user
 * @param {string} userEmail - User email to check
 * @return {Object|null} Slot object or null if not found
 */
function getUserAdoptedSlot(userEmail) {
  try {
    const slotData = getSlotData();
    
    return (slotData.slots || []).find(slot => 
      slot.adoptedBy === userEmail && slot.status === "google_adopted"
    ) || null;
    
  } catch (e) {
    Logger.log(`SlotManager: Error getting user slot for ${userEmail}: ${e.message}`);
    return null;
  }
}

/**
 * Checks if a slot is available for adoption
 * @param {number} slotNumber - Slot number to check
 * @return {boolean} True if available
 */
function isSlotAvailable(slotNumber) {
  try {
    const slotData = getSlotData();
    
    return !(slotData.slots || []).some(slot => 
      slot.slotNumber === slotNumber && slot.status === "google_adopted"
    );
    
  } catch (e) {
    Logger.log(`SlotManager: Error checking slot ${slotNumber} availability: ${e.message}`);
    return false;
  }
}

/**
 * Gets current user email (placeholder for Google auth)
 * @return {string|null} User email or null if not available
 */
function getCurrentUserEmail() {
  try {
    // For now, use Session.getActiveUser() - in future this would be enhanced
    // with proper Google OAuth integration
    const user = Session.getActiveUser();
    return user ? user.getEmail() : null;
  } catch (e) {
    Logger.log(`SlotManager: Error getting current user: ${e.message}`);
    return null;
  }
}

/**
 * Gets slot data from document properties
 * @return {Object} Slot data structure
 */
function getSlotData() {
  try {
    const documentProps = PropertiesService.getDocumentProperties();
    const slotDataJson = documentProps.getProperty('slotData');
    
    if (slotDataJson) {
      return JSON.parse(slotDataJson);
    }
    
    // Return empty structure if no data exists
    return {
      teamName: "",
      teamLeader: "",
      division: "",
      slots: [],
      lastUpdated: new Date().toISOString()
    };
    
  } catch (e) {
    Logger.log(`SlotManager: Error getting slot data: ${e.message}`);
    // Return safe default
    return {
      teamName: "",
      teamLeader: "",
      division: "",
      slots: [],
      lastUpdated: new Date().toISOString()
    };
  }
}

/**
 * Saves slot data to document properties
 * @param {Object} slotData - Slot data to save
 * @return {boolean} Success indicator
 */
function saveSlotData(slotData) {
  try {
    slotData.lastUpdated = new Date().toISOString();
    
    const documentProps = PropertiesService.getDocumentProperties();
    documentProps.setProperty('slotData', JSON.stringify(slotData));
    
    Logger.log("SlotManager: Slot data saved successfully");
    return true;
    
  } catch (e) {
    Logger.log(`SlotManager: Error saving slot data: ${e.message}`);
    return false;
  }
}

/**
 * Updates the spreadsheet display for a specific slot
 * PHASE 2: Uses native protection bypass for secure display updates
 * @param {number} slotNumber - Slot number to update
 * @param {string} playerName - Player name to display
 * @param {string} initials - Initials to display
 */
function updateSlotDisplay(slotNumber, playerName, initials) {
  try {
    // PHASE 2: Use native protection bypass for slot display updates
    withProtectionBypass(() => {
      const sheet = SpreadsheetApp.getActiveSpreadsheet().getActiveSheet();
      const position = getSlotPosition(slotNumber);
      
      // Set initials
      sheet.getRange(position.row, position.initialsCol)
           .setValue(initials)
           .setHorizontalAlignment("center")
           .setBackground(BLOCK_CONFIG.COLORS.PLAYER_INITIALS);
      
      // Set player name
      sheet.getRange(position.row, position.nameCol)
           .setValue(playerName)
           .setBackground(BLOCK_CONFIG.COLORS.PLAYER_NAMES);
    }, `Update Slot ${slotNumber} Display`);
    
    Logger.log(`SlotManager: Updated display for slot ${slotNumber}: ${playerName} (${initials})`);
    
  } catch (e) {
    Logger.log(`SlotManager: Error updating slot ${slotNumber} display: ${e.message}`);
  }
}

/**
 * Clears the spreadsheet display for a specific slot
 * PHASE 2: Uses native protection bypass for secure display updates
 * @param {number} slotNumber - Slot number to clear
 */
function clearSlotDisplay(slotNumber) {
  try {
    // PHASE 2: Use native protection bypass for slot display clearing
    withProtectionBypass(() => {
      const sheet = SpreadsheetApp.getActiveSpreadsheet().getActiveSheet();
      const position = getSlotPosition(slotNumber);
      
      // Clear initials but keep background color
      sheet.getRange(position.row, position.initialsCol)
           .setValue("")
           .setBackground(BLOCK_CONFIG.COLORS.PLAYER_INITIALS);
      
      // Clear player name but keep background color
      sheet.getRange(position.row, position.nameCol)
           .setValue("")
           .setBackground(BLOCK_CONFIG.COLORS.PLAYER_NAMES);
    }, `Clear Slot ${slotNumber} Display`);
    
    Logger.log(`SlotManager: Cleared display for slot ${slotNumber}`);
    
  } catch (e) {
    Logger.log(`SlotManager: Error clearing slot ${slotNumber} display: ${e.message}`);
  }
}

/**
 * Gets all available slot numbers
 * @return {number[]} Array of available slot numbers
 */
function getAvailableSlots() {
  const allSlots = [];
  for (let i = 1; i <= BLOCK_CONFIG.LAYOUT.MAX_PLAYERS; i++) {
    if (isSlotAvailable(i)) {
      allSlots.push(i);
    }
  }
  return allSlots;
}

/**
 * Gets slot ownership information for admin/debug purposes
 * @return {Object} Complete ownership information
 */
function getSlotOwnershipInfo() {
  try {
    const slotData = getSlotData();
    const adoptedSlots = slotData.slots || [];
    const availableSlots = getAvailableSlots();
    
    return {
      teamInfo: {
        teamName: slotData.teamName,
        teamLeader: slotData.teamLeader,
        division: slotData.division
      },
      adoptedSlots: adoptedSlots,
      availableSlots: availableSlots,
      totalSlots: BLOCK_CONFIG.LAYOUT.MAX_PLAYERS,
      lastUpdated: slotData.lastUpdated
    };
    
  } catch (e) {
    Logger.log(`SlotManager: Error getting ownership info: ${e.message}`);
    return {
      teamInfo: {},
      adoptedSlots: [],
      availableSlots: [],
      totalSlots: BLOCK_CONFIG.LAYOUT.MAX_PLAYERS,
      lastUpdated: null,
      error: e.message
    };
  }
}

/**
 * Debug function to test slot adoption process
 * @param {number} slotNumber - Slot to test
 * @param {string} testName - Test player name
 * @param {string} testInitials - Test initials
 */
function debugSlotAdoption(slotNumber = 1, testName = "Test Player", testInitials = "TP") {
  try {
    Logger.log("=== SLOT ADOPTION DEBUG TEST ===");
    
    const currentUser = getCurrentUserEmail();
    Logger.log(`Current user: ${currentUser}`);
    
    // Test availability check
    const isAvailable = isSlotAvailable(slotNumber);
    Logger.log(`Slot ${slotNumber} available: ${isAvailable}`);
    
    if (isAvailable) {
      // Test adoption
      Logger.log(`Adopting slot ${slotNumber}...`);
      const adoptResult = adoptPlayerSlot(slotNumber, testName, testInitials);
      Logger.log(`Adoption result: ${adoptResult}`);
      
      // Check adoption
      const userSlot = getUserAdoptedSlot(currentUser);
      Logger.log(`User adopted slot: ${JSON.stringify(userSlot)}`);
    }
    
    // Show ownership info
    const ownershipInfo = getSlotOwnershipInfo();
    Logger.log(`Ownership info: ${JSON.stringify(ownershipInfo, null, 2)}`);
    
    Logger.log("=== DEBUG TEST COMPLETE ===");
    
  } catch (e) {
    Logger.log(`Debug test error: ${e.message}`);
  }
}