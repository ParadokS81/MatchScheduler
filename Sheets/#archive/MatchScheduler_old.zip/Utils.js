/**
 * Schedule Manager - Shared Utilities
 * 
 * @version 1.0.0 (2025-05-22)
 * 
 * Description: Centralized utility functions to eliminate code duplication
 */

// ========== GRID VALIDATION UTILITIES ==========

/**
 * Checks if a cell is within any valid block grid (consolidated version)
 * @param {Number} row - 1-based row index
 * @param {Number} col - 1-based column index
 * @return {Boolean} Whether the cell is in a valid grid
 */
function isInValidBlockGrid(row, col) {
  // Quick boundary check for known grid areas
  const knownGrids = [
    // First team
    {minRow: 5, maxRow: 15, minCol: 4, maxCol: 10},   // D5:J15
    {minRow: 5, maxRow: 15, minCol: 12, maxCol: 18},  // L5:R15
    
    // Second team
    {minRow: 22, maxRow: 32, minCol: 4, maxCol: 10},  // D22:J32
    {minRow: 22, maxRow: 32, minCol: 12, maxCol: 18}, // L22:R32
    
    // Third team
    {minRow: 37, maxRow: 47, minCol: 4, maxCol: 10},  // D37:J47
    {minRow: 37, maxRow: 47, minCol: 12, maxCol: 18}, // L37:R47
    
    // Fourth team
    {minRow: 52, maxRow: 62, minCol: 4, maxCol: 10},  // D52:J62
    {minRow: 52, maxRow: 62, minCol: 12, maxCol: 18}, // L52:R62
    
    // Fifth team
    {minRow: 67, maxRow: 77, minCol: 4, maxCol: 10},  // D67:J77
    {minRow: 67, maxRow: 77, minCol: 12, maxCol: 18}  // L67:R77
  ];
  
  // Fast check against known grid positions
  for (const grid of knownGrids) {
    if (row >= grid.minRow && row <= grid.maxRow && 
        col >= grid.minCol && col <= grid.maxCol) {
      return true;
    }
  }
  
  // If not found in known grids, check against detected blocks
  try {
    const blocks = findAllBlocks();
    
    for (const block of blocks) {
      // Check if the cell is within this block's grid
      if (row >= block.timeStartRow && 
          row < block.timeStartRow + block.gridHeight &&
          col >= block.col && 
          col < block.col + block.gridWidth) {
        return true;
      }
    }
  } catch (e) {
    Logger.log(`Utils: Error in block detection fallback: ${e.message}`);
  }
  
  return false;
}

/**
 * Determines if a cell contains a header or time value
 * @param {String} text - Cell text to check
 * @return {Boolean} True if cell is a header or time
 */
function isHeaderOrTimeCell(text) {
  if (!text) return false;
  
  return text.match(/^week\s*\d+/i) || // Week headers
         text.match(/^(mon|tue|wed|thu|fri|sat|sun)/i) || // Day headers
         text.match(/^\d{1,2}:\d{2}$/) || // Time values
         text.match(/^(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)/i); // Month headers
}

/**
 * Determines if a cell is in a weekend column (Sat or Sun)
 * @param {Number} col - 1-based column index
 * @return {Boolean} Whether the cell is in a weekend column
 */
function isInWeekendColumn(col) {
  // Standard positions for weekend days
  const weekendColumns = [9, 10, 17, 18]; // Columns I, J, Q, R
  
  return weekendColumns.includes(col);
}

// ========== HTML/TEXT UTILITIES ==========

/**
 * Escapes HTML characters to prevent XSS (consolidated version)
 * @param {string} text - Text to escape
 * @return {string} Escaped text
 */
function escapeHtml(text) {
  if (!text) return '';
  return String(text)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

/**
 * Truncates text to specified length with ellipsis
 * @param {string} text - Text to truncate
 * @param {number} maxLength - Maximum length
 * @return {string} Truncated text
 */
function truncateText(text, maxLength) {
  if (!text || text.length <= maxLength) return text;
  return text.substring(0, maxLength - 3) + "...";
}

// ========== ERROR HANDLING UTILITIES ==========

/**
 * Standardized error handler for UI functions
 * @param {Error} error - Error object
 * @param {string} operation - Description of operation that failed
 * @param {boolean} showToUser - Whether to show alert to user
 */
function handleError(error, operation, showToUser = true) {
  const errorMessage = `Error in ${operation}: ${error.message}`;
  
  // Always log the error
  Logger.log(errorMessage);
  
  // Optionally show to user
  if (showToUser) {
    try {
      SpreadsheetApp.getUi().alert("Error", errorMessage, SpreadsheetApp.getUi().ButtonSet.OK);
    } catch (e) {
      // If UI alert fails, just log it
      Logger.log(`Could not show error to user: ${e.message}`);
    }
  }
  
  return false; // Standard failure return
}

/**
 * Safe function executor with error handling
 * @param {Function} func - Function to execute
 * @param {string} operation - Description for error messages
 * @param {boolean} showErrors - Whether to show errors to user
 * @return {*} Function result or null on error
 */
function safeExecute(func, operation, showErrors = false) {
  try {
    return func();
  } catch (error) {
    handleError(error, operation, showErrors);
    return null;
  }
}

// ========== DATA VALIDATION UTILITIES ==========

/**
 * Validates team data structure
 * @param {Object} teamData - Team data to validate
 * @return {Object} Validation result with isValid and errors
 */
function validateTeamData(teamData) {
  const errors = [];
  
  if (!teamData) {
    errors.push("Team data is null or undefined");
    return { isValid: false, errors };
  }
  
  if (!teamData.teamName || String(teamData.teamName).trim() === "") {
    errors.push("Team name is required");
  }
  
  if (!teamData.players || !Array.isArray(teamData.players) || teamData.players.length < 3) {
    errors.push("At least 3 players are required");
  }
  
  return {
    isValid: errors.length === 0,
    errors: errors
  };
}

/**
 * Validates week number is current or next week
 * @param {number} weekNumber - Week number to validate
 * @return {boolean} True if week is current or next week
 */
function isValidWeekForSharing(weekNumber) {
  try {
    const currentWeek = getCurrentWeekNumber();
    const nextWeek = currentWeek + 1;
    
    return weekNumber === currentWeek || weekNumber === nextWeek;
  } catch (e) {
    Logger.log(`Error validating week ${weekNumber}: ${e.message}`);
    return false;
  }
}

// ========== PERFORMANCE UTILITIES ==========

/**
 * Batches Google Sheets range operations
 * @param {Sheet} sheet - Sheet to operate on
 * @param {Array} operations - Array of {range, value} objects
 * @param {string} operation - "set" or "get"
 * @return {boolean} Success indicator
 */
function batchSheetOperations(sheet, operations, operation = "set") {
  try {
    if (operation === "set") {
      // Batch setValue operations
      for (const op of operations) {
        if (op.range && op.value !== undefined) {
          sheet.getRange(op.range).setValue(op.value);
        }
      }
    }
    // Add "get" operations if needed in the future
    
    return true;
  } catch (e) {
    Logger.log(`Error in batch operations: ${e.message}`);
    return false;
  }
}

// ========== DEBUG UTILITIES ==========

/**
 * Simple performance timer
 * @param {string} label - Label for the timer
 * @return {Function} Stop function that logs elapsed time
 */
function startTimer(label) {
  const startTime = new Date().getTime();
  
  return function stopTimer() {
    const endTime = new Date().getTime();
    const elapsed = endTime - startTime;
    Logger.log(`Timer [${label}]: ${elapsed}ms`);
    return elapsed;
  };
}

/**
 * Logs object structure for debugging
 * @param {*} obj - Object to analyze
 * @param {string} label - Label for the log
 */
function debugLogObject(obj, label = "Object") {
  try {
    Logger.log(`${label}: ${JSON.stringify(obj, null, 2)}`);
  } catch (e) {
    Logger.log(`${label}: [Cannot stringify - ${e.message}]`);
  }
}