/**
 * Schedule Manager - Smart Refresh System
 * 
 * @version 1.2.0 (2025-05-22)
 * 
 * Description: Handles smart refresh automation and team list refreshing with batch timer cancellation
 * NEW MODULE: Split from UIController.js for better organization  
 * UPDATED: Added smart batch timer system with cancellation capability
 * MAJOR: Added comprehensive timer monitoring and management functions
 */

/**
 * Sets the auto-refresh setting
 * @param {boolean} enabled - Whether auto-refresh is enabled
 */
function setAutoRefresh(enabled) {
  const userProps = PropertiesService.getUserProperties();
  userProps.setProperty('autoRefresh', enabled ? 'true' : 'false');
  
  // Set up or remove the trigger based on the setting
  if (enabled) {
    setupAutoRefreshTrigger();
  } else {
    removeAutoRefreshTrigger();
  }
  
  Logger.log(`Auto-refresh set to ${enabled}`);
}

/**
 * Gets the current auto-refresh setting
 * @return {boolean} - Whether auto-refresh is enabled
 */
function getAutoRefresh() {
  const userProps = PropertiesService.getUserProperties();
  const setting = userProps.getProperty('autoRefresh');
  return setting === 'true';
}

/**
 * Sets up the auto-refresh trigger
 */
function setupAutoRefreshTrigger() {
  // Remove any existing triggers first
  removeAutoRefreshTrigger();
  
  // Create a trigger that runs every 3 hours
  ScriptApp.newTrigger('autoRefreshTeams')
    .timeBased()
    .everyHours(3)
    .create();
    
  Logger.log('Auto-refresh trigger set up');
}

/**
 * Removes the auto-refresh trigger
 */
function removeAutoRefreshTrigger() {
  const triggers = ScriptApp.getProjectTriggers();
  
  for (const trigger of triggers) {
    if (trigger.getHandlerFunction() === 'autoRefreshTeams') {
      ScriptApp.deleteTrigger(trigger);
    }
  }
  
  Logger.log('Auto-refresh trigger removed');
}

/**
 * Auto-refreshes the teams data if within allowed hours
 */
function autoRefreshTeams() {
  // Only refresh between noon and midnight
  const now = new Date();
  const hour = now.getHours();
  
  if (hour >= 12 && hour < 24) {
    getAvailableTeams("yes");  // Use string instead of boolean
    Logger.log('Teams list auto-refreshed');
  } else {
    Logger.log('Outside auto-refresh hours, skipping');
  }
}

/**
 * DEBUG: Shows current auto-refresh status
 */
function debugAutoRefreshStatus() {
  const ui = SpreadsheetApp.getUi();
  
  try {
    const enabled = getAutoRefresh();
    const triggers = ScriptApp.getProjectTriggers();
    const autoRefreshTriggers = triggers.filter(t => t.getHandlerFunction() === 'autoRefreshTeams');
    
    let message = `Auto-Refresh Status:\n\n`;
    message += `Enabled: ${enabled}\n`;
    message += `Active triggers: ${autoRefreshTriggers.length}\n\n`;
    
    if (autoRefreshTriggers.length > 0) {
      message += `Trigger details:\n`;
      autoRefreshTriggers.forEach((trigger, index) => {
        message += `${index + 1}. Runs every 3 hours (12PM-12AM)\n`;
      });
    } else if (enabled) {
      message += `WARNING: Auto-refresh is enabled but no triggers found!`;
    }
    
    ui.alert("Auto-Refresh Debug", message, ui.ButtonSet.OK);
    
  } catch (e) {
    ui.alert("Error debugging auto-refresh: " + e.message);
  }
}

// ========== SMART BATCH TIMER SYSTEM ==========

/**
 * Creates smart batch timers after user edits (2min + 30min windows)
 * Prevents duplicate sharing and reduces API usage
 */
function setupSmartBatchTimers() {
  try {
    // Check if there are already active batch timers
    const activeBatchTimers = getActiveBatchTimers();
    
    if (activeBatchTimers.length > 0) {
      Logger.log(`SmartRefresh: ${activeBatchTimers.length} batch timers already active, skipping creation`);
      return false;
    }
    
    // Create 2-minute timer (first batch window)
    const shortTimer = ScriptApp.newTrigger('executeBatchShare')
      .timeBased()
      .after(2 * 60 * 1000) // 2 minutes
      .create();
    
    // Create 30-minute timer (extended batch window)  
    const longTimer = ScriptApp.newTrigger('executeBatchShare')
      .timeBased()
      .after(30 * 60 * 1000) // 30 minutes
      .create();
    
    // Store timer IDs for cancellation
    const userProps = PropertiesService.getUserProperties();
    const timerData = {
      shortTimerId: shortTimer.getUniqueId(),
      longTimerId: longTimer.getUniqueId(),
      createdAt: new Date().getTime()
    };
    
    userProps.setProperty('activeBatchTimers', JSON.stringify(timerData));
    
    Logger.log(`SmartRefresh: Created batch timers - Short: ${timerData.shortTimerId}, Long: ${timerData.longTimerId}`);
    return true;
    
  } catch (e) {
    Logger.log(`SmartRefresh: Error setting up batch timers: ${e.message}`);
    return false;
  }
}

/**
 * Cancels all active batch timers (called before manual sharing)
 * @param {boolean} silent - Whether to suppress logging
 * @return {boolean} Success indicator
 */
function cancelActiveBatchTimers(silent = false) {
  try {
    const userProps = PropertiesService.getUserProperties();
    const timerDataJson = userProps.getProperty('activeBatchTimers');
    
    if (!timerDataJson) {
      if (!silent) Logger.log('SmartRefresh: No active batch timers to cancel');
      return true; // Nothing to cancel is success
    }
    
    const timerData = JSON.parse(timerDataJson);
    const triggers = ScriptApp.getProjectTriggers();
    let cancelledCount = 0;
    
    // Cancel triggers by ID
    for (const trigger of triggers) {
      const triggerId = trigger.getUniqueId();
      
      if (triggerId === timerData.shortTimerId || triggerId === timerData.longTimerId) {
        ScriptApp.deleteTrigger(trigger);
        cancelledCount++;
        
        if (!silent) {
          Logger.log(`SmartRefresh: Cancelled batch timer: ${triggerId}`);
        }
      }
    }
    
    // Clear stored timer data
    userProps.deleteProperty('activeBatchTimers');
    
    if (!silent) {
      Logger.log(`SmartRefresh: Successfully cancelled ${cancelledCount} batch timers`);
    }
    
    return true;
    
  } catch (e) {
    Logger.log(`SmartRefresh: Error cancelling batch timers: ${e.message}`);
    return false; // Don't let cancellation errors break manual sharing
  }
}

/**
 * Gets currently active batch timers
 * @return {Object[]} Array of active timer objects
 */
function getActiveBatchTimers() {
  try {
    const userProps = PropertiesService.getUserProperties();
    const timerDataJson = userProps.getProperty('activeBatchTimers');
    
    if (!timerDataJson) return [];
    
    const timerData = JSON.parse(timerDataJson);
    const triggers = ScriptApp.getProjectTriggers();
    const activeTriggers = [];
    
    // Find matching triggers
    for (const trigger of triggers) {
      const triggerId = trigger.getUniqueId();
      
      if (triggerId === timerData.shortTimerId || triggerId === timerData.longTimerId) {
        activeTriggers.push({
          id: triggerId,
          type: triggerId === timerData.shortTimerId ? 'short' : 'long',
          createdAt: timerData.createdAt
        });
      }
    }
    
    return activeTriggers;
    
  } catch (e) {
    Logger.log(`SmartRefresh: Error getting active batch timers: ${e.message}`);
    return [];
  }
}

/**
 * Executes the batch share when timer fires
 * This function is called by the batch timers
 */
function executeBatchShare() {
  try {
    Logger.log('SmartRefresh: Executing batch share from timer');
    
    // Clear timer data since we're executing
    const userProps = PropertiesService.getUserProperties();
    userProps.deleteProperty('activeBatchTimers');
    
    // Execute the actual sharing
    const success = pushAvailabilityToHub();
    
    if (success) {
      Logger.log('SmartRefresh: Batch share completed successfully');
    } else {
      Logger.log('SmartRefresh: Batch share failed');
    }
    
  } catch (e) {
    Logger.log(`SmartRefresh: Error in batch share execution: ${e.message}`);
  }
}

/**
 * Enhanced manual share with timer cancellation
 * Call this instead of pushAvailabilityToHub() directly
 * @return {boolean} Success indicator  
 */
function manualShareWithCancellation() {
  try {
    Logger.log('SmartRefresh: Manual share initiated, cancelling batch timers');
    
    // Cancel any pending batch timers (non-blocking)
    cancelActiveBatchTimers(false);
    
    // Execute manual share
    const success = pushAvailabilityToHub();
    
    if (success) {
      Logger.log('SmartRefresh: Manual share completed successfully');
    }
    
    return success;
    
  } catch (e) {
    Logger.log(`SmartRefresh: Error in manual share with cancellation: ${e.message}`);
    
    // If cancellation fails, still try manual share
    try {
      return pushAvailabilityToHub();
    } catch (shareError) {
      Logger.log(`SmartRefresh: Manual share also failed: ${shareError.message}`);
      throw shareError;
    }
  }
}

/**
 * Debug function to show batch timer status (UI-accessible version)
 */
function debugBatchTimerStatus() {
  const ui = SpreadsheetApp.getUi();
  
  try {
    const activeBatchTimers = getActiveBatchTimers();
    const userProps = PropertiesService.getUserProperties();
    const timerDataJson = userProps.getProperty('activeBatchTimers');
    
    let message = `📤 BATCH TIMER STATUS:\n\n`;
    message += `Active batch timers: ${activeBatchTimers.length}\n\n`;
    
    if (activeBatchTimers.length > 0) {
      activeBatchTimers.forEach((timer, index) => {
        const age = new Date().getTime() - timer.createdAt;
        const ageMinutes = Math.floor(age / (1000 * 60));
        const ageSeconds = Math.floor((age % (1000 * 60)) / 1000);
        
        message += `${index + 1}. ${timer.type.toUpperCase()} TIMER\n`;
        message += `   ID: ${timer.id}\n`;
        message += `   Age: ${ageMinutes}m ${ageSeconds}s\n`;
        message += `   Type: ${timer.type === 'short' ? '2-minute' : '30-minute'} batch\n\n`;
      });
    } else {
      message += `No active batch timers found.\n\n`;
    }
    
    // Show stored data status
    if (timerDataJson) {
      message += `Stored timer data: Yes\n`;
      try {
        const timerData = JSON.parse(timerDataJson);
        const dataAge = new Date().getTime() - timerData.createdAt;
        const dataAgeMinutes = Math.floor(dataAge / (1000 * 60));
        message += `Data age: ${dataAgeMinutes} minutes\n`;
      } catch (e) {
        message += `Data parsing error: ${e.message}\n`;
      }
    } else {
      message += `Stored timer data: No\n`;
    }
    
    message += `\n💡 TIP: Use "Monitor All Active Timers" for complete system overview.`;
    
    ui.alert("📤 Batch Timer Status", message, ui.ButtonSet.OK);
    
  } catch (e) {
    ui.alert("Error debugging batch timers: " + e.message);
  }
}