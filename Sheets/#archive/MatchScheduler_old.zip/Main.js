/**
 * Schedule Manager - Main (AUTH-ONLY SYSTEM - PHASE 3 ENHANCED)
 * 
 * @version 2.1.0 (2025-05-24) - PHASE 3 ENHANCED
 * 
 * Description: Clean auth-only system with Phase 3 CET rollover integration
 * PHASE 3: Added CET testing tools and complete rollover system validation
 * BREAKING: No longer supports guest/open mode - Google auth required
 */

/**
 * CENTRAL onOpen function - AUTH-ONLY with role-based menus
 * This is the ONLY onOpen in the entire project
 */
function onOpen() {
  const ui = SpreadsheetApp.getUi();
  const isAdmin = checkIfUserIsAdmin();
  
  if (isAdmin) {
    // ADMIN MENU - Full access
    createAdminMenu(ui);
  } else {
    // USER MENU - Limited access
    createUserMenu(ui);
  }
  
  // Initialize the system
  initializeSystem();
}

/**
 * Checks if current user is an admin (owner or authorized admin)
 * @return {boolean} True if user has admin privileges
 */
function checkIfUserIsAdmin() {
  try {
    const currentUser = Session.getActiveUser().getEmail();
    const spreadsheet = SpreadsheetApp.getActiveSpreadsheet();
    
    // Method 1: Check if user is the owner
    const owner = spreadsheet.getOwner();
    if (owner && currentUser === owner.getEmail()) {
      return true;
    }
    
    // Method 2: Authorized admin emails list (add your trusted admins here)
    const authorizedAdmins = [
      "your-email@gmail.com",        // Replace with your email
      "trusted-admin@gmail.com"      // Add other admin emails
    ];
    
    return authorizedAdmins.includes(currentUser);
    
  } catch (e) {
    Logger.log(`Error checking admin status: ${e.message}`);
    return false; // Default to non-admin on error
  }
}

/**
 * Creates the full admin menu - AUTH-ONLY SYSTEM WITH PHASE 3 ENHANCEMENTS
 * @param {UI} ui - Google Sheets UI object
 */
function createAdminMenu(ui) {
  ui.createMenu('🎯 Schedule Manager [ADMIN]')
    .addItem('🚀 OPEN SCHEDULE MANAGER', 'showSidebar')
    .addSeparator()
    .addItem('🎨 Apply Colors Manually', 'updateColorsManually')
    .addItem('🔄 Reset Schedule', 'resetScheduleWithConfirmation')
    .addSeparator()
    .addSubMenu(ui.createMenu('📅 WEEK MANAGEMENT')
      .addItem('⏭️ Roll One Week Forward', 'rollOneWeekWithConfirmation')
      .addItem('🔄 Toggle Auto-Roll', 'toggleAutoRoll')
      .addSeparator()
      .addItem('🧪 Test Auto-Roll Logic', 'testAutoRollLogic')
      .addItem('📊 Debug Auto-Roll Status', 'debugAutoRollStatus')
      .addItem('🔍 Test Week Validation', 'debugTestWeekValidationUI')
      .addSeparator()
      .addItem('⚙️ Setup Test Rollover (5min)', 'debugSetupTestRollover'))
    .addSeparator()
    .addSubMenu(ui.createMenu('👥 TEAM MANAGEMENT')
      .addItem('🆕 Spawn New Team Sheet', 'spawnNewTeamSheet')
      .addItem('👑 Assign Team Leader', 'assignTeamLeaderUI')
      .addItem('🧪 Generate Test Team Data', 'generateTestTeamData')
      .addItem('📊 View All Teams Status', 'viewAllTeamsStatus'))
    .addSeparator()
    .addSubMenu(ui.createMenu('⚙️ AUTH SYSTEM')
      .addItem('🧪 Debug Auth System', 'debugUserBindingsAuth')
      .addItem('🔄 Reset User Bindings', 'resetUserBindingsAuth'))
    .addSeparator()
    .addSubMenu(ui.createMenu('🔧 DEBUG')
      .addSubMenu(ui.createMenu('🧪 Sidebar Testing')
        .addItem('Test Minimal Sidebar', 'debugTestMinimalSidebar')
        .addItem('Force Cache Clear', 'debugForceCacheClear')
        .addItem('Test Registration Check', 'debugRegistrationCheck'))
      .addSubMenu(ui.createMenu('📊 System Status')
        .addItem('Check Sheet State', 'debugSheetState')
        .addItem('Check Team Info', 'debugTeamInfo')
        .addItem('Check Block Detection', 'debugBlockDetection')
        .addItem('Test Auto-Initialization', 'debugAutoInitialization'))
      .addSubMenu(ui.createMenu('🕐 CET TIME TESTING')
        .addItem('🕐 CET Time Manager Status', 'debugCETTimeManagerStatus')
        .addItem('🧪 Test CET Calculations', 'debugTestCETCalculationsUI')
        .addItem('🔄 Test Rollover Timing', 'debugTestRolloverTimingUI')
        .addSeparator()
        .addItem('🎯 Test Complete Phase 3 System', 'debugTestCompletePhase3System'))
      .addSubMenu(ui.createMenu('🕐 TIMER MONITORING')
        .addItem('🔍 Monitor All Active Timers', 'debugAllActiveTimers')
        .addItem('📤 Monitor Batch Timers Only', 'debugBatchTimerStatus')
        .addItem('⏰ Monitor Auto-Roll Status', 'debugAutoRollStatus')
        .addItem('🔄 Monitor Auto-Refresh Status', 'debugAutoRefreshStatus')
        .addSeparator()
        .addItem('🛑 Cancel Batch Timers', 'adminCancelAllBatchTimers')
        .addItem('⚠️ Emergency Timer Cleanup', 'adminEmergencyTimerCleanup'))
      .addSubMenu(ui.createMenu('🎨 Logo Testing')
        .addItem('Test Logo Fetch', 'debugLogoFetchSafe')
        .addItem('Test Logo Setup', 'debugLogoSetup')
        .addItem('Check Drive Folder', 'debugDriveFolder'))
      .addSubMenu(ui.createMenu('🌐 Hub Testing')
        .addItem('Test Hub Connectivity', 'debugHubConnectivity')
        .addItem('Test Team Registration Status', 'debugTeamRegistrationStatus')
        .addItem('Test Available Teams', 'debugAvailableTeams'))
      .addSubMenu(ui.createMenu('🏥 Hub Health Monitoring')
        .addItem('📊 Hub Health Overview', 'showHubHealthStatus')
        .addItem('📋 Detailed Team Status', 'showDetailedTeamStatus')
        .addSeparator()
        .addItem('🧪 Test Health Check System', 'debugTestHubHealthCheck')
        .addItem('🔍 Validate Complete System', 'validateHubMonitoringSystem'))
      .addSubMenu(ui.createMenu('🧪 Display Teams Testing')
        .addItem('Debug Selected Teams Display', 'debugDisplaySelectedTeamsUI')
        .addItem('Fix Selected Teams IDs', 'fixSelectedTeamIdsUI')))
    .addToUi();
}

/**
 * Creates the limited user menu for team members - AUTH-ONLY
 * @param {UI} ui - Google Sheets UI object
 */
function createUserMenu(ui) {
  ui.createMenu('🎯 Schedule Manager')
    .addItem('🚀 OPEN SCHEDULE MANAGER', 'showSidebar')
    .addSeparator()
    .addItem('🎨 Apply Colors Manually', 'applyColorsToAllBlocks')
    .addItem('🔄 Reset Schedule', 'resetScheduleWithConfirmation')
    .addSeparator()
    .addSubMenu(ui.createMenu('ℹ️ HELP')
      .addItem('📖 How to Use', 'showHelpGuide')
      .addItem('🐛 Report Issue', 'reportIssue'))
    .addToUi();
}

/**
 * Shows help guide for regular users - AUTH-ONLY SYSTEM
 */
function showHelpGuide() {
  const ui = SpreadsheetApp.getUi();
  const message = `📖 How to Use Schedule Manager (Auth-Only):\n\n` +
                 `1. 🔐 Log into your Google account\n` +
                 `2. 🚀 Click "Open Schedule Manager"\n` +
                 `3. 🎮 Join team (first time only)\n` +
                 `4. 📅 Select cells in your schedule\n` +
                 `5. 👤 Click "Add Me" to mark availability\n` +
                 `6. 📤 Click "Share Availability" to sync\n` +
                 `7. 👥 Select other teams to compare schedules\n\n` +
                 `💡 Tip: Colors show player counts:\n` +
                 `🔴 1 player  🟡 2-3 players  🟢 4+ players`;
  
  ui.alert('📖 Help Guide', message, ui.ButtonSet.OK);
}

/**
 * Allows users to report issues
 */
function reportIssue() {
  const ui = SpreadsheetApp.getUi();
  const response = ui.prompt(
    '🐛 Report Issue',
    'Describe the problem you\'re experiencing:\n\n(This will be logged for the admin to review)',
    ui.ButtonSet.OK_CANCEL
  );
  
  if (response.getSelectedButton() === ui.Button.OK) {
    const issue = response.getResponseText();
    const user = Session.getActiveUser().getEmail();
    const timestamp = new Date().toISOString();
    
    Logger.log(`USER ISSUE REPORT - ${timestamp} - ${user}: ${issue}`);
    ui.alert('Issue reported. Thank you for your feedback!');
  }
}

/**
 * PHASE 4 SIMPLIFIED: Always uses ScheduleSidebar.html (auth-aware)
 */
function showSidebar() {
  try {
    // First ensure we have a valid schedule
    if (!hasValidSchedule()) {
      Logger.log("No valid schedule found when showing sidebar, creating one");
      createSchedule();
    }
    
    // Always use the updated ScheduleSidebar.html file (handles auth internally)
    const html = HtmlService.createHtmlOutputFromFile('ScheduleSidebar')
      .setTitle('Schedule Manager')
      .setWidth(300);
    
    SpreadsheetApp.getUi().showSidebar(html);
    Logger.log("Auth-only sidebar displayed successfully");
    
  } catch (e) {
    Logger.log("Error showing sidebar: " + e.message);
    SpreadsheetApp.getUi().alert("Error opening sidebar: " + e.message);
  }
}

/**
 * Confirms and resets the schedule
 */
function resetScheduleWithConfirmation() {
  const ui = SpreadsheetApp.getUi();
  const response = ui.alert(
    'Reset Schedule',
    'This will create a new clean schedule with current and next week.\n\nExisting team and player names will be preserved. Continue?',
    ui.ButtonSet.YES_NO
  );
  
  if (response === ui.Button.YES) {
    createSchedule(); // No success message - user can see the result
  }
}

/**
 * Confirms and rolls forward one week
 */
function rollOneWeekWithConfirmation() {
  const ui = SpreadsheetApp.getUi();
  const response = ui.alert(
    'Roll Forward',
    'This will roll the schedule forward by one week.\n\nThe newer week will move to the left position and a new week will be created on the right. Continue?',
    ui.ButtonSet.YES_NO
  );
  
  if (response === ui.Button.YES) {
    rollOneWeekForward();
  }
}

/**
 * Toggles the auto-roll setting and shows current status
 */
function toggleAutoRoll() {
  const ui = SpreadsheetApp.getUi();
  
  try {
    const currentSetting = getAutoRoll();
    const newSetting = !currentSetting;
    
    const response = ui.alert(
      'Toggle Auto-Roll',
      `Auto-roll is currently: ${currentSetting ? 'ENABLED' : 'DISABLED'}\n\nChange to: ${newSetting ? 'ENABLED' : 'DISABLED'}?\n\n${newSetting ? 'Your schedule will automatically stay current by rolling to new weeks.' : 'You will need to manually roll weeks forward.'}`,
      ui.ButtonSet.YES_NO
    );
    
    if (response === ui.Button.YES) {
      setAutoRoll(newSetting);
      ui.alert(`Auto-roll is now ${newSetting ? 'ENABLED' : 'DISABLED'}`);
    }
    
  } catch (e) {
    ui.alert('Error toggling auto-roll: ' + e.message);
  }
}

// ========== TEAM MANAGEMENT FUNCTIONS ==========

/**
 * Spawns a new team sheet from current template
 */
function spawnNewTeamSheet() {
  const ui = SpreadsheetApp.getUi();
  
  try {
    // Step 1: Get team name
    const nameResponse = ui.prompt(
      '🆕 Spawn New Team Sheet',
      'Enter the new team name:\n\n(This will create "team_[name]_schedule")',
      ui.ButtonSet.OK_CANCEL
    );
    
    if (nameResponse.getSelectedButton() !== ui.Button.OK) {
      return; // User cancelled
    }
    
    const teamName = nameResponse.getResponseText().trim();
    if (!teamName) {
      ui.alert('Team name cannot be empty');
      return;
    }
    
    // Step 2: Create copy with grouped naming
    const currentSpreadsheet = SpreadsheetApp.getActiveSpreadsheet();
    const cleanName = teamName.toLowerCase().replace(/[^a-zA-Z0-9]/g, '_');
    const newFileName = `team_${cleanName}_schedule`;
    
    ui.alert('Creating copy...', 'Creating new team sheet, please wait...', ui.ButtonSet.OK);
    
    // Create the copy
    const newSpreadsheet = currentSpreadsheet.copy(newFileName);
    const newUrl = newSpreadsheet.getUrl();
    const newScriptId = extractScriptIdFromSpreadsheet(newSpreadsheet);
    
    // Step 3: Clean up the new sheet (remove current team data)
    initializeNewTeamSheet(newSpreadsheet);
    
    // Step 4: Show results and next steps
    const message = `✅ New team sheet created!\n\n` +
                   `📁 Name: ${newFileName}\n` +
                   `📜 Script ID: ${newScriptId}\n` +
                   `🔗 URL: ${newUrl}\n\n` +
                   `📋 Next Steps:\n` +
                   `1. Click URL to open new sheet\n` +
                   `2. Grant permissions (sidebar, logo test)\n` +
                   `3. Use debug tools to populate test data\n` +
                   `4. Share URL with team leader`;
    
    ui.alert('🎉 Team Sheet Created', message, ui.ButtonSet.OK);
    
    // Log for deployment tracking
    Logger.log(`NEW TEAM SHEET: ${newFileName} | Script ID: ${newScriptId} | URL: ${newUrl}`);
    
  } catch (e) {
    Logger.log(`Error spawning team sheet: ${e.message}`);
    ui.alert('Error creating team sheet: ' + e.message);
  }
}

/**
 * Extracts the script ID from a spreadsheet for deployment tracking
 * @param {Spreadsheet} spreadsheet - The spreadsheet to get script ID from
 * @return {string} The script ID
 */
function extractScriptIdFromSpreadsheet(spreadsheet) {
  try {
    // The script ID is embedded in the spreadsheet
    // We can get it by accessing the script project
    const scriptId = ScriptApp.newTrigger('dummyFunction')
      .timeBased()
      .after(1)
      .create()
      .getUniqueId()
      .split('_')[0]; // Extract script ID portion
    
    // Clean up the dummy trigger
    const triggers = ScriptApp.getProjectTriggers();
    triggers.forEach(trigger => {
      if (trigger.getHandlerFunction() === 'dummyFunction') {
        ScriptApp.deleteTrigger(trigger);
      }
    });
    
    return scriptId;
  } catch (e) {
    Logger.log(`Could not extract script ID: ${e.message}`);
    return 'SCRIPT_ID_UNKNOWN';
  }
}

/**
 * Initializes a newly spawned team sheet
 * @param {Spreadsheet} spreadsheet - The new spreadsheet to initialize
 */
function initializeNewTeamSheet(spreadsheet) {
  try {
    const sheet = spreadsheet.getActiveSheet();
    
    // Clear any existing team data
    sheet.getRange("B3").setValue(""); // Clear team name to force registration
    
    // Clear player names to force fresh setup
    for (let i = 4; i <= 9; i++) {
      sheet.getRange(i, 2).setValue("");
    }
    
    // Clear logo area
    const logoRange = sheet.getRange("A10:B15");
    logoRange.unmerge();
    logoRange.clearContent();
    logoRange.setValue("🏮 Team Logo");
    logoRange.merge();
    logoRange.setHorizontalAlignment("center");
    logoRange.setVerticalAlignment("middle");
    
    Logger.log(`Initialized new team sheet: ${spreadsheet.getName()}`);
    
  } catch (e) {
    Logger.log(`Error initializing new team sheet: ${e.message}`);
  }
}

/**
 * Generates realistic test data for testing multi-team features
 */
function generateTestTeamData() {
  const ui = SpreadsheetApp.getUi();
  
  const response = ui.alert(
    '🧪 Generate Test Data',
    'This will add:\n• Random team name\n• 4-6 test players\n• Realistic availability patterns\n\nContinue?',
    ui.ButtonSet.YES_NO
  );
  
  if (response !== ui.Button.YES) {
    return;
  }
  
  try {
    const sheet = SpreadsheetApp.getActiveSpreadsheet().getActiveSheet();
    
    // Step 1: Generate team info
    generateTestTeamInfo(sheet);
    
    // Step 2: Ensure valid schedule exists
    if (!hasValidSchedule()) {
      createSchedule();
    }
    
    // Step 3: Generate availability data
    const blocks = findAllBlocks();
    if (blocks.length === 0) {
      ui.alert('No schedule blocks found. Try resetting schedule first.');
      return;
    }
    
    // Generate realistic availability patterns
    for (const block of blocks) {
      generateBlockTestData(sheet, block);
    }
    
    // Step 4: Apply colors
    applyColorToAllBlocks();
    
    ui.alert('🧪 Test Data Generated', 'Team info and realistic availability patterns created!', ui.ButtonSet.OK);
    
  } catch (e) {
    Logger.log(`Error generating test data: ${e.message}`);
    ui.alert('Error generating test data: ' + e.message);
  }
}

/**
 * Generates test team information (name and players)
 * @param {Sheet} sheet - Sheet to modify
 */
function generateTestTeamInfo(sheet) {
  // Generate random team name
  const teamNames = [
    "Dragons", "Eagles", "Wolves", "Lions", "Tigers", "Bears", "Knights", "Warriors",
    "Rangers", "Guardians", "Hunters", "Vikings", "Spartans", "Titans", "Phoenix", "Storm"
  ];
  const randomTeam = teamNames[Math.floor(Math.random() * teamNames.length)];
  
  // Generate player names
  const firstNames = ["Alex", "Jordan", "Casey", "Morgan", "Taylor", "Jamie", "Riley", "Cameron", "Avery", "Quinn"];
  const lastNames = ["Smith", "Johnson", "Brown", "Davis", "Miller", "Wilson", "Moore", "Taylor", "Anderson", "Jackson"];
  
  const playerCount = 4 + Math.floor(Math.random() * 3); // 4-6 players
  const players = [];
  
  for (let i = 0; i < playerCount; i++) {
    const firstName = firstNames[Math.floor(Math.random() * firstNames.length)];
    const lastName = lastNames[Math.floor(Math.random() * lastNames.length)];
    players.push(`${firstName} ${lastName}`);
  }
  
  // Set team name
  sheet.getRange("B3").setValue(randomTeam);
  
  // Set player names and initials
  for (let i = 0; i < 6; i++) {
    const row = 4 + i;
    if (i < players.length) {
      const playerName = players[i];
      const initial = playerName.split(' ').map(n => n[0]).join('').toUpperCase();
      
      sheet.getRange(row, 1).setValue(initial);
      sheet.getRange(row, 2).setValue(playerName);
    } else {
      // Clear unused slots
      sheet.getRange(row, 1).setValue("");
      sheet.getRange(row, 2).setValue("");
    }
  }
  
  Logger.log(`Generated test team: ${randomTeam} with ${playerCount} players`);
}

/**
 * Generates test data for a specific block
 * @param {Sheet} sheet - Sheet to modify
 * @param {Object} block - Block information
 */
function generateBlockTestData(sheet, block) {
  try {
    // Get player initials from the sheet
    const playerInitials = [];
    for (let i = 4; i <= 9; i++) {
      const initial = sheet.getRange(i, 1).getValue();
      if (initial && String(initial).trim() !== "") {
        playerInitials.push(String(initial).trim());
      }
    }
    
    if (playerInitials.length === 0) {
      return; // No players to generate data for
    }
    
    // Generate realistic patterns
    for (let timeRow = 0; timeRow < block.gridHeight; timeRow++) {
      for (let dayCol = 0; dayCol < block.gridWidth; dayCol++) {
        const cellRow = block.timeStartRow + timeRow;
        const cellCol = block.col + dayCol;
        
        // Create realistic availability patterns
        const isWeekend = dayCol >= 5; // Sat/Sun
        const isEarlyEvening = timeRow <= 2; // First few time slots
        const isLateNight = timeRow >= block.gridHeight - 2; // Last few slots
        
        // Adjust probability based on time and day
        let baseProb = 0.3; // Base 30% chance per player
        if (isWeekend) baseProb += 0.2; // More available on weekends
        if (isEarlyEvening) baseProb += 0.1; // More available early evening
        if (isLateNight) baseProb -= 0.1; // Less available late night
        
        // Generate player list for this cell
        const availablePlayers = [];
        for (const initial of playerInitials) {
          if (Math.random() < baseProb) {
            availablePlayers.push(initial);
          }
        }
        
        // Set cell value
        if (availablePlayers.length > 0) {
          sheet.getRange(cellRow, cellCol).setValue(availablePlayers.join(", "));
        }
      }
    }
    
  } catch (e) {
    Logger.log(`Error generating test data for block: ${e.message}`);
  }
}

// ========== PHASE 3: CET TESTING FUNCTIONS ==========

/**
 * UI wrapper for CET calculation testing
 */
function debugTestCETCalculationsUI() {
  const ui = SpreadsheetApp.getUi();
  
  try {
    const results = debugTestCETCalculations();
    
    let message = `🧪 CET CALCULATION TEST RESULTS:\n\n`;
    message += `Current CET: ${results.currentCETTime.toLocaleString()}\n`;
    message += `Current Week: ${results.currentWeekCET}\n`;
    message += `DST Active: ${results.isDSTActive}\n`;
    message += `Next Monday: ${results.nextMonday.toDateString()}\n\n`;
    
    message += `🔄 ROLLOVER TIMES:\n`;
    message += `Primary: ${results.rolloverTimes.primary.toLocaleString()}\n`;
    message += `Failover: ${results.rolloverTimes.failover.toLocaleString()}\n`;
    message += `Emergency: ${results.rolloverTimes.emergency.toLocaleString()}\n\n`;
    
    if (results.rolloverWindow.inWindow) {
      message += `⚠️ IN ROLLOVER WINDOW: ${results.rolloverWindow.rolloverType}\n`;
    } else {
      message += `✅ Outside rollover window\n`;
    }
    
    message += `\n💡 Check script editor logs for detailed test results.`;
    
    ui.alert("🧪 CET Test Results", message, ui.ButtonSet.OK);
    
  } catch (e) {
    ui.alert("CET test error: " + e.message);
  }
}

/**
 * UI wrapper for rollover timing tests
 */
function debugTestRolloverTimingUI() {
  const ui = SpreadsheetApp.getUi();
  
  try {
    const cetNow = getCurrentCETTime();
    const currentWeek = getCurrentWeekNumberCET();
    const nextWeek = currentWeek + 1;
    
    // Test rollover timing for different scenarios
    const results = {
      currentTime: cetNow,
      currentWeek: currentWeek,
      nextWeek: nextWeek,
      rolloverWindow: isRolloverWindowCET(),
      nextRollovers: {
        primary: getNextRolloverTimeCET('primary'),
        failover: getNextRolloverTimeCET('failover'),
        emergency: getNextRolloverTimeCET('emergency')
      }
    };
    
    let message = `🔄 ROLLOVER TIMING TEST:\n\n`;
    message += `Current CET: ${results.currentTime.toLocaleString()}\n`;
    message += `Current Week: ${results.currentWeek}\n`;
    message += `Next Week: ${results.nextWeek}\n\n`;
    
    message += `⏰ NEXT ROLLOVER SCHEDULE:\n`;
    const primary = results.nextRollovers.primary;
    const failover = results.nextRollovers.failover;
    const emergency = results.nextRollovers.emergency;
    
    message += `Primary: ${primary.toLocaleDateString()} ${primary.toLocaleTimeString()}\n`;
    message += `Failover: ${failover.toLocaleDateString()} ${failover.toLocaleTimeString()}\n`;
    message += `Emergency: ${emergency.toLocaleDateString()} ${emergency.toLocaleTimeString()}\n\n`;
    
    // Calculate time until next rollover
    const timeUntilPrimary = Math.round((primary.getTime() - cetNow.getTime()) / (1000 * 60 * 60));
    message += `⏳ Time until primary rollover: ${timeUntilPrimary} hours\n`;
    
    if (results.rolloverWindow.inWindow) {
      message += `\n⚠️ CURRENTLY IN ROLLOVER WINDOW!\n`;
      message += `Type: ${results.rolloverWindow.rolloverType.toUpperCase()}\n`;
      message += `Minutes from rollover: ${results.rolloverWindow.minutesFromRollover}`;
    }
    
    ui.alert("🔄 Rollover Timing", message, ui.ButtonSet.OK);
    
  } catch (e) {
    ui.alert("Rollover timing test error: " + e.message);
  }
}

// ========== PHASE 3B: ENHANCED ROLLOVER TESTING ==========

/**
 * UI wrapper for week validation testing
 */
function debugTestWeekValidationUI() {
  const ui = SpreadsheetApp.getUi();
  
  try {
    const blocks = findAllBlocks();
    
    if (blocks.length === 0) {
      ui.alert("No week blocks found. Please create a schedule first.");
      return;
    }
    
    const weekObjects = blocks.map(block => ({ weekNumber: block.weekNumber }));
    const validation = validateWeekAlignment(weekObjects);
    const currentWeekCET = getCurrentWeekNumberCET();
    
    let message = `🔍 WEEK VALIDATION TEST:\n\n`;
    message += `Current CET Week: ${currentWeekCET}\n`;
    message += `Next CET Week: ${currentWeekCET + 1}\n`;
    message += `Local Weeks: [${blocks.map(b => b.weekNumber).join(', ')}]\n\n`;
    
    message += `📊 VALIDATION RESULTS:\n`;
    message += `Status: ${validation.status}\n`;
    message += `Valid: ${validation.isValid ? '✅' : '❌'}\n`;
    message += `Needs Rollover: ${validation.needsRollover ? '⚠️ YES' : '✅ NO'}\n`;
    message += `Has Current Week: ${validation.hasCurrentWeek ? '✅' : '❌'}\n`;
    message += `Has Next Week: ${validation.hasNextWeek ? '✅' : '❌'}\n\n`;
    
    if (validation.pastWeeks.length > 0) {
      message += `📅 Past Weeks: [${validation.pastWeeks.join(', ')}]\n`;
    }
    
    if (validation.futureWeeks.length > 0) {
      message += `🔮 Future Weeks: [${validation.futureWeeks.join(', ')}]\n`;
    }
    
    if (validation.errors.length > 0) {
      message += `\n❌ ERRORS:\n${validation.errors.join('\n')}\n`;
    }
    
    if (validation.warnings.length > 0) {
      message += `\n⚠️ WARNINGS:\n${validation.warnings.join('\n')}`;
    }
    
    ui.alert("🔍 Week Validation Results", message, ui.ButtonSet.OK);
    
  } catch (e) {
    ui.alert("Week validation test error: " + e.message);
  }
}

/**
 * Sets up a test rollover trigger for 5 minutes from now
 */
function debugSetupTestRollover() {
  const ui = SpreadsheetApp.getUi();
  
  try {
    const response = ui.alert(
      '⚙️ Setup Test Rollover',
      'This will create a test trigger that fires in 5 minutes to test the auto-rollover system.\n\nThe test trigger will run alongside the regular rollover system. Continue?',
      ui.ButtonSet.YES_NO
    );
    
    if (response !== ui.Button.YES) {
      return;
    }
    
    // Create a trigger that fires in 5 minutes
    const triggerTime = new Date();
    triggerTime.setMinutes(triggerTime.getMinutes() + 5);
    
    ScriptApp.newTrigger('debugTestRolloverTrigger')
      .timeBased()
      .at(triggerTime)
      .create();
    
    const message = `✅ Test rollover trigger created!\n\n` +
                   `Trigger time: ${triggerTime.toLocaleString()}\n` +
                   `Function: debugTestRolloverTrigger\n\n` +
                   `The trigger will:\n` +
                   `1. Test CET calculations\n` +
                   `2. Validate current week alignment\n` +
                   `3. Log detailed results\n` +
                   `4. NOT perform actual rollover (safe test)\n\n` +
                   `Check the script editor logs in 5 minutes to see results.`;
    
    ui.alert("⚙️ Test Trigger Created", message, ui.ButtonSet.OK);
    
    Logger.log(`TEST ROLLOVER TRIGGER: Created for ${triggerTime.toISOString()}`);
    
  } catch (e) {
    ui.alert("Error setting up test rollover: " + e.message);
  }
}

/**
 * Test rollover trigger function (safe testing without actual rollover)
 */
function debugTestRolloverTrigger() {
  try {
    Logger.log("=== TEST ROLLOVER TRIGGER FIRED ===");
    Logger.log(`Execution time: ${new Date().toISOString()}`);
    
    // Test CET calculations
    const cetNow = getCurrentCETTime();
    const currentWeekCET = getCurrentWeekNumberCET();
    const rolloverWindow = isRolloverWindowCET();
    
    Logger.log(`CET Time: ${cetNow.toISOString()}`);
    Logger.log(`CET Week: ${currentWeekCET}`);
    Logger.log(`Rollover Window: ${JSON.stringify(rolloverWindow)}`);
    
    // Test week validation
    const blocks = findAllBlocks();
    if (blocks.length > 0) {
      const weekObjects = blocks.map(block => ({ weekNumber: block.weekNumber }));
      const validation = validateWeekAlignment(weekObjects);
      
      Logger.log(`Week Validation: ${JSON.stringify(validation, null, 2)}`);
      
      // Test rollover decision logic (without actually rolling)
      let wouldRoll = false;
      let reason = '';
      
      if (validation.needsRollover) {
        wouldRoll = true;
        reason = `Week validation indicates rollover needed: ${validation.status}`;
      } else if (!validation.hasCurrentWeek && rolloverWindow.inWindow) {
        wouldRoll = true;
        reason = `Missing current week during ${rolloverWindow.rolloverType} rollover window`;
      }
      
      Logger.log(`AUTO-ROLL DECISION: Would roll: ${wouldRoll}`);
      if (wouldRoll) {
        Logger.log(`AUTO-ROLL REASON: ${reason}`);
      }
      
    } else {
      Logger.log("No blocks found for validation test");
    }
    
    Logger.log("=== TEST ROLLOVER TRIGGER COMPLETE ===");
    
    // Clean up the test trigger
    const triggers = ScriptApp.getProjectTriggers();
    triggers.forEach(trigger => {
      if (trigger.getHandlerFunction() === 'debugTestRolloverTrigger') {
        ScriptApp.deleteTrigger(trigger);
        Logger.log("Test trigger cleaned up");
      }
    });
    
  } catch (e) {
    Logger.log(`TEST ROLLOVER TRIGGER ERROR: ${e.message}`);
  }
}

/**
 * Comprehensive test of the complete Phase 3 system integration
 */
function debugTestCompletePhase3System() {
  const ui = SpreadsheetApp.getUi();
  
  try {
    Logger.log("=== PHASE 3 COMPLETE SYSTEM TEST ===");
    
    let message = `🎯 PHASE 3 COMPLETE SYSTEM TEST:\n\n`;
    let allTestsPassed = true;
    
    // Test 1: CET Time Manager
    try {
      const cetNow = getCurrentCETTime();
      const currentWeekCET = getCurrentWeekNumberCET();
      message += `✅ CET Time Manager: ${cetNow.toLocaleString()}\n`;
      message += `✅ CET Week: ${currentWeekCET}\n`;
    } catch (e) {
      message += `❌ CET Time Manager: ${e.message}\n`;
      allTestsPassed = false;
    }
    
    // Test 2: Week Validation
    try {
      const blocks = findAllBlocks();
      if (blocks.length > 0) {
        const weekObjects = blocks.map(block => ({ weekNumber: block.weekNumber }));
        const validation = validateWeekAlignment(weekObjects);
        message += `✅ Week Validation: ${validation.status}\n`;
        message += `   Current: ${validation.hasCurrentWeek}, Next: ${validation.hasNextWeek}\n`;
      } else {
        message += `⚠️ Week Validation: No blocks found\n`;
      }
    } catch (e) {
      message += `❌ Week Validation: ${e.message}\n`;
      allTestsPassed = false;
    }
    
    // Test 3: DataContract Integration
    try {
      const atomicData = buildAtomicTeamData();
      const validation = validateTeamDataContract(atomicData);
      message += `✅ DataContract: ${validation.isValid ? 'Valid' : 'Invalid'}\n`;
      message += `   Version: ${atomicData.version}, CET: ${atomicData.syncMetadata.cetTimeUsed}\n`;
    } catch (e) {
      message += `❌ DataContract: ${e.message}\n`;
      allTestsPassed = false;
    }
    
    // Test 4: Conflict Detection (simulated)
    try {
      const localData = buildAtomicTeamData();
      const conflicts = detectConflicts(localData, null);
      message += `✅ Conflict Detection: ${conflicts.hasConflicts ? conflicts.totalIssues + ' issues' : 'Clean'}\n`;
    } catch (e) {
      message += `❌ Conflict Detection: ${e.message}\n`;
      allTestsPassed = false;
    }
    
    // Test 5: Rollover System
    try {
      const rolloverWindow = isRolloverWindowCET();
      const autoRollEnabled = getAutoRoll();
      message += `✅ Rollover System: ${autoRollEnabled ? 'Enabled' : 'Disabled'}\n`;
      message += `   Window: ${rolloverWindow.inWindow ? rolloverWindow.rolloverType : 'Outside'}\n`;
    } catch (e) {
      message += `❌ Rollover System: ${e.message}\n`;
      allTestsPassed = false;
    }
    
    message += `\n🎯 OVERALL RESULT: ${allTestsPassed ? '✅ ALL TESTS PASSED' : '❌ SOME TESTS FAILED'}\n\n`;
    message += `📋 PHASE 3 COMPONENTS:\n`;
    message += `   Phase 3A: CET Timezone Foundation ✅\n`;
    message += `   Phase 3B: RollerSystem Integration ✅\n`;
    message += `   Phase 3C: DataContract Integration ✅\n\n`;
    message += `💡 Check script editor logs for detailed results.`;
    
    ui.alert("🎯 Phase 3 Complete System Test", message, ui.ButtonSet.OK);
    
    Logger.log(`PHASE 3 COMPLETE SYSTEM TEST: ${allTestsPassed ? 'PASSED' : 'FAILED'}`);
    Logger.log("=== PHASE 3 COMPLETE SYSTEM TEST END ===");
    
  } catch (e) {
    ui.alert("Phase 3 system test error: " + e.message);
    Logger.log(`PHASE 3 SYSTEM TEST ERROR: ${e.message}`);
  }
}

// ========== PHASE 4 CLEANUP COMPLETE ==========
// REMOVED in Phase 4 (~120 lines eliminated):
// - showOriginalSidebar() - Legacy function
// - showAuthenticatedSidebar() - Inline HTML system (~80 lines)
// - claimSlotTest() - Test function (~20 lines)
// - Dual-mode routing logic - Replaced with single path
// - "Toggle Access Mode" menu items - No longer needed
// Total cleanup: Cleaner, more maintainable auth-only system