/**
 * Schedule Manager - Logo Manager (PHASE 2: NATIVE PROTECTION INTEGRATED)
 * 
 * @version 1.3.0 (2025-05-25) - PHASE 2 COMPLETE - NATIVE PROTECTION BYPASS
 * 
 * Description: Handles team logo URL fetching, file uploads, Drive storage, and display with native protection bypass
 * PHASE 2: All logo setup functions use native protection bypass for secure operations
 * UPDATED: Logo area widened from A9:B15 to A9:D15 to match 2x5 roster layout
 * ENHANCED: Direct file upload support alongside URL-based uploads
 */

// Target Drive folder ID for all team logos
const LOGO_DRIVE_FOLDER_ID = "11eQcTKCol9wPyn6XfqbKaDOEwwa0zbqg";

/**
 * NEW: Handles file upload from sidebar
 * @param {string} base64Data - Base64 encoded file data (without prefix)
 * @param {string} fileName - Original filename
 * @param {string} mimeType - File MIME type
 * @return {string} Public Google Drive URL for use in IMAGE() formula
 */
function uploadLogoFile(base64Data, fileName, mimeType) {
  try {
    Logger.log(`LogoManager: Processing file upload: ${fileName} (${mimeType})`);
    
    // Convert base64 back to blob
    const blob = Utilities.newBlob(
      Utilities.base64Decode(base64Data), 
      mimeType, 
      fileName
    );
    
    // Get team name for file naming
    const sheet = SpreadsheetApp.getActiveSpreadsheet().getActiveSheet();
    const teamName = sheet.getRange("B3").getValue() || "UnknownTeam";
    
    // Save the logo and get public URL
    const publicUrl = saveTeamLogoTodrive(blob, teamName);
    
    // Update logo in spreadsheet
    setupTeamLogo(sheet, publicUrl);
    
    // Update hub with logo URL (if registered)
    updateHubLogoInfo(publicUrl);
    
    Logger.log(`LogoManager: File upload completed successfully: ${publicUrl}`);
    return publicUrl;
    
  } catch (e) {
    Logger.log(`LogoManager: Error in file upload: ${e.message}`);
    throw new Error(`Failed to upload logo file: ${e.message}`);
  }
}

/**
 * ENHANCED: Fetches an image from URL and saves it to Google Drive
 * @param {string} imageUrl - URL of the image to fetch
 * @param {string} teamName - Team name for file naming
 * @return {string} Public Google Drive URL for use in IMAGE() formula
 */
function fetchAndSaveTeamLogo(imageUrl, teamName) {
  try {
    Logger.log(`LogoManager: Fetching logo from ${imageUrl} for team ${teamName}`);
    
    // Validate URL
    if (!imageUrl || !imageUrl.trim()) {
      throw new Error("No logo URL provided");
    }
    
    // Fetch image from URL
    const response = UrlFetchApp.fetch(imageUrl);
    const imageBlob = response.getBlob();
    
    // Save the logo and get public URL
    const publicUrl = saveTeamLogoTodrive(imageBlob, teamName);
    
    Logger.log(`LogoManager: URL fetch completed successfully: ${publicUrl}`);
    return publicUrl;
    
  } catch (e) {
    Logger.log(`LogoManager: Error fetching/saving logo from URL: ${e.message}`);
    throw new Error(`Failed to fetch logo: ${e.message}`);
  }
}

/**
 * NEW: Core function to save any blob (file or URL) to Drive with standardized naming
 * @param {Blob} imageBlob - Image blob to save
 * @param {string} teamName - Team name for file naming
 * @return {string} Public Google Drive URL
 */
function saveTeamLogoTodrive(imageBlob, teamName) {
  try {
    // Clean team name for filename (remove spaces, special chars, lowercase)
    const cleanTeamName = teamName.toLowerCase().replace(/[^a-zA-Z0-9]/g, '');
    
    // Determine file extension from content type or default
    let fileExtension = getExtensionFromContentType(imageBlob.getContentType());
    if (!fileExtension) {
      fileExtension = 'png'; // Default fallback
    }
    
    const standardFileName = `${cleanTeamName}_logo.${fileExtension}`;
    
    // Get the target Drive folder
    const logoFolder = DriveApp.getFolderById(LOGO_DRIVE_FOLDER_ID);
    
    // Delete existing logo for this team (ensures only 1 logo per team)
    deleteExistingTeamLogo(logoFolder, cleanTeamName);
    
    // Create new file in Drive
    const file = logoFolder.createFile(imageBlob.setName(standardFileName));
    
    // Set public sharing permissions
    file.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW);
    
    // Generate public URL for IMAGE() formula
    const publicUrl = `https://drive.google.com/uc?id=${file.getId()}`;
    
    Logger.log(`LogoManager: Successfully saved logo as ${standardFileName}, public URL: ${publicUrl}`);
    return publicUrl;
    
  } catch (e) {
    Logger.log(`LogoManager: Error saving logo to Drive: ${e.message}`);
    throw new Error(`Failed to save logo to Drive: ${e.message}`);
  }
}

/**
 * ENHANCED: Deletes existing logo for a team to ensure only 1 logo per team
 * @param {Folder} folder - Logos folder
 * @param {string} cleanTeamName - Clean team name for filename matching
 */
function deleteExistingTeamLogo(folder, cleanTeamName) {
  try {
    const files = folder.getFiles();
    
    while (files.hasNext()) {
      const file = files.next();
      const fileName = file.getName();
      
      // Check if this file belongs to the same team (starts with teamname_logo.)
      if (fileName.startsWith(cleanTeamName + "_logo.")) {
        Logger.log(`LogoManager: Deleting existing logo: ${fileName}`);
        file.setTrashed(true);
      }
    }
  } catch (e) {
    Logger.log(`LogoManager: Warning - could not delete existing logos: ${e.message}`);
    // Continue anyway - not critical
  }
}

/**
 * Maps content type to file extension
 * @param {string} contentType - MIME content type
 * @return {string} File extension
 */
function getExtensionFromContentType(contentType) {
  const typeMap = {
    'image/png': 'png',
    'image/jpeg': 'jpg',
    'image/jpg': 'jpg',
    'image/gif': 'gif',
    'image/webp': 'webp'
  };
  
  return typeMap[contentType] || 'png'; // Default to png
}

/**
 * Extracts file extension from URL
 * @param {string} url - Image URL
 * @return {string} File extension (png, jpg, gif, etc.)
 */
function getFileExtensionFromUrl(url) {
  try {
    // Extract extension from URL
    const urlParts = url.split('.');
    const extension = urlParts[urlParts.length - 1].split(/[?#]/)[0].toLowerCase();
    
    // Validate it's an image extension
    const validExtensions = ['png', 'jpg', 'jpeg', 'gif', 'webp'];
    
    if (validExtensions.includes(extension)) {
      return extension;
    }
  } catch (e) {
    // URL parsing failed
  }
  
  return null;
}

/**
 * UPDATED: Sets up team logo in the spreadsheet (WIDENED: A9:D15 for 2x5 roster layout)
 * PHASE 2: Uses native protection bypass for secure logo operations
 * @param {Sheet} sheet - Sheet to modify
 * @param {string} logoUrl - Public Google Drive URL or direct image URL
 */
function setupTeamLogo(sheet, logoUrl) {
  try {
    if (!logoUrl || !logoUrl.trim()) {
      // No logo - set placeholder
      setupLogoPlaceholder(sheet);
      return;
    }
    
    // PHASE 2: Use native protection bypass for logo setup
    withProtectionBypass(() => {
      // UPDATED: Define the logo area using configuration constants
      const rosterConfig = BLOCK_CONFIG.LAYOUT.ROSTER;
      const logoStartRow = rosterConfig.LOGO_START_ROW;
      const logoWidth = rosterConfig.LOGO_WIDTH;
      const logoHeight = rosterConfig.LOGO_HEIGHT;
      
      // Logo area: A9:D15 (4 columns x 7 rows) to match 2x5 roster width
      const logoRange = sheet.getRange(logoStartRow, 1, logoHeight, logoWidth); // A9:D15
      
      // Merge the cells
      logoRange.merge();
      
      // Set the IMAGE formula with fitting mode 1 (fit inside, maintain aspect ratio)
      logoRange.setFormula(`=IMAGE("${logoUrl}", 1)`);
      
      // Center alignment
      logoRange.setHorizontalAlignment("center");
      logoRange.setVerticalAlignment("middle");
      
      // Optional: Add subtle border
      logoRange.setBorder(true, true, true, true, false, false, "#E0E0E0", SpreadsheetApp.BorderStyle.SOLID);
      
      Logger.log(`LogoManager: Set up team logo in A${logoStartRow}:D${logoStartRow + logoHeight - 1} with URL: ${logoUrl}`);
    }, "Setup Team Logo");
    
  } catch (e) {
    Logger.log(`LogoManager: Error setting up logo: ${e.message}`);
    // Fallback to placeholder
    setupLogoPlaceholder(sheet);
  }
}

/**
 * UPDATED: Sets up placeholder when no logo is available (WIDENED: A9:D15 for 2x5 roster layout)
 * PHASE 2: Uses native protection bypass for secure placeholder operations
 * @param {Sheet} sheet - Sheet to modify
 */
function setupLogoPlaceholder(sheet) {
  try {
    // PHASE 2: Use native protection bypass for placeholder setup
    withProtectionBypass(() => {
      // UPDATED: Use configuration constants for logo positioning
      const rosterConfig = BLOCK_CONFIG.LAYOUT.ROSTER;
      const logoStartRow = rosterConfig.LOGO_START_ROW;
      const logoWidth = rosterConfig.LOGO_WIDTH;
      const logoHeight = rosterConfig.LOGO_HEIGHT;
      
      // Logo area: A9:D15 (4 columns x 7 rows)
      const logoRange = sheet.getRange(logoStartRow, 1, logoHeight, logoWidth);
      
      logoRange.merge();
      logoRange.setValue("🏮 Team Logo");
      logoRange.setFontSize(12);
      logoRange.setFontColor("#999999");
      logoRange.setHorizontalAlignment("center");
      logoRange.setVerticalAlignment("middle");
      logoRange.setBorder(true, true, true, true, false, false, "#E0E0E0", SpreadsheetApp.BorderStyle.DASHED);
      
      Logger.log(`LogoManager: Set up logo placeholder in A${logoStartRow}:D${logoStartRow + logoHeight - 1}`);
    }, "Setup Logo Placeholder");
    
  } catch (e) {
    Logger.log(`LogoManager: Error setting up placeholder: ${e.message}`);
  }
}

/**
 * NEW: Updates team logo from URL via sidebar (with overwrite)
 * @param {string} logoUrl - URL of new logo
 * @return {boolean} Success indicator
 */
function updateTeamLogoFromUrl(logoUrl) {
  try {
    const sheet = SpreadsheetApp.getActiveSpreadsheet().getActiveSheet();
    
    // Get team name for Drive storage
    const teamName = sheet.getRange("B3").getValue() || "Unknown Team";
    
    if (logoUrl && logoUrl.trim()) {
      // Fetch and save new logo (this will overwrite existing)
      const driveUrl = fetchAndSaveTeamLogo(logoUrl, teamName);
      
      // Update spreadsheet
      setupTeamLogo(sheet, driveUrl);
      
      // Update hub with logo URL (if registered)
      updateHubLogoInfo(driveUrl);
      
      Logger.log(`LogoManager: Logo updated successfully from URL: ${logoUrl}`);
    } else {
      // Remove logo (set placeholder)
      setupTeamLogo(sheet, null);
      updateHubLogoInfo(""); // Clear logo from hub
      Logger.log(`LogoManager: Logo removed`);
    }
    
    return true;
    
  } catch (e) {
    Logger.log(`LogoManager: Error updating team logo from URL: ${e.message}`);
    throw new Error(`Error updating logo: ${e.message}`);
  }
}

/**
 * LEGACY: Updates team logo via Tools interface (kept for backward compatibility)
 * @param {string} logoUrl - URL of new logo
 * @return {boolean} Success indicator
 */
function updateTeamLogo(logoUrl) {
  try {
    return updateTeamLogoFromUrl(logoUrl);
  } catch (e) {
    SpreadsheetApp.getUi().alert(`Error updating logo: ${e.message}`);
    return false;
  }
}

/**
 * NEW: Updates the hub masterlist with logo URL information
 * @param {string} logoUrl - Public Drive URL to store in hub
 * @return {boolean} Success indicator
 */
function updateHubLogoInfo(logoUrl) {
  try {
    // Check if team is registered with hub
    const registrationStatus = checkTeamRegistration();
    if (!registrationStatus.isRegistered) {
      Logger.log("LogoManager: Team not registered with hub, skipping logo URL update");
      return false;
    }
    
    const currentSheetId = SpreadsheetApp.getActiveSpreadsheet().getId();
    
    // Open hub and update masterlist
    const hubSheet = SpreadsheetApp.openById(BLOCK_CONFIG.HUB.SPREADSHEET_ID);
    const masterlist = hubSheet.getSheetByName(BLOCK_CONFIG.HUB.MASTERLIST_SHEET);
    
    if (!masterlist) {
      Logger.log("LogoManager: Hub masterlist not found");
      return false;
    }
    
    // Find team row and update logo URL (column I = index 8)
    const teamData = masterlist.getDataRange().getValues();
    
    for (let i = 1; i < teamData.length; i++) { // Skip header row
      if (teamData[i][BLOCK_CONFIG.HUB.COLUMNS.SHEET_ID] === currentSheetId) {
        // Update logo URL in column I (index 8)
        masterlist.getRange(i + 1, 9).setValue(logoUrl || ""); // Column I = 9 (1-based)
        Logger.log(`LogoManager: Updated hub logo URL for team in row ${i + 1}: ${logoUrl}`);
        return true;
      }
    }
    
    Logger.log("LogoManager: Team not found in hub masterlist");
    return false;
    
  } catch (e) {
    Logger.log(`LogoManager: Error updating hub logo info: ${e.message}`);
    return false;
  }
}

/**
 * Debug function to test logo fetching
 * @param {string} testUrl - URL to test
 */
function debugLogoFetching(testUrl) {
  try {
    const testTeamName = "Test Team";
    Logger.log("=== Logo Fetching Debug ===");
    Logger.log("Test URL: " + testUrl);
    
    const result = fetchAndSaveTeamLogo(testUrl, testTeamName);
    Logger.log("Success! Public URL: " + result);
    
    return result;
  } catch (e) {
    Logger.log("Error: " + e.message);
    return null;
  }
}