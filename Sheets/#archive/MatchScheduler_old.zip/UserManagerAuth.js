/**
 * Schedule Manager - User Manager Auth (ENHANCED TEAM LEADERSHIP)
 * 
 * @version 1.1.0 (2025-05-24) - ENHANCED FOR 10 SLOTS + TEAM LEADERSHIP
 * 
 * Description: Authenticated user management system with team leadership features
 * ENHANCEMENTS: 10 player slots, first adopter becomes Team Leader, slot #1 reserved
 * FEATURES: Team locking, player removal, enhanced management controls
 */

// ========== ACCESS MODE MANAGEMENT ==========

/**
 * Gets the current access mode for this sheet
 * @return {string} "open_to_all" or "google_only"
 */
function getAccessMode() {
  try {
    const userProps = PropertiesService.getUserProperties();
    const mode = userProps.getProperty('access_mode');
    return mode || "google_only"; // Default to auth-only mode
  } catch (e) {
    Logger.log(`Error getting access mode: ${e.message}`);
    return "google_only"; // Safe fallback to auth mode
  }
}

/**
 * Sets the access mode for this sheet
 * @param {string} mode - "open_to_all" or "google_only"
 * @return {boolean} Success indicator
 */
function setAccessMode(mode) {
  try {
    const validModes = ["open_to_all", "google_only"];
    if (!validModes.includes(mode)) {
      throw new Error("Invalid access mode: " + mode);
    }
    
    const userProps = PropertiesService.getUserProperties();
    userProps.setProperty('access_mode', mode);
    
    Logger.log(`Access mode set to: ${mode}`);
    return true;
  } catch (e) {
    Logger.log(`Error setting access mode: ${e.message}`);
    return false;
  }
}

/**
 * Admin UI function to toggle access mode
 */
function toggleAccessModeUI() {
  const ui = SpreadsheetApp.getUi();
  
  try {
    const currentMode = getAccessMode();
    const newMode = currentMode === "open_to_all" ? "google_only" : "open_to_all";
    
    const modeDescriptions = {
      "open_to_all": "Anyone with link can edit (current system)",
      "google_only": "Google account required + user bindings"
    };
    
    const response = ui.alert(
      'Change Access Mode',
      `Current: ${modeDescriptions[currentMode]}\n\n` +
      `Change to: ${modeDescriptions[newMode]}?\n\n` +
      `Note: You can switch back anytime from the admin menu.`,
      ui.ButtonSet.YES_NO
    );
    
    if (response === ui.Button.YES) {
      const success = setAccessMode(newMode);
      if (success) {
        ui.alert(`✅ Access mode changed to: ${newMode}\n\nRefresh the sidebar to see changes.`);
      } else {
        ui.alert("❌ Failed to change access mode. Check logs for details.");
      }
    }
  } catch (e) {
    ui.alert("Error toggling access mode: " + e.message);
  }
}

// ========== GOOGLE AUTHENTICATION ==========

/**
 * Gets the current authenticated Google user
 * @return {Object|null} User object with email and info, or null if not authenticated
 */
function getCurrentAuthenticatedUser() {
  try {
    const user = Session.getActiveUser();
    const email = user.getEmail();
    
    if (!email || email.trim() === "") {
      Logger.log("No authenticated user found");
      return null;
    }
    
    return {
      email: email,
      isAuthenticated: true,
      name: email.split('@')[0] // Simple name extraction
    };
  } catch (e) {
    Logger.log(`Error getting authenticated user: ${e.message}`);
    return null;
  }
}

/**
 * Requires user to be authenticated - blocks functionality if not
 * @param {boolean} showAlert - Whether to show alert to user
 * @return {Object|null} User object if authenticated, null if blocked
 */
function requireAuthentication(showAlert = true) {
  const user = getCurrentAuthenticatedUser();
  
  if (!user) {
    if (showAlert) {
      const ui = SpreadsheetApp.getUi();
      ui.alert(
        'Google Account Required',
        'Please log into your Google account to use this feature.\n\n' +
        'This sheet requires authentication for data integrity.',
        ui.ButtonSet.OK
      );
    }
    Logger.log("Authentication required but user not logged in");
    return null;
  }
  
  Logger.log(`User authenticated: ${user.email}`);
  return user;
}

/**
 * Checks if current sheet is in authenticated mode
 * @return {boolean} True if authentication is required
 */
function isAuthenticationRequired() {
  return getAccessMode() === "google_only";
}

// ========== USER-TO-PLAYER SLOT BINDING ==========

/**
 * Gets user bindings for current sheet
 * @return {Object} User binding data
 */
function getUserBindings() {
  try {
    const userProps = PropertiesService.getUserProperties();
    const bindingsJson = userProps.getProperty('user_bindings');
    
    if (bindingsJson) {
      return JSON.parse(bindingsJson);
    }
    
    // Default structure
    return {
      teamLeader: null,
      players: {}, // email -> {slot, name, initials, claimedAt}
      kickedUsers: {} // email -> {kickedAt, kickedBy, expiresAt}
    };
  } catch (e) {
    Logger.log(`Error getting user bindings: ${e.message}`);
    return {teamLeader: null, players: {}, kickedUsers: {}};
  }
}

/**
 * Saves user bindings for current sheet
 * @param {Object} bindings - User binding data
 * @return {boolean} Success indicator
 */
function saveUserBindings(bindings) {
  try {
    const userProps = PropertiesService.getUserProperties();
    userProps.setProperty('user_bindings', JSON.stringify(bindings));
    return true;
  } catch (e) {
    Logger.log(`Error saving user bindings: ${e.message}`);
    return false;
  }
}

/**
 * ENHANCED: Claims a player slot for the current user (SUPPORTS 10 SLOTS + TEAM LEADERSHIP)
 * @param {number} slotNumber - Slot number (1-10)
 * @param {string} playerName - Player name to use
 * @return {Object} Result with success status and message
 */
function claimPlayerSlotAuth(slotNumber, playerName) {
  try {
    // Require authentication
    const user = requireAuthentication();
    if (!user) {
      return {success: false, message: "Authentication required"};
    }
    
    // Validate slot number (now supports 1-10)
    if (slotNumber < 1 || slotNumber > 10) {
      return {success: false, message: "Invalid slot number. Must be 1-10."};
    }
    
    // Check if user is in cooldown
    const cooldownCheck = checkUserCooldown(user.email);
    if (!cooldownCheck.canClaim) {
      return {
        success: false, 
        message: `You were recently removed from this team. Cooldown expires in ${cooldownCheck.remainingMinutes} minutes.`
      };
    }
    
    // Get current bindings
    const bindings = getUserBindings();
    
    // Check if this would be the first player (becomes team leader)
    const isFirstPlayer = Object.keys(bindings.players).length === 0;
    
    // Enforce Team Leader gets slot #1
    if (isFirstPlayer && slotNumber !== 1) {
      return {success: false, message: "First player must take slot #1 and becomes Team Leader"};
    }
    
    if (!isFirstPlayer && slotNumber === 1) {
      return {success: false, message: "Slot #1 is reserved for the Team Leader"};
    }
    
    // Check if slot is already taken
    for (const [email, playerData] of Object.entries(bindings.players)) {
      if (playerData.slot === slotNumber) {
        return {success: false, message: `Slot ${slotNumber} is already claimed by ${playerData.name}`};
      }
    }
    
    // Check if user already has a slot
    if (bindings.players[user.email]) {
      return {success: false, message: `You already claimed slot ${bindings.players[user.email].slot}`};
    }
    
    // Generate initials
    const initials = playerName.substring(0, 2).toUpperCase();
    
    // Check for duplicate initials
    for (const [email, playerData] of Object.entries(bindings.players)) {
      if (playerData.initials === initials) {
        return {success: false, message: `Initials "${initials}" are already taken by ${playerData.name}`};
      }
    }
    
    // Claim the slot
    bindings.players[user.email] = {
      slot: slotNumber,
      name: playerName,
      initials: initials,
      claimedAt: new Date().toISOString()
    };
    
    // Set as team leader if first player
    if (isFirstPlayer) {
      bindings.teamLeader = user.email;
      Logger.log(`${user.email} becomes Team Leader with slot 1`);
    }
    
    // Save bindings
    const saveSuccess = saveUserBindings(bindings);
    if (!saveSuccess) {
      return {success: false, message: "Failed to save user binding"};
    }
    
    // Update the actual sheet
    const sheet = SpreadsheetApp.getActiveSpreadsheet().getActiveSheet();
    const playerRow = 3 + slotNumber; // B4, B5, B6, ..., B13 (for 10 slots)
    
    sheet.getRange(playerRow, 1).setValue(initials); // Column A - initials
    sheet.getRange(playerRow, 2).setValue(playerName); // Column B - name
    
    const roleText = isFirstPlayer ? " (Team Leader)" : "";
    Logger.log(`User ${user.email} claimed slot ${slotNumber} as ${playerName} (${initials})${roleText}`);
    
    return {
      success: true, 
      message: `Successfully claimed slot ${slotNumber} as ${playerName}${roleText}`,
      data: {
        slot: slotNumber, 
        name: playerName, 
        initials: initials, 
        isLeader: isFirstPlayer
      }
    };
    
  } catch (e) {
    Logger.log(`Error claiming player slot: ${e.message}`);
    return {success: false, message: "System error: " + e.message};
  }
}

/**
 * Gets the current user's player info
 * @return {Object|null} Player data or null if not claimed
 */
function getCurrentUserPlayerInfo() {
  try {
    const user = getCurrentAuthenticatedUser();
    if (!user) return null;
    
    const bindings = getUserBindings();
    return bindings.players[user.email] || null;
  } catch (e) {
    Logger.log(`Error getting current user player info: ${e.message}`);
    return null;
  }
}

// ========== ENHANCED TEAM LEADER MANAGEMENT ==========

/**
 * Sets the team leader for current sheet
 * @param {string} email - Email of team leader
 * @return {boolean} Success indicator
 */
function setTeamLeaderAuth(email) {
  try {
    const bindings = getUserBindings();
    bindings.teamLeader = email;
    
    const success = saveUserBindings(bindings);
    if (success) {
      Logger.log(`Team leader set to: ${email}`);
    }
    return success;
  } catch (e) {
    Logger.log(`Error setting team leader: ${e.message}`);
    return false;
  }
}

/**
 * ENHANCED: Checks if current user is team leader
 * @return {boolean} True if current user is team leader
 */
function isCurrentUserTeamLeader() {
  try {
    const user = getCurrentAuthenticatedUser();
    if (!user) return false;
    
    const bindings = getUserBindings();
    return bindings.teamLeader === user.email;
  } catch (e) {
    Logger.log(`Error checking team leader status: ${e.message}`);
    return false;
  }
}

/**
 * Admin UI function to assign team leader
 */
function assignTeamLeaderUI() {
  const ui = SpreadsheetApp.getUi();
  
  try {
    const emailResponse = ui.prompt(
      'Assign Team Leader',
      'Enter email address of the team leader:',
      ui.ButtonSet.OK_CANCEL
    );
    
    if (emailResponse.getSelectedButton() === ui.Button.OK) {
      const email = emailResponse.getResponseText().trim();
      
      if (!email) {
        ui.alert("Email address cannot be empty");
        return;
      }
      
      const success = setTeamLeaderAuth(email);
      if (success) {
        ui.alert(`✅ ${email} is now team leader for this sheet!`);
      } else {
        ui.alert("❌ Failed to assign team leader. Check logs for details.");
      }
    }
  } catch (e) {
    ui.alert("Error assigning team leader: " + e.message);
  }
}

// ========== ENHANCED KICK/COOLDOWN SYSTEM ==========

/**
 * ENHANCED: Kicks a user from the team (team leader only) - SUPPORTS 10 SLOTS
 * @param {string} targetEmail - Email of user to kick
 * @param {boolean} permanent - True for permanent ban, false for temporary (1hr)
 * @return {Object} Result with success status and message
 */
function kickUserFromTeam(targetEmail, permanent = false) {
  try {
    // Check if current user is team leader
    if (!isCurrentUserTeamLeader()) {
      return {success: false, message: "Only team leaders can kick users"};
    }
    
    const user = getCurrentAuthenticatedUser();
    if (!user) {
      return {success: false, message: "Authentication required"};
    }
    
    const bindings = getUserBindings();
    
    // Check if target user exists
    if (!bindings.players[targetEmail]) {
      return {success: false, message: "User not found on this team"};
    }
    
    // Can't kick yourself
    if (targetEmail === user.email) {
      return {success: false, message: "Team leaders cannot kick themselves"};
    }
    
    const kickedPlayer = bindings.players[targetEmail];
    
    // Remove from players
    delete bindings.players[targetEmail];
    
    // Add to cooldown list (1 hour for temp, permanent for perm)
    const now = new Date();
    const expiry = permanent ? null : new Date(now.getTime() + (60 * 60 * 1000)); // 1 hour
    
    bindings.kickedUsers = bindings.kickedUsers || {};
    bindings.kickedUsers[targetEmail] = {
      kickedAt: now.toISOString(),
      kickedBy: user.email,
      expiresAt: expiry ? expiry.toISOString() : null,
      permanent: permanent,
      formerSlot: kickedPlayer.slot,
      formerName: kickedPlayer.name,
      formerInitials: kickedPlayer.initials
    };
    
    // Save bindings
    const saveSuccess = saveUserBindings(bindings);
    if (!saveSuccess) {
      return {success: false, message: "Failed to save kick data"};
    }
    
    // Clear slot in sheet (supports 10 slots now)
    const sheet = SpreadsheetApp.getActiveSpreadsheet().getActiveSheet();
    const playerRow = 3 + kickedPlayer.slot; // Supports slots 1-10
    
    sheet.getRange(playerRow, 1).setValue(""); // Clear initials
    sheet.getRange(playerRow, 2).setValue(""); // Clear name
    
    const banType = permanent ? "permanently" : "temporarily";
    Logger.log(`User ${targetEmail} (${kickedPlayer.name}) ${banType} kicked by ${user.email}`);
    
    return {
      success: true,
      message: `${kickedPlayer.name} has been ${banType} removed from the team. Slot ${kickedPlayer.slot} is now available.`
    };
    
  } catch (e) {
    Logger.log(`Error kicking user: ${e.message}`);
    return {success: false, message: "System error: " + e.message};
  }
}

/**
 * Checks if a user is in cooldown period
 * @param {string} email - User email to check
 * @return {Object} Cooldown status with canClaim and remainingMinutes
 */
function checkUserCooldown(email) {
  try {
    const bindings = getUserBindings();
    const kickData = bindings.kickedUsers ? bindings.kickedUsers[email] : null;
    
    if (!kickData) {
      return {canClaim: true, remainingMinutes: 0};
    }
    
    // Check if permanent ban
    if (kickData.permanent) {
      return {canClaim: false, remainingMinutes: 999999}; // Large number for permanent
    }
    
    const now = new Date();
    const expiry = new Date(kickData.expiresAt);
    
    if (now >= expiry) {
      // Cooldown expired, clean up
      delete bindings.kickedUsers[email];
      saveUserBindings(bindings);
      return {canClaim: true, remainingMinutes: 0};
    }
    
    const remainingMs = expiry.getTime() - now.getTime();
    const remainingMinutes = Math.ceil(remainingMs / (1000 * 60));
    
    return {canClaim: false, remainingMinutes: remainingMinutes};
    
  } catch (e) {
    Logger.log(`Error checking user cooldown: ${e.message}`);
    return {canClaim: true, remainingMinutes: 0}; // Allow on error
  }
}

/**
 * ENHANCED: Gets team roster for display (supports 10 slots)
 * @return {Object} Team roster data
 */
function getTeamRosterForLeader() {
  try {
    const bindings = getUserBindings();
    const roster = [];
    
    // Create roster with all 10 slots
    for (let slot = 1; slot <= 10; slot++) {
      const playerData = Object.values(bindings.players).find(p => p.slot === slot);
      
      if (playerData) {
        const playerEmail = Object.keys(bindings.players).find(
          email => bindings.players[email].slot === slot
        );
        
        const isLeader = (bindings.teamLeader === playerEmail);
        
        roster.push({
          slot: slot,
          name: playerData.name,
          email: playerEmail,
          initials: playerData.initials,
          claimed: true,
          claimedAt: playerData.claimedAt,
          isLeader: isLeader
        });
      } else {
        roster.push({
          slot: slot,
          name: "Available",
          email: null,
          initials: "",
          claimed: false,
          claimedAt: null,
          isLeader: false
        });
      }
    }
    
    return {
      teamLeader: bindings.teamLeader,
      players: roster,
      kickedUsers: Object.keys(bindings.kickedUsers || {}).length
    };
    
  } catch (e) {
    Logger.log(`Error getting team roster: ${e.message}`);
    return {teamLeader: null, players: [], kickedUsers: 0};
  }
}

// ========== DEBUG FUNCTIONS ==========

/**
 * Debug function to show current user bindings
 */
function debugUserBindingsAuth() {
  const ui = SpreadsheetApp.getUi();
  
  try {
    const user = getCurrentAuthenticatedUser();
    const bindings = getUserBindings();
    const accessMode = getAccessMode();
    
    let message = `🔐 AUTH SYSTEM DEBUG:\n\n`;
    message += `Access Mode: ${accessMode}\n`;
    message += `Current User: ${user ? user.email : 'Not authenticated'}\n`;
    message += `Team Leader: ${bindings.teamLeader || 'None assigned'}\n\n`;
    
    message += `CLAIMED SLOTS (10 SLOT SYSTEM):\n`;
    if (Object.keys(bindings.players).length === 0) {
      message += `  No claimed slots\n`;
    } else {
      for (const [email, playerData] of Object.entries(bindings.players)) {
        const leaderTag = (email === bindings.teamLeader) ? " 👑" : "";
        message += `  Slot ${playerData.slot}: ${playerData.name} (${email})${leaderTag}\n`;
      }
    }
    
    message += `\nKICKED USERS: ${Object.keys(bindings.kickedUsers || {}).length}\n`;
    
    ui.alert("Enhanced Auth System Debug", message, ui.ButtonSet.OK);
    
  } catch (e) {
    ui.alert("Debug error: " + e.message);
  }
}

/**
 * Debug function to reset all user bindings (admin only)
 */
function resetUserBindingsAuth() {
  const ui = SpreadsheetApp.getUi();
  
  const response = ui.alert(
    'Reset User Bindings',
    'This will remove all user-to-player bindings and team leader assignments.\n\nContinue?',
    ui.ButtonSet.YES_NO
  );
  
  if (response === ui.Button.YES) {
    try {
      const emptyBindings = {teamLeader: null, players: {}, kickedUsers: {}};
      const success = saveUserBindings(emptyBindings);
      
      if (success) {
        ui.alert("✅ All user bindings have been reset.");
      } else {
        ui.alert("❌ Failed to reset user bindings.");
      }
    } catch (e) {
      ui.alert("Error resetting bindings: " + e.message);
    }
  }
}