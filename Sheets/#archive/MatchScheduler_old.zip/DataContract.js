/**
 * Schedule Manager - Data Contract Foundation
 * 
 * @version 1.1.0 (Phase 1 - Single Source Consolidation)
 * 
 * Description: Canonical data contract and validation for hub-team exchange
 * UPDATED: Eliminated dual data paths - SlotManager is now the ONLY data source
 * ARCHITECTURE: Properties-first, display-secondary design pattern
 */

// ========== CANONICAL DATA CONTRACT ==========

/**
 * Canonical Team Data Contract v1.0
 * Single source of truth that prevents masterlist/availability corruption
 */
const TEAM_DATA_CONTRACT_V1 = {
  // IDENTITY (Immutable)
  sheetId: "string",              // Primary key - never changes
  contractVersion: "1.0.0",       // For future migrations
  
  // METADATA (Mutable but tracked)
  teamName: "string",             // Can change safely
  teamLeader: "email",            // Google account (slot-based teams)
  division: "string",             // Can change safely
  teamType: "slot_based",         // FIXED: Always slot_based now
  
  // TEMPORAL DATA (Critical for sync)
  timestamp: "ISO8601",           // Last modification time
  version: "number",              // Incremental version for conflict detection
  weekAlignment: "number",        // Current week number for validation
  
  // PLAYER DATA (Unified format)
  players: [
    {
      slotNumber: "number",       // Position (1-10)
      adoptedBy: "email",         // Google account (auth tracking)
      playerName: "string",       // Display name
      initials: "string",         // 2-char initials
      status: "adopted|available|leader_managed",
      adoptedAt: "ISO8601"        // Timestamp for auditing
    }
  ],
  
  // SCHEDULE DATA (Atomic with metadata)
  weeks: [
    {
      weekNumber: "number",       // ISO week number
      startDate: "YYYY-MM-DD",    // Monday of week
      month: "string",            // Month name
      dayHeaders: ["string"],     // Day names
      timeSlots: ["string"],      // Time labels
      availability: {
        grid: [["string"]]        // 2D array of availability data
      }
    }
  ],
  
  // SYNC METADATA
  syncMetadata: {
    lastSuccessfulSync: "ISO8601",
    syncAttempts: "number",
    conflictsDetected: "number",
    rolloverStatus: "current|behind|ahead"
  }
};

// ========== VALIDATION FUNCTIONS ==========

/**
 * Validates team data against canonical contract
 * @param {Object} teamData - Data to validate
 * @return {Object} Validation result
 */
function validateTeamDataContract(teamData) {
  const errors = [];
  const warnings = [];
  
  try {
    // REQUIRED FIELDS
    if (!teamData.sheetId || typeof teamData.sheetId !== 'string') {
      errors.push("Missing or invalid sheetId");
    }
    
    if (!teamData.teamName || typeof teamData.teamName !== 'string') {
      errors.push("Missing or invalid teamName");
    }
    
    if (!teamData.timestamp || !isValidISO8601(teamData.timestamp)) {
      errors.push("Missing or invalid timestamp");
    }
    
    if (typeof teamData.version !== 'number' || teamData.version < 1) {
      errors.push("Missing or invalid version number");
    }
    
    // TEAM TYPE VALIDATION - Now always slot_based
    if (teamData.teamType !== 'slot_based') {
      warnings.push("Team type should be 'slot_based' - all teams use slot system now");
    }
    
    // PLAYER DATA VALIDATION
    if (!Array.isArray(teamData.players)) {
      errors.push("Players must be an array");
    } else {
      teamData.players.forEach((player, index) => {
        if (!player.playerName || typeof player.playerName !== 'string') {
          errors.push(`Player ${index + 1}: Missing or invalid playerName`);
        }
        
        if (!player.initials || typeof player.initials !== 'string' || player.initials.length !== 2) {
          errors.push(`Player ${index + 1}: Invalid initials (must be 2 characters)`);
        }
        
        if (typeof player.slotNumber !== 'number' || player.slotNumber < 1 || player.slotNumber > 10) {
          errors.push(`Player ${index + 1}: Invalid slotNumber (must be 1-10)`);
        }
        
        if (!player.adoptedBy || !isValidEmail(player.adoptedBy)) {
          errors.push(`Player ${index + 1}: Invalid adoptedBy email - all slots require adoption`);
        }
      });
    }
    
    // WEEK DATA VALIDATION
    if (!Array.isArray(teamData.weeks)) {
      errors.push("Weeks must be an array");
    } else if (teamData.weeks.length === 0) {
      errors.push("At least one week is required");
    } else {
      teamData.weeks.forEach((week, index) => {
        if (typeof week.weekNumber !== 'number' || week.weekNumber < 1 || week.weekNumber > 53) {
          errors.push(`Week ${index + 1}: Invalid weekNumber`);
        }
        
        if (!week.startDate || !isValidDateFormat(week.startDate)) {
          errors.push(`Week ${index + 1}: Invalid startDate format (YYYY-MM-DD required)`);
        }
        
        if (!week.availability || !Array.isArray(week.availability.grid)) {
          errors.push(`Week ${index + 1}: Invalid availability grid`);
        }
      });
    }
    
    // WEEK ALIGNMENT VALIDATION (Critical for rollover system) 
    const currentWeek = getCurrentWeekNumber();
    const nextWeek = currentWeek + 1;
    const weekNumbers = teamData.weeks.map(w => w.weekNumber);
    
    if (!weekNumbers.includes(currentWeek) && !weekNumbers.includes(nextWeek)) {
      warnings.push(`No current or next week data (current: ${currentWeek}, next: ${nextWeek})`);
    }
    
    return {
      isValid: errors.length === 0,
      errors: errors,
      warnings: warnings,
      contractVersion: "1.0.0"
    };
    
  } catch (e) {
    return {
      isValid: false,
      errors: [`Validation error: ${e.message}`],
      warnings: [],
      contractVersion: "1.0.0"
    };
  }
}

/**
 * Builds atomic team data from SlotManager properties (SINGLE SOURCE)
 * UPDATED: Eliminates dual data paths - always uses SlotManager properties
 * @return {Object} Canonical team data
 */
function buildAtomicTeamData() {
  try {
    const ss = SpreadsheetApp.getActiveSpreadsheet();
    const sheetId = ss.getId();
    
    // SINGLE SOURCE: Always get data from SlotManager properties
    const slotData = getSlotData();
    const adoptedPlayers = getAdoptedPlayers();
    
    // Get team metadata from SlotManager (fallback to sheet if not in properties)
    let teamName = slotData.teamName;
    if (!teamName || teamName.trim() === "") {
      // Fallback to sheet only if SlotManager has no team name
      const sheet = ss.getActiveSheet();
      teamName = sheet.getRange("B3").getValue() || "Unknown Team";
    }
    
    // Build player data from SlotManager ONLY
    const players = [];
    adoptedPlayers.forEach(player => {
      players.push({
        slotNumber: player.slotNumber,
        adoptedBy: player.adoptedBy,
        playerName: player.playerName,
        initials: player.initials,
        status: player.status || "adopted",
        adoptedAt: player.adoptedAt || new Date().toISOString()
      });
    });
    
    // Get week data from schedule blocks
    const blocks = findAllBlocks();
    const weeks = [];
    
    blocks.forEach(block => {
      const sheet = ss.getActiveSheet();
      const weekData = collectWeekData(sheet, block);
      if (weekData) {
        weeks.push({
          weekNumber: block.weekNumber,
          startDate: calculateMondayFromWeekNumber(block.weekNumber).toISOString().split('T')[0],
          month: weekData.month,
          dayHeaders: weekData.dayHeaders,
          timeSlots: weekData.timeSlots,
          availability: {
            grid: weekData.grid
          }
        });
      }
    });
    
    // Get current version (increment from stored value)
    const currentVersion = getCurrentDataVersion();
    const newVersion = currentVersion + 1;
    
    // Store new version
    setCurrentDataVersion(newVersion);
    
    // Build canonical data structure (ALWAYS slot-based now)
    const atomicData = {
      // Identity
      sheetId: sheetId,
      contractVersion: "1.0.0",
      
      // Metadata
      teamName: teamName,
      teamLeader: slotData.teamLeader || Session.getActiveUser().getEmail(),
      division: slotData.division || "Division 1",
      teamType: "slot_based", // FIXED: Always slot-based
      
      // Temporal
      timestamp: new Date().toISOString(),
      version: newVersion,
      weekAlignment: getCurrentWeekNumber(),
      
      // Data
      players: players,
      weeks: weeks,
      
      // Sync metadata
      syncMetadata: {
        lastSuccessfulSync: getLastSuccessfulSync(),
        syncAttempts: getSyncAttempts(),
        conflictsDetected: getConflictsDetected(),
        rolloverStatus: calculateRolloverStatus(weeks)
      }
    };
    
    Logger.log(`DataContract: Built atomic data for ${teamName} (version ${newVersion}) - Single source from SlotManager`);
    return atomicData;
    
  } catch (e) {
    Logger.log(`DataContract: Error building atomic data: ${e.message}`);
    throw new Error(`Failed to build atomic team data: ${e.message}`);
  }
}

/**
 * Compresses team data for efficient hub storage
 * @param {Object} teamData - Full team data
 * @return {Object} Compressed data for hub
 */
function compressForHubStorage(teamData) {
  // Keep full data structure but compress availability grid if needed
  const compressed = { ...teamData };
  
  // Compress availability grid (convert to string if very large)
  compressed.weeks.forEach(week => {
    const gridSize = JSON.stringify(week.availability.grid).length;
    if (gridSize > 5000) { // If over 5KB, compress
      week.availability.compressed = true;
      week.availability.gridCompressed = compressAvailabilityGrid(week.availability.grid);
      delete week.availability.grid;
    }
  });
  
  return compressed;
}

/**
 * Decompresses team data from hub storage
 * @param {Object} compressedData - Compressed team data
 * @return {Object} Full team data
 */
function decompressFromHubStorage(compressedData) {
  const decompressed = { ...compressedData };
  
  // Decompress availability grids if compressed
  decompressed.weeks.forEach(week => {
    if (week.availability.compressed) {
      week.availability.grid = decompressAvailabilityGrid(week.availability.gridCompressed);
      delete week.availability.compressed;
      delete week.availability.gridCompressed;
    }
  });
  
  return decompressed;
}

// ========== UTILITY FUNCTIONS ==========

/**
 * Validates ISO8601 timestamp format
 */
function isValidISO8601(timestamp) {
  try {
    const date = new Date(timestamp);
    return date.toISOString() === timestamp;
  } catch (e) {
    return false;
  }
}

/**
 * Validates email format
 */
function isValidEmail(email) {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

/**
 * Validates YYYY-MM-DD date format
 */
function isValidDateFormat(dateString) {
  const dateRegex = /^\d{4}-\d{2}-\d{2}$/;
  if (!dateRegex.test(dateString)) return false;
  
  const date = new Date(dateString);
  return date.toISOString().split('T')[0] === dateString;
}

/**
 * Gets current data version from properties
 */
function getCurrentDataVersion() {
  try {
    const props = PropertiesService.getDocumentProperties();
    const version = props.getProperty('dataVersion');
    return version ? parseInt(version) : 0;
  } catch (e) {
    return 0;
  }
}

/**
 * Sets current data version in properties
 */
function setCurrentDataVersion(version) {
  try {
    const props = PropertiesService.getDocumentProperties();
    props.setProperty('dataVersion', version.toString());
  } catch (e) {
    Logger.log(`Error setting data version: ${e.message}`);
  }
}

/**
 * Calculates rollover status based on week data
 */
function calculateRolloverStatus(weeks) {
  const currentWeek = getCurrentWeekNumber();
  const weekNumbers = weeks.map(w => w.weekNumber);
  
  if (weekNumbers.includes(currentWeek)) {
    return "current";
  } else if (Math.max(...weekNumbers) < currentWeek) {
    return "behind";
  } else {
    return "ahead";
  }
}

/**
 * Gets last successful sync timestamp
 */
function getLastSuccessfulSync() {
  try {
    const props = PropertiesService.getDocumentProperties();
    return props.getProperty('lastSuccessfulSync') || null;
  } catch (e) {
    return null;
  }
}

/**
 * Gets sync attempt count
 */
function getSyncAttempts() {
  try {
    const props = PropertiesService.getDocumentProperties();
    const attempts = props.getProperty('syncAttempts');
    return attempts ? parseInt(attempts) : 0;
  } catch (e) {
    return 0;
  }
}

/**
 * Gets conflicts detected count
 */
function getConflictsDetected() {
  try {
    const props = PropertiesService.getDocumentProperties();
    const conflicts = props.getProperty('conflictsDetected');
    return conflicts ? parseInt(conflicts) : 0;
  } catch (e) {
    return 0;
  }
}

// ========== DATAEXCHANGE INTEGRATION ==========

/**
 * Validates incoming team data from hub (for DataExchange.js integration)
 * @param {Object} incomingTeamData - Data received from hub
 * @return {Object} Validation result for display
 */
function validateIncomingTeamData(incomingTeamData) {
  try {
    // Use same validation as outbound data for consistency
    const validation = validateTeamDataContract(incomingTeamData);
    
    // Add specific checks for display purposes
    if (!incomingTeamData.weeks || incomingTeamData.weeks.length === 0) {
      validation.warnings.push("No availability data to display");
    }
    
    // Check if data is current for display
    const currentWeek = getCurrentWeekNumber();
    const weekNumbers = incomingTeamData.weeks?.map(w => w.weekNumber) || [];
    
    if (!weekNumbers.includes(currentWeek) && !weekNumbers.includes(currentWeek + 1)) {
      validation.warnings.push("Team data may be outdated for current viewing");
    }
    
    return {
      ...validation,
      displayRecommendation: validation.isValid ? "safe_to_display" : "display_with_warnings"
    };
    
  } catch (e) {
    return {
      isValid: false,
      errors: [`Incoming data validation failed: ${e.message}`],
      displayRecommendation: "do_not_display"
    };
  }
}

/**
 * Normalizes incoming team data to standard format for display
 * Ensures DataExchange.js receives consistent data structure
 * @param {Object} rawHubData - Raw data from hub
 * @return {Object} Normalized data for display
 */
function normalizeForDisplay(rawHubData) {
  try {
    // If data is already in contract format, return as-is
    if (rawHubData.contractVersion === "1.0.0") {
      return rawHubData;
    }
    
    // Convert legacy format to contract format
    const normalized = {
      sheetId: rawHubData.sheetId || "",
      contractVersion: "1.0.0",
      teamName: rawHubData.teamName || "Unknown Team",
      teamType: "slot_based", // FIXED: Always slot-based now
      timestamp: rawHubData.timestamp || new Date().toISOString(),
      version: rawHubData.version || 1,
      
      // Convert player format
      players: (rawHubData.players || []).map((player, index) => ({
        slotNumber: index + 1,
        playerName: typeof player === 'string' ? player : player.name || player.playerName,
        initials: typeof player === 'string' ? player.substring(0, 2).toUpperCase() : 
                 (player.initials || player.initial || player.playerName?.substring(0, 2).toUpperCase()),
        status: "display_only"
      })),
      
      // Preserve week data
      weeks: rawHubData.weeks || [],
      
      // Add display metadata
      syncMetadata: {
        displayMode: true,
        originalFormat: "legacy",
        normalizedAt: new Date().toISOString()
      }
    };
    
    return normalized;
    
  } catch (e) {
    Logger.log(`Error normalizing data for display: ${e.message}`);
    return rawHubData; // Return original if normalization fails
  }
}

// ========== TESTING FUNCTIONS ==========

/**
 * Debug function to test data contract validation
 */
function debugTestDataContract() {
  try {
    Logger.log("=== DATA CONTRACT VALIDATION TEST (Single Source) ===");
    
    // Build atomic data
    const atomicData = buildAtomicTeamData();
    Logger.log("Atomic data built successfully from SlotManager properties");
    
    // Validate against contract
    const validation = validateTeamDataContract(atomicData);
    Logger.log(`Validation result: ${validation.isValid ? 'PASS' : 'FAIL'}`);
    
    if (validation.errors.length > 0) {
      Logger.log("Errors:");
      validation.errors.forEach(error => Logger.log(`  - ${error}`));
    }
    
    if (validation.warnings.length > 0) {
      Logger.log("Warnings:");
      validation.warnings.forEach(warning => Logger.log(`  - ${warning}`));
    }
    
    Logger.log("Data structure:");
    Logger.log(JSON.stringify(atomicData, null, 2));
    
    return validation;
    
  } catch (e) {
    Logger.log(`Test error: ${e.message}`);
    return { isValid: false, errors: [e.message] };
  }
}

/**
 * Test integration between DataContract and DataExchange
 */
function debugTestDataExchangeIntegration() {
  try {
    Logger.log("=== DATACONTRACT <-> DATAEXCHANGE INTEGRATION TEST (Single Source) ===");
    
    // Test 1: Build outbound data
    const outboundData = buildAtomicTeamData();
    Logger.log(`✓ Outbound data built (version ${outboundData.version}) from SlotManager only`);
    
    // Test 2: Simulate hub storage and retrieval
    const compressedData = compressForHubStorage(outboundData);
    const retrievedData = decompressFromHubStorage(compressedData);
    Logger.log(`✓ Hub storage simulation complete`);
    
    // Test 3: Validate incoming data for display
    const incomingValidation = validateIncomingTeamData(retrievedData);
    Logger.log(`✓ Incoming validation: ${incomingValidation.displayRecommendation}`);
    
    // Test 4: Normalize for display
    const normalizedData = normalizeForDisplay(retrievedData);
    Logger.log(`✓ Data normalized for display`);
    
    // Test 5: Legacy format compatibility
    const legacyData = {
      teamName: "Legacy Team",
      players: ["Player 1", "Player 2", "Player 3"],
      weeks: [{ weekNumber: 42, availability: { grid: [["A", "B"]] } }]
    };
    
    const normalizedLegacy = normalizeForDisplay(legacyData);
    Logger.log(`✓ Legacy format conversion complete`);
    
    return {
      outboundValid: validateTeamDataContract(outboundData).isValid,
      incomingValid: incomingValidation.isValid,
      storageIntegrity: JSON.stringify(outboundData) === JSON.stringify(retrievedData),
      legacyCompatible: normalizedLegacy.contractVersion === "1.0.0",
      singleSource: true // New flag indicating single source implementation
    };
    
  } catch (e) {
    Logger.log(`Integration test error: ${e.message}`);
    return { error: e.message };
  }
}