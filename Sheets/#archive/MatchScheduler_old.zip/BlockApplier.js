/**
 * Schedule Manager - Block Applier (PHASE 2: NATIVE PROTECTION INTEGRATED)
 * 
 * @version 1.1.0 (2025-05-25) - PHASE 2 COMPLETE - NATIVE PROTECTION BYPASS
 * 
 * Description: Applies coloring and formatting to blocks with native protection bypass
 * PHASE 2: Integrated with native protection system for secure color operations
 * OPTIMIZED: All color functions use protection bypass for rows 1-17
 */

/**
 * Applies availability coloring to all blocks in the sheet
 * PHASE 2: Uses native protection bypass for secure color operations
 * @param {Boolean} showConfirmation - Whether to show confirmation dialog
 * @return {Boolean} Success indicator
 */
function applyColorToAllBlocks(showConfirmation = false) {
  try {
    const blocks = findAllBlocks();
    
    if (blocks.length === 0) {
      if (showConfirmation) {
        SpreadsheetApp.getUi().alert("No week blocks found to color.");
      }
      return false;
    }
    
    // PHASE 2: Use native protection bypass for all color operations
    const result = withProtectionBypass(() => {
      const sheet = SpreadsheetApp.getActiveSpreadsheet().getActiveSheet();
      let blocksColored = 0;
      
      // Apply colors to each block
      for (const block of blocks) {
        if (applyColorsToBlock(sheet, block)) {
          blocksColored++;
        }
      }
      
      // Ensure team info area has correct colors after block coloring
      preserveTeamInfoColors(sheet);
      
      return blocksColored;
    }, "Apply Colors to All Blocks");
    
    Logger.log(`Applied colors to ${result} blocks`);
    
    if (showConfirmation) {
      SpreadsheetApp.getUi().alert(`Colors applied to ${result} week blocks.`);
    }
    
    return result > 0;
  } catch (e) {
    Logger.log(`Error applying colors: ${e.message}`);
    
    if (showConfirmation) {
      SpreadsheetApp.getUi().alert(`Error applying colors: ${e.message}`);
    }
    
    return false;
  }
}

/**
 * Preserves the team info area colors after block coloring
 * PHASE 2: This function is called within protection bypass context
 * @param {Sheet} sheet - The sheet to modify
 */
function preserveTeamInfoColors(sheet) {
  try {
    // NOTE: This function is called from within withProtectionBypass()
    // so it can safely modify protected cells
    
    // Preserve A3 (Team header)
    sheet.getRange("A3").setBackground(BLOCK_CONFIG.COLORS.TEAM_HEADER);
    
    // Preserve B3 (Team name)
    sheet.getRange("B3").setBackground(BLOCK_CONFIG.COLORS.TEAM_NAME);
    
    // Preserve player slots (A4-A8, B4-B8, C4-C8, D4-D8) - all 10 slots
    const maxPlayers = BLOCK_CONFIG.LAYOUT.MAX_PLAYERS;
    for (let i = 1; i <= maxPlayers; i++) {
      const position = getSlotPosition(i);
      sheet.getRange(position.row, position.initialsCol).setBackground(BLOCK_CONFIG.COLORS.PLAYER_INITIALS);
      sheet.getRange(position.row, position.nameCol).setBackground(BLOCK_CONFIG.COLORS.PLAYER_NAMES);
    }
    
  } catch (e) {
    Logger.log(`Error preserving team info colors: ${e.message}`);
  }
}

/**
 * Applies colors to a specific block based on availability
 * @param {Sheet} sheet - Sheet containing the block
 * @param {Object} block - Block metadata
 * @return {Boolean} Success indicator
 */
function applyColorsToBlock(sheet, block) {
  try {
    // Validate essential block properties
    if (!block || !block.row || !block.col || !block.timeStartRow || !block.gridHeight) {
      Logger.log("Invalid block metadata, cannot apply colors");
      return false;
    }
    
    // 1. Ensure day headers have proper coloring
    sheet.getRange(block.dayHeadersRow, block.col, 1, block.gridWidth)
         .setBackground(BLOCK_CONFIG.COLORS.DAY_HEADER);
    
    // 2. Ensure time column has proper coloring
    sheet.getRange(block.timeStartRow, block.timeCol, block.gridHeight, 1)
         .setBackground(BLOCK_CONFIG.COLORS.TIME_COLUMN);
    
    // 3. Get all grid values at once
    const gridRange = sheet.getRange(
      block.timeStartRow,
      block.col,
      block.gridHeight,
      block.gridWidth
    );
    
    const gridValues = gridRange.getValues();
    const backgrounds = [];
    
    // 4. Process each cell in the grid
    for (let r = 0; r < gridValues.length; r++) {
      const rowBackgrounds = [];
      
      for (let c = 0; c < gridValues[r].length; c++) {
        const cellValue = String(gridValues[r][c]);
        const isWeekend = (c >= 5); // Saturday or Sunday
        
        // Count initials in the cell - split by commas and spaces
        const entries = cellValue ? cellValue.split(/[,\s]+/).filter(e => e.trim()) : [];
        const count = entries.length;
        
        // Determine background color based on player count
        let bgColor;
        if (count === 0) {
          // Empty cell - use weekend or weekday background
          bgColor = isWeekend ? BLOCK_CONFIG.COLORS.WEEKEND : BLOCK_CONFIG.COLORS.WEEKDAY;
        } else if (count === 1) {
          // 1 player - red
          bgColor = BLOCK_CONFIG.COLORS.ONE_PLAYER;
        } else if (count <= 3) {
          // 2-3 players - yellow
          bgColor = BLOCK_CONFIG.COLORS.TWO_TO_THREE;
        } else {
          // 4+ players - green
          bgColor = BLOCK_CONFIG.COLORS.FOUR_PLUS;
        }
        
        rowBackgrounds.push(bgColor);
      }
      
      backgrounds.push(rowBackgrounds);
    }
    
    // 5. Apply all backgrounds at once for efficiency
    gridRange.setBackgrounds(backgrounds);
    
    return true;
  } catch (e) {
    Logger.log(`Error applying colors to block: ${e.message}`);
    return false;
  }
}

/**
 * Manually updates colors via menu command (streamlined - no unnecessary confirmations)
 */
function updateColorsManually() {
  applyColorToAllBlocks(false); // No confirmations = faster execution, no UI context conflicts
}

/**
 * Applies colors directly to selected cells based on content
 * PHASE 2: Uses native protection bypass for secure color operations
 * @param {Range} selectedRange - The range of selected cells
 * @return {Boolean} Success indicator
 */
function applyColorsToSelectedRange(selectedRange) {
  if (!selectedRange) return false;
  
  try {
    // PHASE 2: Use native protection bypass for color operations
    return withProtectionBypass(() => {
      const sheet = selectedRange.getSheet();
      const startRow = selectedRange.getRow();
      const startCol = selectedRange.getColumn();
      const numRows = selectedRange.getNumRows();
      const numCols = selectedRange.getNumColumns();
      const values = selectedRange.getValues();
      
      // Process each cell in the selection
      for (let r = 0; r < numRows; r++) {
        for (let c = 0; c < numCols; c++) {
          const cellRow = startRow + r;
          const cellCol = startCol + c;
          const cellValue = String(values[r][c]);
          
          // Skip if cell is in team info area (A3:D8) - preserve existing colors
          if (cellCol <= 4 && cellRow >= 3 && cellRow <= 8) {
            continue;
          }
          
          // Skip if cell is not in a valid grid area
          if (!isInValidBlockGrid(cellRow, cellCol)) {
            continue;
          }
          
          // Skip if cell contains time or header
          if (cellValue.match(/^\d{1,2}:\d{2}$/) || 
              cellValue.match(/^(mon|tue|wed|thu|fri|sat|sun)\s+\d+/i) ||
              cellValue.match(/^week\s+\d+/i) ||
              cellValue.match(/^(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)/i)) {
            continue;
          }
          
          // Count initials
          const entries = cellValue ? cellValue.split(/[,\s]+/).filter(e => e.trim()) : [];
          const count = entries.length;
          
          // Determine background color
          let bgColor;
          if (count === 0) {
            // For empty cells, determine if it's a weekend
            const isWeekend = isInWeekendColumn(cellCol);
            bgColor = isWeekend ? BLOCK_CONFIG.COLORS.WEEKEND : BLOCK_CONFIG.COLORS.WEEKDAY;
          } else if (count === 1) {
            bgColor = BLOCK_CONFIG.COLORS.ONE_PLAYER;
          } else if (count <= 3) {
            bgColor = BLOCK_CONFIG.COLORS.TWO_TO_THREE;
          } else {
            bgColor = BLOCK_CONFIG.COLORS.FOUR_PLUS;
          }
          
          // Apply color to this cell
          sheet.getRange(cellRow, cellCol).setBackground(bgColor);
        }
      }
      
      return true;
    }, "Apply Colors to Selected Range");
    
  } catch (e) {
    Logger.log(`Error applying colors to selection: ${e.message}`);
    return false;
  }
}

/**
 * Determines if a cell is in a weekend column (Sat or Sun)
 * @param {Number} row - 1-based row index
 * @param {Number} col - 1-based column index
 * @return {Boolean} Whether the cell is in a weekend column
 */
function isWeekendCell(row, col) {
  // Get all blocks to determine weekend columns
  const blocks = findAllBlocks();
  
  for (const block of blocks) {
    // Check if cell is in this block's grid
    if (row >= block.timeStartRow && 
        row < block.timeStartRow + block.gridHeight) {
      
      // Check if column is in the last two days (Sat, Sun)
      const blockStartCol = block.col;
      const relativeCol = col - blockStartCol;
      
      // Columns 5 and 6 (0-based) in the grid are weekend days
      return relativeCol === 5 || relativeCol === 6;
    }
  }
  
  // Default to false if not in any block
  return false;
}