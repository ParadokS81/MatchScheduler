/**
 * Schedule Manager - CET Time Manager (CLEAN VERSION - FIXED)
 * 
 * @version 2.0.1 (Fixed ISO Week Bug)
 * 
 * Description: Clean CET timezone utilities - 50 lines instead of 400
 * Maintains all functions needed by RollerSystem.js
 * Removes 350+ lines of debug bloat
 * 
 * BUG FIX: Corrected getCurrentWeekNumberCET() to use proper ISO week calculation
 */

// ========== CORE CET FUNCTIONS ==========

/**
 * Gets current time in CET timezone (auto-handles DST)
 * @return {Date} Current CET time
 */
function getCurrentCETTime() {
  return new Date(new Date().toLocaleString("en-US", {timeZone: "Europe/Berlin"}));
}

/**
 * FIXED: Gets current ISO week number in CET timezone using proper ISO week calculation
 * @return {number} Current week number (1-53)
 */
function getCurrentWeekNumberCET() {
  const cetTime = getCurrentCETTime();
  
  // Proper ISO week calculation
  // ISO week 1 is the first week that contains January 4th
  // Weeks start on Monday (Monday = 1, Sunday = 7)
  
  const year = cetTime.getFullYear();
  const month = cetTime.getMonth();
  const date = cetTime.getDate();
  
  // Create a date object for the current date
  const currentDate = new Date(year, month, date);
  
  // Find January 4th of the current year (always in week 1)
  const jan4 = new Date(year, 0, 4);
  
  // Find the Monday of week 1 (the week containing Jan 4th)
  const jan4DayOfWeek = (jan4.getDay() || 7); // Convert Sunday=0 to Sunday=7
  const mondayOfWeek1 = new Date(jan4.getTime() - (jan4DayOfWeek - 1) * 24 * 60 * 60 * 1000);
  
  // Calculate days difference between current date and Monday of week 1
  const daysDiff = Math.floor((currentDate.getTime() - mondayOfWeek1.getTime()) / (24 * 60 * 60 * 1000));
  
  // Calculate week number
  const weekNumber = Math.floor(daysDiff / 7) + 1;
  
  // Handle edge case: if we get week 0 or negative, it belongs to previous year
  if (weekNumber < 1) {
    // This date belongs to the last week of the previous year
    return getLastWeekOfYear(year - 1);
  }
  
  // Handle edge case: if we get week > 52/53, it might belong to next year
  if (weekNumber > 52) {
    // Check if this is actually week 1 of next year
    const jan4NextYear = new Date(year + 1, 0, 4);
    const jan4NextYearDayOfWeek = (jan4NextYear.getDay() || 7);
    const mondayOfWeek1NextYear = new Date(jan4NextYear.getTime() - (jan4NextYearDayOfWeek - 1) * 24 * 60 * 60 * 1000);
    
    if (currentDate.getTime() >= mondayOfWeek1NextYear.getTime()) {
      return 1; // This is actually week 1 of next year
    }
  }
  
  return weekNumber;
}

/**
 * Helper function to get the last week number of a given year
 * @param {number} year - The year
 * @return {number} Last week number (52 or 53)
 */
function getLastWeekOfYear(year) {
  // December 28th is always in the last week of the year
  const dec28 = new Date(year, 11, 28);
  return getWeekNumberForDate(dec28);
}

/**
 * Helper function to get week number for a specific date
 * @param {Date} date - The date
 * @return {number} Week number
 */
function getWeekNumberForDate(date) {
  const year = date.getFullYear();
  const jan4 = new Date(year, 0, 4);
  const jan4DayOfWeek = (jan4.getDay() || 7);
  const mondayOfWeek1 = new Date(jan4.getTime() - (jan4DayOfWeek - 1) * 24 * 60 * 60 * 1000);
  const daysDiff = Math.floor((date.getTime() - mondayOfWeek1.getTime()) / (24 * 60 * 60 * 1000));
  return Math.floor(daysDiff / 7) + 1;
}

// ========== ROLLOVER TIMING FUNCTIONS ==========

/**
 * Checks if we're currently in a rollover window
 * Used by RollerSystem.js for auto-rollover logic
 * @param {number} windowMinutes - Minutes after rollover time to consider "window"
 * @return {Object} Rollover window status
 */
function isRolloverWindowCET(windowMinutes = 30) {
  const cetNow = getCurrentCETTime();
  const isMonday = cetNow.getDay() === 1;
  const hour = cetNow.getHours();
  const minute = cetNow.getMinutes();
  
  // Primary rollover window: Monday 00:01-01:00
  const isPrimaryWindow = isMonday && hour === 0 && minute >= 1;
  
  // Failover rollover window: Monday 06:00-07:00  
  const isFailoverWindow = isMonday && hour === 6;
  
  let rolloverType = null;
  let inWindow = false;
  let minutesFromRollover = null;
  
  if (isPrimaryWindow) {
    rolloverType = 'primary';
    inWindow = true;
    minutesFromRollover = minute - 1; // Minutes since 00:01
  } else if (isFailoverWindow) {
    rolloverType = 'failover';
    inWindow = true;
    minutesFromRollover = minute; // Minutes since 06:00
  }
  
  return {
    inWindow: inWindow,
    rolloverType: rolloverType,
    minutesFromRollover: minutesFromRollover
  };
}

// ========== WEEK CALCULATION FUNCTIONS ==========

/**
 * Calculates Monday date from week number in CET timezone
 * Used by RollerSystem.js for rollover calculations
 * @param {number} weekNumber - ISO week number
 * @param {number} year - Year (optional, defaults to current)
 * @return {Date} Monday date in CET
 */
function calculateMondayFromWeekNumberCET(weekNumber, year = null) {
  const targetYear = year || getCurrentCETTime().getFullYear();
  
  // Find January 4th (always in week 1)
  const jan4 = new Date(targetYear, 0, 4);
  
  // Find Monday of week 1
  const jan4Day = (jan4.getDay() || 7) - 1; // Convert to 0=Monday, 6=Sunday
  const week1Monday = new Date(jan4.getTime() - (jan4Day * 24 * 60 * 60 * 1000));
  
  // Calculate target Monday
  const targetMonday = new Date(week1Monday.getTime() + ((weekNumber - 1) * 7 * 24 * 60 * 60 * 1000));
  
  return targetMonday;
}

// ========== BACKWARD COMPATIBILITY ==========

/**
 * Backward compatibility function for any legacy code
 * @return {number} Current week number in CET
 */
function getCurrentWeekNumber() {
  return getCurrentWeekNumberCET();
}

// ========== DEBUG FUNCTIONS ==========

/**
 * Debug function to verify week calculation
 * @return {Object} Debug information about current week
 */
function debugWeekCalculation() {
  const cetTime = getCurrentCETTime();
  const weekNumber = getCurrentWeekNumberCET();
  const mondayOfCurrentWeek = calculateMondayFromWeekNumberCET(weekNumber);
  const sundayOfCurrentWeek = new Date(mondayOfCurrentWeek.getTime() + (6 * 24 * 60 * 60 * 1000));
  
  return {
    currentCETTime: cetTime,
    calculatedWeekNumber: weekNumber,
    mondayOfWeek: mondayOfCurrentWeek,
    sundayOfWeek: sundayOfCurrentWeek,
    isCurrentDateInWeek: cetTime >= mondayOfCurrentWeek && cetTime <= sundayOfCurrentWeek
  };
}