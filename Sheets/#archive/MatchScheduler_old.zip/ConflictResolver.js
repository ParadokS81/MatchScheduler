/**
 * Schedule Manager - Conflict Detection & Resolution
 * 
 * @version 2.0.0 (Phase 2) - FIXED
 * 
 * Description: Robust conflict detection and automatic resolution
 * Implements team-sheet-wins policy with timestamp validation
 * 
 * BUG FIX: Removed double JSON.stringify that was causing double-stringified data in hub
 */

// ========== CONFLICT DETECTION ==========

/**
 * Conflict types that can occur during synchronization
 */
const CONFLICT_TYPES = {
  VERSION_MISMATCH: 'version_mismatch',     // Different version numbers
  TIMESTAMP_CONFLICT: 'timestamp_conflict', // Concurrent modifications
  WEEK_MISALIGNMENT: 'week_misalignment',   // Different week data
  PLAYER_ROSTER_CONFLICT: 'player_roster_conflict', // Player changes
  DATA_CORRUPTION: 'data_corruption'        // Invalid data structure
};

/**
 * Conflict resolution strategies
 */
const RESOLUTION_STRATEGIES = {
  TEAM_SHEET_WINS: 'team_sheet_wins',       // Local data takes priority
  MOST_RECENT_WINS: 'most_recent_wins',     // Latest timestamp wins
  MERGE_CHANGES: 'merge_changes',           // Attempt to merge
  MANUAL_RESOLUTION: 'manual_resolution',   // Requires user intervention
  REJECT_UPDATE: 'reject_update'            // Block the operation
};

/**
 * Detects conflicts between local team data and hub data
 * @param {Object} localData - Current team sheet data
 * @param {Object} hubData - Data from hub (if exists)
 * @return {Object} Conflict detection result
 */
function detectConflicts(localData, hubData = null) {
  const conflicts = [];
  const warnings = [];
  
  try {
    // If no hub data exists, no conflicts possible
    if (!hubData) {
      return {
        hasConflicts: false,
        conflicts: [],
        warnings: [],
        canProceed: true
      };
    }
    
    // VERSION CONFLICT
    if (hubData.version && localData.version <= hubData.version) {
      // Local version is not newer than hub - potential conflict
      if (localData.version < hubData.version) {
        conflicts.push({
          type: CONFLICT_TYPES.VERSION_MISMATCH,
          severity: 'high',
          description: `Local version (${localData.version}) is behind hub version (${hubData.version})`,
          localValue: localData.version,
          hubValue: hubData.version,
          strategy: RESOLUTION_STRATEGIES.MOST_RECENT_WINS
        });
      }
    }
    
    // TIMESTAMP CONFLICT
    const localTime = new Date(localData.timestamp);
    const hubTime = new Date(hubData.timestamp);
    const timeDiffMs = Math.abs(localTime.getTime() - hubTime.getTime());
    const timeDiffMinutes = timeDiffMs / (1000 * 60);
    
    if (timeDiffMinutes < 5 && localData.version === hubData.version) {
      // Concurrent modifications within 5 minutes - conflict
      conflicts.push({
        type: CONFLICT_TYPES.TIMESTAMP_CONFLICT,
        severity: 'medium',
        description: `Concurrent modifications detected (${timeDiffMinutes.toFixed(1)} minutes apart)`,
        localValue: localData.timestamp,
        hubValue: hubData.timestamp,
        strategy: RESOLUTION_STRATEGIES.TEAM_SHEET_WINS
      });
    }
    
    // WEEK ALIGNMENT CONFLICT
    const localWeeks = localData.weeks.map(w => w.weekNumber).sort((a, b) => a - b);
    const hubWeeks = hubData.weeks.map(w => w.weekNumber).sort((a, b) => a - b);
    
    if (JSON.stringify(localWeeks) !== JSON.stringify(hubWeeks)) {
      const currentWeek = getCurrentWeekNumber();
      const nextWeek = currentWeek + 1;
      
      // Check if local data has current/next week but hub doesn't
      const localHasCurrent = localWeeks.includes(currentWeek) || localWeeks.includes(nextWeek);
      const hubHasCurrent = hubWeeks.includes(currentWeek) || hubWeeks.includes(nextWeek);
      
      if (localHasCurrent && !hubHasCurrent) {
        // Local is more current - this is good
        warnings.push({
          type: CONFLICT_TYPES.WEEK_MISALIGNMENT,
          severity: 'low',
          description: `Local data is more current than hub`,
          strategy: RESOLUTION_STRATEGIES.TEAM_SHEET_WINS
        });
      } else if (!localHasCurrent && hubHasCurrent) {
        // Hub is more current - potential issue
        conflicts.push({
          type: CONFLICT_TYPES.WEEK_MISALIGNMENT,
          severity: 'high',
          description: `Hub has more current week data than local`,
          localValue: localWeeks,
          hubValue: hubWeeks,
          strategy: RESOLUTION_STRATEGIES.REJECT_UPDATE
        });
      } else {
        // Different weeks but unclear which is better
        warnings.push({
          type: CONFLICT_TYPES.WEEK_MISALIGNMENT,
          severity: 'medium',
          description: `Different week data between local and hub`,
          strategy: RESOLUTION_STRATEGIES.TEAM_SHEET_WINS
        });
      }
    }
    
    // PLAYER ROSTER CONFLICT
    const localPlayerNames = localData.players.map(p => p.playerName).sort();
    const hubPlayerNames = hubData.players.map(p => p.playerName).sort();
    
    if (JSON.stringify(localPlayerNames) !== JSON.stringify(hubPlayerNames)) {
      // Player roster has changed
      const localPlayerCount = localPlayerNames.length;
      const hubPlayerCount = hubPlayerNames.length;
      
      if (Math.abs(localPlayerCount - hubPlayerCount) > 0) {
        // Different number of players
        warnings.push({
          type: CONFLICT_TYPES.PLAYER_ROSTER_CONFLICT,
          severity: 'medium',
          description: `Player count changed: Local(${localPlayerCount}) vs Hub(${hubPlayerCount})`,
          strategy: RESOLUTION_STRATEGIES.TEAM_SHEET_WINS
        });
      } else {
        // Same count but different names
        warnings.push({
          type: CONFLICT_TYPES.PLAYER_ROSTER_CONFLICT,
          severity: 'low',
          description: `Player names have changed`,
          strategy: RESOLUTION_STRATEGIES.TEAM_SHEET_WINS
        });
      }
    }
    
    // TEAM NAME CONFLICT
    if (localData.teamName !== hubData.teamName) {
      warnings.push({
        type: 'team_name_change',
        severity: 'low',
        description: `Team name changed: "${hubData.teamName}" → "${localData.teamName}"`,
        strategy: RESOLUTION_STRATEGIES.TEAM_SHEET_WINS
      });
    }
    
    return {
      hasConflicts: conflicts.length > 0,
      conflicts: conflicts,
      warnings: warnings,
      canProceed: !conflicts.some(c => c.severity === 'high'),
      totalIssues: conflicts.length + warnings.length
    };
    
  } catch (e) {
    Logger.log(`ConflictResolver: Error detecting conflicts: ${e.message}`);
    return {
      hasConflicts: true,
      conflicts: [{
        type: CONFLICT_TYPES.DATA_CORRUPTION,
        severity: 'high',
        description: `Conflict detection failed: ${e.message}`,
        strategy: RESOLUTION_STRATEGIES.REJECT_UPDATE
      }],
      warnings: [],
      canProceed: false
    };
  }
}

/**
 * Resolves conflicts automatically based on configured strategies
 * @param {Object} localData - Local team data
 * @param {Object} hubData - Hub team data
 * @param {Object} conflictResult - Result from detectConflicts()
 * @return {Object} Resolution result
 */
function resolveConflicts(localData, hubData, conflictResult) {
  if (!conflictResult.hasConflicts) {
    return {
      resolved: true,
      finalData: localData,
      strategy: 'no_conflicts',
      actions: ['proceeding_with_local_data']
    };
  }
  
  const actions = [];
  let finalData = { ...localData };
  let canProceed = true;
  
  try {
    // Process each conflict
    for (const conflict of conflictResult.conflicts) {
      Logger.log(`ConflictResolver: Resolving ${conflict.type} conflict using ${conflict.strategy}`);
      
      switch (conflict.strategy) {
        case RESOLUTION_STRATEGIES.TEAM_SHEET_WINS:
          // Local data wins - no changes needed
          actions.push(`${conflict.type}: Local data preserved`);
          break;
          
        case RESOLUTION_STRATEGIES.MOST_RECENT_WINS:
          // Use timestamp to determine winner
          const localTime = new Date(localData.timestamp);
          const hubTime = new Date(hubData.timestamp);
          
          if (hubTime > localTime) {
            // Hub data is more recent - this shouldn't happen often
            actions.push(`${conflict.type}: Hub data is more recent, but local wins by policy`);
            // Still use local data per team-sheet-wins policy
          } else {
            actions.push(`${conflict.type}: Local data is more recent and wins`);
          }
          break;
          
        case RESOLUTION_STRATEGIES.REJECT_UPDATE:
          // Block the entire operation
          canProceed = false;
          actions.push(`${conflict.type}: Operation rejected due to severe conflict`);
          break;
          
        default:
          // Unknown strategy - be conservative
          if (conflict.severity === 'high') {
            canProceed = false;
            actions.push(`${conflict.type}: Unknown resolution strategy, operation blocked`);
          } else {
            actions.push(`${conflict.type}: Unknown resolution strategy, proceeding with local data`);
          }
      }
    }
    
    // Process warnings (non-blocking)
    for (const warning of conflictResult.warnings) {
      actions.push(`${warning.type}: ${warning.description} (proceeding)`);
    }
    
    // If we can proceed, increment version number to reflect resolution
    if (canProceed) {
      finalData.version = Math.max(localData.version, hubData?.version || 0) + 1;
      finalData.timestamp = new Date().toISOString();
      
      // Update sync metadata
      finalData.syncMetadata.conflictsDetected = (finalData.syncMetadata.conflictsDetected || 0) + conflictResult.conflicts.length;
      
      actions.push(`Version incremented to ${finalData.version} after conflict resolution`);
    }
    
    return {
      resolved: canProceed,
      finalData: canProceed ? finalData : null,
      strategy: 'team_sheet_wins_policy',
      actions: actions,
      conflictsProcessed: conflictResult.conflicts.length,
      warningsProcessed: conflictResult.warnings.length
    };
    
  } catch (e) {
    Logger.log(`ConflictResolver: Error resolving conflicts: ${e.message}`);
    return {
      resolved: false,
      finalData: null,
      strategy: 'error',
      actions: [`Resolution failed: ${e.message}`],
      error: e.message
    };
  }
}

/**
 * Gets current team data from hub for conflict detection
 * @param {string} sheetId - Team sheet ID
 * @return {Object|null} Current hub data or null if not found
 */
function getCurrentHubData(sheetId) {
  try {
    // Get data from hub using existing fetchTeamsData function
    const hubTeamsData = fetchTeamsData([sheetId]);
    
    if (hubTeamsData && hubTeamsData.length > 0) {
      return hubTeamsData[0];
    }
    
    return null;
    
  } catch (e) {
    Logger.log(`ConflictResolver: Error getting hub data: ${e.message}`);
    return null;
  }
}

/**
 * Comprehensive conflict-aware data sync
 * Replaces simple pushAvailabilityToHub with conflict detection
 * @return {Object} Sync result with conflict information
 */
function syncWithConflictDetection() {
  const ui = SpreadsheetApp.getUi();
  
  try {
    Logger.log("ConflictResolver: Starting conflict-aware sync");
    
    // Step 1: Build local atomic data
    const localData = buildAtomicTeamData();
    Logger.log(`ConflictResolver: Built local data (version ${localData.version})`);
    
    // Step 2: Get current hub data for comparison
    const hubData = getCurrentHubData(localData.sheetId);
    Logger.log(`ConflictResolver: Retrieved hub data: ${hubData ? 'found' : 'not found'}`);
    
    // Step 3: Detect conflicts
    const conflictResult = detectConflicts(localData, hubData);
    Logger.log(`ConflictResolver: Conflicts detected: ${conflictResult.hasConflicts}, Total issues: ${conflictResult.totalIssues}`);
    
    // Step 4: Handle conflicts if they exist
    if (conflictResult.hasConflicts || conflictResult.warnings.length > 0) {
      // Log conflict details
      conflictResult.conflicts.forEach(conflict => {
        Logger.log(`ConflictResolver: CONFLICT - ${conflict.type}: ${conflict.description}`);
      });
      
      conflictResult.warnings.forEach(warning => {
        Logger.log(`ConflictResolver: WARNING - ${warning.type}: ${warning.description}`);
      });
      
      // Show user summary of conflicts (if any are significant)
      const highSeverityConflicts = conflictResult.conflicts.filter(c => c.severity === 'high');
      
      if (highSeverityConflicts.length > 0) {
        const conflictSummary = highSeverityConflicts.map(c => c.description).join('\n');
        const userResponse = ui.alert(
          'Sync Conflicts Detected',
          `The following conflicts were detected:\n${conflictSummary}\n\nUsing team-sheet-wins policy. Continue?`,
          ui.ButtonSet.YES_NO
        );
        
        if (userResponse !== ui.Button.YES) {
          return {
            success: false,
            message: 'Sync cancelled by user due to conflicts',
            conflicts: conflictResult.conflicts,
            userCancelled: true
          };
        }
      }
    }
    
    // Step 5: Resolve conflicts
    const resolution = resolveConflicts(localData, hubData, conflictResult);
    
    if (!resolution.resolved) {
      return {
        success: false,
        message: 'Conflicts could not be resolved automatically',
        conflicts: conflictResult.conflicts,
        resolution: resolution
      };
    }
    
    // Step 6: Proceed with sync using resolved data
    Logger.log("ConflictResolver: Proceeding with conflict-resolved sync");
    const syncSuccess = performAtomicHubSync(resolution.finalData);
    
    if (syncSuccess) {
      // Update sync metadata
      updateSyncMetadata(resolution.finalData, true);
      
      // Show success message with conflict summary
      let message = `Sync successful! `;
      if (conflictResult.totalIssues > 0) {
        message += `Resolved ${conflictResult.conflicts.length} conflicts and ${conflictResult.warnings.length} warnings.`;
      }
      
      ui.alert('Sync Complete', message, ui.ButtonSet.OK);
      
      return {
        success: true,
        message: message,
        conflicts: conflictResult.conflicts,
        warnings: conflictResult.warnings,
        resolution: resolution,
        finalVersion: resolution.finalData.version
      };
    } else {
      return {
        success: false,
        message: 'Hub sync failed after conflict resolution',
        conflicts: conflictResult.conflicts,
        resolution: resolution
      };
    }
    
  } catch (e) {
    Logger.log(`ConflictResolver: Sync error: ${e.message}`);
    updateSyncMetadata(null, false, e.message);
    
    return {
      success: false,
      message: `Sync failed: ${e.message}`,
      error: e.message
    };
  }
}

/**
 * FIXED: Performs atomic hub sync with validated data
 * BUG FIX: Removed duplicate JSON.stringify that was causing double-stringified data
 * @param {Object} validatedData - Data that has passed conflict resolution
 * @return {boolean} Success indicator
 */
function performAtomicHubSync(validatedData) {
  try {
    // Use existing hub infrastructure but with validated data
    const hubSheet = SpreadsheetApp.openById(BLOCK_CONFIG.HUB.SPREADSHEET_ID);
    
    // Update both data sheet and masterlist atomically
    const dataSheet = hubSheet.getSheetByName(BLOCK_CONFIG.HUB.DATA_SHEET);
    const masterlist = hubSheet.getSheetByName(BLOCK_CONFIG.HUB.MASTERLIST_SHEET);
    
    if (!dataSheet || !masterlist) {
      throw new Error("Hub sheets not found");
    }
    
    // Compress data for storage (returns OBJECT)
    const compressedData = compressForHubStorage(validatedData);
    
    // FIXED: Pass object directly - updateHubDataSheet will do the JSON.stringify
    // REMOVED: const dataJson = JSON.stringify(compressedData); // This was causing double stringify
    const success = updateHubDataSheet(dataSheet, validatedData.sheetId, compressedData);
    
    if (success) {
      // Update masterlist with metadata from same data
      updateHubMasterlist(masterlist, validatedData);
      Logger.log(`ConflictResolver: Atomic hub sync completed for ${validatedData.teamName}`);
      return true;
    }
    
    return false;
    
  } catch (e) {
    Logger.log(`ConflictResolver: Atomic sync error: ${e.message}`);
    return false;
  }
}

/**
 * Updates sync metadata after sync attempt
 * @param {Object} data - Team data (if successful)
 * @param {boolean} success - Whether sync was successful
 * @param {string} error - Error message (if failed)
 */
function updateSyncMetadata(data, success, error = null) {
  try {
    const props = PropertiesService.getDocumentProperties();
    
    if (success && data) {
      props.setProperty('lastSuccessfulSync', data.timestamp);
      props.setProperty('syncAttempts', '0'); // Reset attempt counter
    } else {
      // Increment attempt counter
      const currentAttempts = parseInt(props.getProperty('syncAttempts') || '0');
      props.setProperty('syncAttempts', (currentAttempts + 1).toString());
      
      if (error) {
        props.setProperty('lastSyncError', error);
      }
    }
    
  } catch (e) {
    Logger.log(`ConflictResolver: Error updating sync metadata: ${e.message}`);
  }
}

// ========== TESTING FUNCTIONS ==========

/**
 * Debug function to test conflict detection with simulated data
 */
function debugTestConflictDetection() {
  try {
    Logger.log("=== CONFLICT DETECTION TEST ===");
    
    // Build current local data
    const localData = buildAtomicTeamData();
    Logger.log(`Local data version: ${localData.version}, timestamp: ${localData.timestamp}`);
    
    // Simulate hub data with conflicts
    const simulatedHubData = { ...localData };
    simulatedHubData.version = localData.version + 1; // Version conflict
    simulatedHubData.timestamp = new Date(Date.now() - 2 * 60 * 1000).toISOString(); // 2 min ago
    simulatedHubData.teamName = localData.teamName + " (Modified)"; // Name conflict
    
    // Test conflict detection
    const conflictResult = detectConflicts(localData, simulatedHubData);
    
    Logger.log(`Conflicts detected: ${conflictResult.hasConflicts}`);
    Logger.log(`Total issues: ${conflictResult.totalIssues}`);
    Logger.log(`Can proceed: ${conflictResult.canProceed}`);
    
    conflictResult.conflicts.forEach((conflict, i) => {
      Logger.log(`Conflict ${i + 1}: ${conflict.type} (${conflict.severity}) - ${conflict.description}`);
    });
    
    conflictResult.warnings.forEach((warning, i) => {
      Logger.log(`Warning ${i + 1}: ${warning.type} (${warning.severity}) - ${warning.description}`);
    });
    
    // Test conflict resolution
    const resolution = resolveConflicts(localData, simulatedHubData, conflictResult);
    Logger.log(`Resolution successful: ${resolution.resolved}`);
    Logger.log(`Final version: ${resolution.finalData?.version}`);
    
    resolution.actions.forEach((action, i) => {
      Logger.log(`Action ${i + 1}: ${action}`);
    });
    
    return {
      conflictResult: conflictResult,
      resolution: resolution
    };
    
  } catch (e) {
    Logger.log(`Test error: ${e.message}`);
    return { error: e.message };
  }
}