/**
 * Schedule Manager - Hub Connector (COMPLETE WITH ATOMIC SYNC)
 * 
 * @version 2.5.0 (Backwards Compatibility - 2025-05-25 02:18)
 * 
 * Description: Clean hub communication using Phase 1-3 systems + missing atomic sync functions
 * Uses: DataContract.js + ConflictResolver.js + TeamManager.js + SlotManager.js
 * 
 * CHANGELOG:
 * v2.5.0 - IMPROVED: Backwards compatibility for legacy double-stringified data (proper engineering)
 * v2.4.0 - FIXED: Double-stringified JSON data parsing (handles JSON.stringify(JSON.stringify()))
 * v2.3.0 - FIXED: Enhanced JSON parsing with object validation (string->object conversion issue)
 * v2.2.0 - FIXED: decompressFromHubStorage data retrieval causing object->array conversion  
 * v2.1.1 - FIXED: compressForHubStorage function scope issue causing forEach error
 * v2.1.0 - ADDED: simpleHubDecompression with proper error handling for atomic data
 * v2.0.0 - Initial atomic sync implementation
 */

// ========== CORE HUB FUNCTIONS ==========

/**
 * Push team data to hub using Phase 1-3 systems
 * @return {Object} Sync result
 */
function pushAvailabilityToHub() {
  try {
    Logger.log("HubConnector: Starting push using Phase 1-3 systems");
    
    // Use ConflictResolver.js which handles everything:
    // - Builds atomic data (DataContract.js)
    // - Detects conflicts with hub
    // - Resolves conflicts using team-sheet-wins policy
    // - Performs atomic hub sync
    const result = syncWithConflictDetection();
    
    Logger.log(`HubConnector: Push ${result.success ? 'successful' : 'failed'}`);
    return result;
    
  } catch (e) {
    Logger.log(`HubConnector: Push error: ${e.message}`);
    return {
      success: false,
      message: `Push failed: ${e.message}`,
      error: e.message
    };
  }
}

/**
 * Simple data compression for hub storage (fallback if DataContract version not available)
 * @param {Object} teamData - Team data to compress
 * @return {Object} Compressed data
 */
function simpleHubCompression(teamData) {
  try {
    // Create a safe copy
    const compressed = JSON.parse(JSON.stringify(teamData));
    
    // Simple compression: only compress large grids
    if (compressed.weeks && Array.isArray(compressed.weeks)) {
      compressed.weeks.forEach(week => {
        if (week.availability && week.availability.grid) {
          const gridSize = JSON.stringify(week.availability.grid).length;
          if (gridSize > 5000) { // If over 5KB, mark for compression
            week.availability.gridSize = gridSize;
            week.availability.compressed = true;
            // For now, keep the grid as-is (can add real compression later)
          }
        }
      });
    }
    
    return compressed;
    
  } catch (e) {
    Logger.log(`HubConnector: Simple compression error: ${e.message}`);
    return teamData; // Return original if compression fails
  }
}

/**
 * Simple data decompression from hub storage (fallback if DataContract version not available)
 * @param {Object} compressedData - Data from hub storage
 * @return {Object} Decompressed team data
 */
function simpleHubDecompression(compressedData) {
  try {
    // SAFETY: Check if data is already in correct format
    if (!compressedData || typeof compressedData !== 'object') {
      Logger.log(`HubConnector: Invalid compressed data type: ${typeof compressedData}`);
      return compressedData;
    }
    
    // If data looks like atomic format already, return as-is
    if (compressedData.contractVersion === "1.0.0" && compressedData.weeks) {
      Logger.log("HubConnector: Data already in atomic format, no decompression needed");
      return compressedData;
    }
    
    // Create a safe copy for decompression
    const decompressed = JSON.parse(JSON.stringify(compressedData));
    
    // Handle any compressed availability grids (SAFE forEach)
    if (decompressed.weeks && Array.isArray(decompressed.weeks)) {
      decompressed.weeks.forEach((week, index) => {
        if (week && week.availability && week.availability.compressed) {
          // For now, just mark as decompressed
          // (Real compression logic would go here)
          week.availability.compressed = false;
          Logger.log(`HubConnector: Decompressed week ${index + 1}`);
        }
      });
    }
    
    return decompressed;
    
  } catch (e) {
    Logger.log(`HubConnector: Simple decompression error: ${e.message}`);
    Logger.log(`HubConnector: Returning original data unchanged`);
    return compressedData; // Return original if decompression fails
  }
}

/**
 * Get team data from hub (simplified)
 * @param {string[]} teamIds - Team sheet IDs to fetch
 * @return {Object[]} Array of team data
 */
function fetchTeamsData(teamIds) {
  if (!teamIds || teamIds.length === 0) {
    return [];
  }
  
  Logger.log(`HubConnector: Fetching data for ${teamIds.length} teams`);
  
  try {
    const hubSheet = SpreadsheetApp.openById(BLOCK_CONFIG.HUB.SPREADSHEET_ID);
    const dataSheet = hubSheet.getSheetByName(BLOCK_CONFIG.HUB.DATA_SHEET);
    
    if (!dataSheet) {
      Logger.log("HubConnector: Data sheet not found");
      return [];
    }
    
    const dataValues = dataSheet.getDataRange().getValues();
    const teams = [];
    
    // Skip header row, find matching teams
    for (let i = 1; i < dataValues.length; i++) {
      const sheetId = String(dataValues[i][0]);
      
      if (teamIds.includes(sheetId)) {
        try {
          const jsonData = dataValues[i][1];
          
          // FIXED: Handle both normal and double-stringified JSON (backwards compatibility)
          let teamData;
          try {
            if (!jsonData || typeof jsonData !== 'string') {
              Logger.log(`HubConnector: Invalid JSON data type for team ${sheetId}: ${typeof jsonData}`);
              continue;
            }
            
            // Parse the JSON data
            let parsedData = JSON.parse(jsonData);
            
            // Handle legacy double-stringified data (backwards compatibility)
            if (typeof parsedData === 'string') {
              Logger.log(`HubConnector: Legacy double-stringified data detected for ${sheetId}, parsing again...`);
              teamData = JSON.parse(parsedData);
            } else {
              Logger.log(`HubConnector: Normal JSON format detected for ${sheetId}`);
              teamData = parsedData;
            }
            
            // CRITICAL: Verify final result is an object
            if (!teamData || typeof teamData !== 'object') {
              Logger.log(`HubConnector: Final parse failed to return object for team ${sheetId}: ${typeof teamData}`);
              continue;
            }
            
            Logger.log(`HubConnector: Successfully parsed JSON for team: ${teamData.teamName || 'unknown'}`);
            
          } catch (jsonError) {
            Logger.log(`HubConnector: JSON.parse error for team ${sheetId}: ${jsonError.message}`);
            continue;
          }
          
          // FIXED: Handle decompression function availability with better error handling
          let decompressedData;
          try {
            // Try to use decompression function from DataContract.js if available
            if (typeof decompressFromHubStorage === 'function') {
              decompressedData = decompressFromHubStorage(teamData);
              Logger.log("HubConnector: DataContract decompression applied");
            } else {
              // Fallback: use simple built-in decompression  
              decompressedData = simpleHubDecompression(teamData);
              Logger.log("HubConnector: Simple decompression applied (DataContract not available)");
            }
            
            // CRITICAL: Verify decompression returned valid object
            if (!decompressedData || typeof decompressedData !== 'object') {
              Logger.log(`HubConnector: Decompression failed to return object: ${typeof decompressedData}`);
              decompressedData = teamData; // Use original parsed data
            }
            
          } catch (decompressionError) {
            Logger.log(`HubConnector: Decompression failed: ${decompressionError.message}, using direct data`);
            // CRITICAL FIX: Use teamData directly, don't modify it
            decompressedData = teamData;
            
            // DEBUG: Check if teamData is valid
            if (teamData && typeof teamData === 'object' && typeof teamData.teamName !== 'undefined') {
              Logger.log(`HubConnector: Direct data appears valid for team: ${teamData.teamName}`);
            } else {
              Logger.log(`HubConnector: WARNING - Direct data structure issue: ${typeof teamData}`);
            }
          }
          
          // FINAL SAFETY CHECK: Ensure we're pushing an object
          if (decompressedData && typeof decompressedData === 'object') {
            teams.push(decompressedData);
            Logger.log(`HubConnector: Added team to results: ${decompressedData.teamName || 'unknown'}`);
          } else {
            Logger.log(`HubConnector: REJECTED team data - not an object: ${typeof decompressedData}`);
          }
          
        } catch (e) {
          Logger.log(`HubConnector: Error parsing data for team ${sheetId}: ${e.message}`);
        }
      }
    }
    
    Logger.log(`HubConnector: Retrieved ${teams.length} teams`);
    return teams;
    
  } catch (e) {
    Logger.log(`HubConnector: Fetch error: ${e.message}`);
    return [];
  }
}

/**
 * Get available teams from hub masterlist
 * @param {boolean} includeOwnTeam - Whether to include current team
 * @return {Object[]} Array of team info
 */
function getAvailableTeams(includeOwnTeam = false) {
  Logger.log("HubConnector: Getting available teams from masterlist");
  
  try {
    const hubSheet = SpreadsheetApp.openById(BLOCK_CONFIG.HUB.SPREADSHEET_ID);
    const masterlist = hubSheet.getSheetByName(BLOCK_CONFIG.HUB.MASTERLIST_SHEET);
    
    if (!masterlist) {
      Logger.log("HubConnector: Masterlist not found");
      return [];
    }
    
    const teamData = masterlist.getDataRange().getValues();
    if (teamData.length <= 1) return []; // Only header
    
    const currentSheetId = SpreadsheetApp.getActiveSpreadsheet().getId();
    const teams = [];
    
    // Process team data (skip header)
    for (let i = 1; i < teamData.length; i++) {
      const row = teamData[i];
      const teamId = row[BLOCK_CONFIG.HUB.COLUMNS.SHEET_ID];
      
      // Skip inactive teams and own team (unless requested)
      if (row[BLOCK_CONFIG.HUB.COLUMNS.SHARING_STATUS] !== "Active") continue;
      if (!includeOwnTeam && teamId === currentSheetId) continue;
      
      teams.push({
        name: row[BLOCK_CONFIG.HUB.COLUMNS.TEAM_NAME],
        sheetId: teamId,
        url: row[BLOCK_CONFIG.HUB.COLUMNS.SHEET_URL],
        division: row[BLOCK_CONFIG.HUB.COLUMNS.DIVISION],
        players: row[BLOCK_CONFIG.HUB.COLUMNS.PLAYER_LIST],
        lastUpdated: row[BLOCK_CONFIG.HUB.COLUMNS.LAST_UPDATED],
        weeksAvailable: row[BLOCK_CONFIG.HUB.COLUMNS.WEEKS_AVAILABLE],
        logoUrl: row[BLOCK_CONFIG.HUB.COLUMNS.LOGO_URL] || "",
        isOwnTeam: (teamId === currentSheetId)
      });
    }
    
    Logger.log(`HubConnector: Found ${teams.length} available teams`);
    return teams;
    
  } catch (e) {
    Logger.log(`HubConnector: Error getting available teams: ${e.message}`);
    return [];
  }
}

// ========== ATOMIC HUB SYNC (TEAM-SIDE) ==========

/**
 * Performs atomic hub sync with validated data (called by ConflictResolver.js)
 * This function runs on TEAM SIDE and writes directly to hub spreadsheet
 * @param {Object} validatedData - Data that has passed conflict resolution
 * @return {boolean} Success indicator
 */
function performAtomicHubSync(validatedData) {
  try {
    Logger.log(`HubConnector: Performing atomic hub sync for ${validatedData.teamName}`);
    
    // Open hub spreadsheet (team needs permission to access hub)
    const hubSheet = SpreadsheetApp.openById(BLOCK_CONFIG.HUB.SPREADSHEET_ID);
    const dataSheet = hubSheet.getSheetByName(BLOCK_CONFIG.HUB.DATA_SHEET);
    const masterlist = hubSheet.getSheetByName(BLOCK_CONFIG.HUB.MASTERLIST_SHEET);
    
    if (!dataSheet || !masterlist) {
      Logger.log("HubConnector: ERROR - Hub sheets not found");
      return false;
    }
    
    // Update both sheets atomically (prevents masterlist ↔ availability mismatches)
    const dataSuccess = updateHubDataSheet(dataSheet, validatedData.sheetId, validatedData);
    const masterlistSuccess = updateHubMasterlist(masterlist, validatedData);
    
    if (dataSuccess && masterlistSuccess) {
      Logger.log(`HubConnector: Atomic hub sync completed successfully for ${validatedData.teamName}`);
      return true;
    } else {
      Logger.log(`HubConnector: Atomic sync partial failure - Data: ${dataSuccess}, Masterlist: ${masterlistSuccess}`);
      return false;
    }
    
  } catch (e) {
    Logger.log(`HubConnector: Atomic sync error: ${e.message}`);
    return false;
  }
}

/**
 * Simple data decompression from hub storage (fallback if DataContract version not available)
 * @param {Object} compressedData - Data from hub storage
 * @return {Object} Decompressed team data
 */
function simpleHubDecompression(compressedData) {
  try {
    // SAFETY: Check if data is already in correct format
    if (!compressedData || typeof compressedData !== 'object') {
      Logger.log(`HubConnector: Invalid compressed data type: ${typeof compressedData}`);
      return compressedData;
    }
    
    // If data looks like atomic format already, return as-is
    if (compressedData.contractVersion === "1.0.0" && compressedData.weeks) {
      Logger.log("HubConnector: Data already in atomic format, no decompression needed");
      return compressedData;
    }
    
    // Create a safe copy for decompression
    const decompressed = JSON.parse(JSON.stringify(compressedData));
    
    // Handle any compressed availability grids (SAFE forEach)
    if (decompressed.weeks && Array.isArray(decompressed.weeks)) {
      decompressed.weeks.forEach((week, index) => {
        if (week && week.availability && week.availability.compressed) {
          // For now, just mark as decompressed
          // (Real compression logic would go here)
          week.availability.compressed = false;
          Logger.log(`HubConnector: Decompressed week ${index + 1}`);
        }
      });
    }
    
    return decompressed;
    
  } catch (e) {
    Logger.log(`HubConnector: Simple decompression error: ${e.message}`);
    Logger.log(`HubConnector: Returning original data unchanged`);
    return compressedData; // Return original if decompression fails
  }
}

/**
 * Updates hub data sheet with team data (team-side function)
 * @param {Sheet} dataSheet - Data sheet reference
 * @param {String} sheetId - Team sheet ID
 * @param {Object} teamData - Full atomic team data
 * @return {Boolean} Success indicator
 */
function updateHubDataSheet(dataSheet, sheetId, teamData) {
  try {
    // Find existing row or determine where to add new row
    const dataValues = dataSheet.getDataRange().getValues();
    let rowIndex = -1;
    
    // Look for existing team data
    for (let i = 1; i < dataValues.length; i++) { // Skip header row
      if (dataValues[i][0] === sheetId) {
        rowIndex = i + 1; // 1-based row index
        break;
      }
    }
    
    // FIXED: Handle compression function availability with multiple fallbacks
    let compressedData;
    try {
      // Try to use compression function from DataContract.js if available
      if (typeof compressForHubStorage === 'function') {
        compressedData = compressForHubStorage(teamData);
        Logger.log("HubConnector: DataContract compression applied");
      } else {
        // Fallback: use simple built-in compression
        compressedData = simpleHubCompression(teamData);
        Logger.log("HubConnector: Simple compression applied (DataContract not available)");
      }
    } catch (compressionError) {
      Logger.log(`HubConnector: Compression failed: ${compressionError.message}, using direct data`);
      // Final fallback: use data directly without any compression
      compressedData = teamData;
    }
    
    const dataJson = JSON.stringify(compressedData);
    
    if (rowIndex > 0) {
      // Update existing row
      dataSheet.getRange(rowIndex, 1).setValue(sheetId);
      dataSheet.getRange(rowIndex, 2).setValue(dataJson);
      Logger.log(`HubConnector: Updated hub data sheet row ${rowIndex} for team ${teamData.teamName}`);
    } else {
      // Add new row
      dataSheet.appendRow([sheetId, dataJson]);
      Logger.log(`HubConnector: Added new hub data sheet row for team ${teamData.teamName}`);
    }
    
    return true;
    
  } catch (e) {
    Logger.log(`HubConnector: ERROR updating hub data sheet - ${e.message}`);
    return false;
  }
}

/**
 * Updates hub masterlist with team metadata (team-side function)
 * @param {Sheet} masterlist - Masterlist sheet reference  
 * @param {Object} teamData - Full atomic team data
 * @return {Boolean} Success indicator
 */
function updateHubMasterlist(masterlist, teamData) {
  try {
    // Find existing team in masterlist
    const masterlistData = masterlist.getDataRange().getValues();
    let teamRow = -1;
    
    for (let i = 1; i < masterlistData.length; i++) { // Skip header row
      if (masterlistData[i][BLOCK_CONFIG.HUB.COLUMNS.SHEET_ID] === teamData.sheetId) {
        teamRow = i + 1; // 1-based row index
        break;
      }
    }
    
    // Prepare data for masterlist
    const timestamp = new Date().toLocaleString();
    const weekNumbers = teamData.weeks.map(w => w.weekNumber).join(", ");
    const playerList = teamData.players.map(p => p.playerName).join(", ");
    
    // Get spreadsheet URL from sheet ID (construct it)
    const sheetUrl = `https://docs.google.com/spreadsheets/d/${teamData.sheetId}/edit`;
    
    if (teamRow > 0) {
      // Update existing team
      Logger.log(`HubConnector: Updating hub masterlist row ${teamRow} for ${teamData.teamName}`);
      
      masterlist.getRange(teamRow, BLOCK_CONFIG.HUB.COLUMNS.TEAM_NAME + 1).setValue(teamData.teamName);
      masterlist.getRange(teamRow, BLOCK_CONFIG.HUB.COLUMNS.SHEET_URL + 1).setValue(sheetUrl);
      masterlist.getRange(teamRow, BLOCK_CONFIG.HUB.COLUMNS.DIVISION + 1).setValue(teamData.division || "Division 1");
      masterlist.getRange(teamRow, BLOCK_CONFIG.HUB.COLUMNS.PLAYER_LIST + 1).setValue(playerList);
      masterlist.getRange(teamRow, BLOCK_CONFIG.HUB.COLUMNS.LAST_UPDATED + 1).setValue(timestamp);
      masterlist.getRange(teamRow, BLOCK_CONFIG.HUB.COLUMNS.WEEKS_AVAILABLE + 1).setValue(weekNumbers);
      masterlist.getRange(teamRow, BLOCK_CONFIG.HUB.COLUMNS.SHARING_STATUS + 1).setValue("Active");
      
      // Handle optional logo URL column
      if (BLOCK_CONFIG.HUB.COLUMNS.LOGO_URL !== undefined && teamData.logoUrl) {
        masterlist.getRange(teamRow, BLOCK_CONFIG.HUB.COLUMNS.LOGO_URL + 1).setValue(teamData.logoUrl);
      }
      
    } else {
      // Add new team
      Logger.log(`HubConnector: Adding new hub masterlist entry for ${teamData.teamName}`);
      
      const newRow = [];
      newRow[BLOCK_CONFIG.HUB.COLUMNS.TEAM_NAME] = teamData.teamName;
      newRow[BLOCK_CONFIG.HUB.COLUMNS.SHEET_URL] = sheetUrl;
      newRow[BLOCK_CONFIG.HUB.COLUMNS.SHEET_ID] = teamData.sheetId;
      newRow[BLOCK_CONFIG.HUB.COLUMNS.DIVISION] = teamData.division || "Division 1";
      newRow[BLOCK_CONFIG.HUB.COLUMNS.LAST_UPDATED] = timestamp;
      newRow[BLOCK_CONFIG.HUB.COLUMNS.PLAYER_LIST] = playerList;
      newRow[BLOCK_CONFIG.HUB.COLUMNS.SHARING_STATUS] = "Active";
      newRow[BLOCK_CONFIG.HUB.COLUMNS.WEEKS_AVAILABLE] = weekNumbers;
      
      // Handle optional logo URL column
      if (BLOCK_CONFIG.HUB.COLUMNS.LOGO_URL !== undefined) {
        newRow[BLOCK_CONFIG.HUB.COLUMNS.LOGO_URL] = teamData.logoUrl || "";
      }
      
      masterlist.appendRow(newRow);
    }
    
    return true;
    
  } catch (e) {
    Logger.log(`HubConnector: ERROR updating hub masterlist - ${e.message}`);
    return false;
  }
}

// ========== TEAM REGISTRATION ==========

/**
 * Check if current team is registered with hub
 * @return {Object} Registration status
 */
function checkTeamRegistration() {
  try {
    const currentSheetId = SpreadsheetApp.getActiveSpreadsheet().getId();
    const hubSheet = SpreadsheetApp.openById(BLOCK_CONFIG.HUB.SPREADSHEET_ID);
    const masterlist = hubSheet.getSheetByName(BLOCK_CONFIG.HUB.MASTERLIST_SHEET);
    
    if (!masterlist) {
      return {
        isRegistered: false,
        error: "Hub masterlist not accessible"
      };
    }
    
    const teamData = masterlist.getDataRange().getValues();
    
    // Find team in masterlist
    for (let i = 1; i < teamData.length; i++) {
      if (teamData[i][BLOCK_CONFIG.HUB.COLUMNS.SHEET_ID] === currentSheetId) {
        return {
          isRegistered: true,
          status: teamData[i][BLOCK_CONFIG.HUB.COLUMNS.SHARING_STATUS],
          teamName: teamData[i][BLOCK_CONFIG.HUB.COLUMNS.TEAM_NAME],
          division: teamData[i][BLOCK_CONFIG.HUB.COLUMNS.DIVISION]
        };
      }
    }
    
    return {
      isRegistered: false,
      needsRegistration: true
    };
    
  } catch (e) {
    Logger.log(`HubConnector: Registration check error: ${e.message}`);
    return {
      isRegistered: false,
      error: e.message
    };
  }
}

/**
 * Simple boolean check for team registration
 * @return {boolean} True if registered and active
 */
function isTeamRegistered() {
  const status = checkTeamRegistration();
  return status.isRegistered && status.status === "Active";
}

// ========== DATA COLLECTION (for DataContract.js) ==========

/**
 * Collects week data from a block (used by DataContract.js)
 * @param {Sheet} sheet - The sheet to process
 * @param {Object} block - Block information
 * @return {Object|null} Week data or null if invalid
 */
function collectWeekData(sheet, block) {
  try {
    // Get month header
    const monthCell = sheet.getRange(block.row, block.col - 1);
    const monthName = monthCell.getValue().toString();
    
    // Get day headers
    const dayHeaderRange = sheet.getRange(block.row + 1, block.col, 1, 7);
    const dayHeaders = dayHeaderRange.getValues()[0];
    
    // Get time values
    const timeRange = sheet.getRange(block.timeStartRow, block.timeCol, block.gridHeight, 1);
    const timeValues = timeRange.getValues().map(row => row[0]);
    
    // Get availability grid
    const gridRange = sheet.getRange(
      block.timeStartRow,
      block.col,
      block.gridHeight,
      block.gridWidth
    );
    
    const gridValues = gridRange.getValues();
    
    // Clean grid data - preserve actual initials as entered
    const cleanGrid = gridValues.map(row => 
      row.map(cell => String(cell).trim())
    );
    
    return {
      weekNumber: block.weekNumber,
      month: monthName,
      dayHeaders: dayHeaders,
      timeSlots: timeValues,
      grid: cleanGrid
    };
    
  } catch (e) {
    Logger.log(`HubConnector: Error collecting week data: ${e.message}`);
    return null;
  }
}

/**
 * Gets division for current team (used by DataContract.js)
 * @return {string} Team division
 */
function getDivision() {
  try {
    // Try to get from registration first
    const registration = checkTeamRegistration();
    if (registration.isRegistered && registration.division) {
      return registration.division;
    }
    
    // Fallback to default
    return "Division 1";
    
  } catch (e) {
    Logger.log(`HubConnector: Error getting division: ${e.message}`);
    return "Division 1";
  }
}

// ========== UTILITIES ==========

/**
 * Get team freshness status for display
 * @param {Object} teamData - Team data with weeks array
 * @return {Object} Freshness status
 */
function getTeamFreshness(teamData) {
  if (!teamData || !teamData.weeks) {
    return {
      indicator: "🔴",
      status: "No Data",
      description: "No schedule data available"
    };
  }
  
  const currentWeek = getCurrentWeekNumber();
  const nextWeek = currentWeek + 1;
  const teamWeeks = teamData.weeks.map(w => w.weekNumber);
  
  const hasCurrentWeek = teamWeeks.includes(currentWeek);
  const hasNextWeek = teamWeeks.includes(nextWeek);
  
  if (hasCurrentWeek && hasNextWeek) {
    return {
      indicator: "🟢",
      status: "Current",
      description: "Has both current and next week"
    };
  } else if (hasCurrentWeek) {
    return {
      indicator: "🟡",
      status: "Partial", 
      description: "Has current week only"
    };
  } else if (hasNextWeek) {
    return {
      indicator: "🟡",
      status: "Partial",
      description: "Has next week only"
    };
  } else {
    return {
      indicator: "🔴",
      status: "Outdated",
      description: "No current or next week data"
    };
  }
}

/**
 * Test hub connectivity
 * @return {string} Status message
 */
function testHubConnectivity() {
  try {
    const hubSheet = SpreadsheetApp.openById(BLOCK_CONFIG.HUB.SPREADSHEET_ID);
    const masterlist = hubSheet.getSheetByName(BLOCK_CONFIG.HUB.MASTERLIST_SHEET);
    const dataSheet = hubSheet.getSheetByName(BLOCK_CONFIG.HUB.DATA_SHEET);
    
    Logger.log(`Hub connectivity: OK`);
    Logger.log(`Masterlist: ${masterlist ? 'OK' : 'Missing'}`);
    Logger.log(`Data sheet: ${dataSheet ? 'OK' : 'Missing'}`);
    
    return "Hub connectivity test successful!";
    
  } catch (e) {
    Logger.log(`Hub connectivity test failed: ${e.message}`);
    return `Hub connectivity failed: ${e.message}`;
  }
}