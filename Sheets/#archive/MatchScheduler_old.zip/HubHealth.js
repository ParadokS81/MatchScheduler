/**
 * Schedule Manager - Hub Health Check System
 * 
 * @version 1.0.0 (Stage 4C)
 * 
 * Description: Simple hub health monitoring for admin oversight
 * Provides team count, last push times, week alignment status, and data health
 */

// ========== CORE HEALTH CHECK FUNCTIONS ==========

/**
 * Gets comprehensive hub health status
 * @return {Object} Complete health overview
 */
function getHubHealthStatus() {
  try {
    Logger.log("HubHealthCheck: Starting comprehensive health check");
    
    const hubSheet = SpreadsheetApp.openById(BLOCK_CONFIG.HUB.SPREADSHEET_ID);
    const masterlist = hubSheet.getSheetByName(BLOCK_CONFIG.HUB.MASTERLIST_SHEET);
    const dataSheet = hubSheet.getSheetByName(BLOCK_CONFIG.HUB.DATA_SHEET);
    
    if (!masterlist || !dataSheet) {
      throw new Error("Hub sheets not accessible");
    }
    
    // Get all team data
    const masterlistData = masterlist.getDataRange().getValues();
    const dataSheetData = dataSheet.getDataRange().getValues();
    
    // Process teams
    const teams = processTeamHealthData(masterlistData, dataSheetData);
    
    // Calculate summary statistics
    const summary = calculateHealthSummary(teams);
    
    // Week alignment check
    const weekAlignment = checkGlobalWeekAlignment(teams);
    
    return {
      timestamp: new Date().toISOString(),
      summary: summary,
      weekAlignment: weekAlignment,
      teams: teams,
      hubInfo: {
        masterlistRows: masterlistData.length - 1, // Exclude header
        dataSheetRows: dataSheetData.length - 1,
        hubSpreadsheetId: BLOCK_CONFIG.HUB.SPREADSHEET_ID
      }
    };
    
  } catch (e) {
    Logger.log(`HubHealthCheck: Error getting health status: ${e.message}`);
    return {
      error: e.message,
      timestamp: new Date().toISOString()
    };
  }
}

/**
 * Processes team health data from masterlist and data sheet
 * @param {Array} masterlistData - Raw masterlist data
 * @param {Array} dataSheetData - Raw data sheet data
 * @return {Array} Processed team health objects
 */
function processTeamHealthData(masterlistData, dataSheetData) {
  const teams = [];
  const currentWeek = getCurrentWeekNumber();
  const nextWeek = currentWeek + 1;
  
  // Create data sheet lookup for faster access
  const dataLookup = {};
  for (let i = 1; i < dataSheetData.length; i++) {
    const sheetId = dataSheetData[i][0];
    const jsonData = dataSheetData[i][1];
    dataLookup[sheetId] = jsonData;
  }
  
  // Process each team from masterlist
  for (let i = 1; i < masterlistData.length; i++) {
    const row = masterlistData[i];
    const sheetId = row[BLOCK_CONFIG.HUB.COLUMNS.SHEET_ID];
    
    const team = {
      name: row[BLOCK_CONFIG.HUB.COLUMNS.TEAM_NAME] || "Unknown",
      sheetId: sheetId,
      division: row[BLOCK_CONFIG.HUB.COLUMNS.DIVISION] || "Unknown",
      status: row[BLOCK_CONFIG.HUB.COLUMNS.SHARING_STATUS] || "Unknown",
      lastUpdated: row[BLOCK_CONFIG.HUB.COLUMNS.LAST_UPDATED] || "Never",
      playerList: row[BLOCK_CONFIG.HUB.COLUMNS.PLAYER_LIST] || "",
      weeksAvailable: row[BLOCK_CONFIG.HUB.COLUMNS.WEEKS_AVAILABLE] || "",
      url: row[BLOCK_CONFIG.HUB.COLUMNS.SHEET_URL] || "",
      
      // Health indicators
      health: {
        isActive: row[BLOCK_CONFIG.HUB.COLUMNS.SHARING_STATUS] === "Active",
        hasData: sheetId in dataLookup,
        hasCurrentWeek: false,
        hasNextWeek: false,
        playerCount: 0,
        dataIntegrity: "unknown",
        lastPushAge: "unknown"
      }
    };
    
    // Analyze player count
    if (team.playerList) {
      team.health.playerCount = team.playerList.split(',').filter(p => p.trim().length > 0).length;
    }
    
    // Analyze weeks available
    if (team.weeksAvailable) {
      const availableWeeks = team.weeksAvailable.split(',').map(w => parseInt(w.trim())).filter(w => !isNaN(w));
      team.health.hasCurrentWeek = availableWeeks.includes(currentWeek);
      team.health.hasNextWeek = availableWeeks.includes(nextWeek);
    }
    
    // Analyze data integrity and recency
    if (team.health.hasData) {
      try {
        const teamData = JSON.parse(dataLookup[sheetId]);
        team.health.dataIntegrity = validateTeamDataIntegrity(teamData);
        
        // Calculate push age
        if (teamData.timestamp) {
          const pushTime = new Date(teamData.timestamp);
          const ageMs = Date.now() - pushTime.getTime();
          const ageHours = Math.round(ageMs / (1000 * 60 * 60));
          team.health.lastPushAge = ageHours < 24 ? `${ageHours}h ago` : `${Math.round(ageHours/24)}d ago`;
        }
        
      } catch (e) {
        team.health.dataIntegrity = "corrupted";
      }
    } else {
      team.health.dataIntegrity = "no_data";
    }
    
    teams.push(team);
  }
  
  return teams;
}

/**
 * Validates team data integrity
 * @param {Object} teamData - Parsed team data
 * @return {string} Integrity status
 */
function validateTeamDataIntegrity(teamData) {
  try {
    // Basic structure checks
    if (!teamData.teamName || !teamData.players || !teamData.weeks) {
      return "incomplete";
    }
    
    if (!Array.isArray(teamData.players) || !Array.isArray(teamData.weeks)) {
      return "malformed";
    }
    
    // Data contract validation (if available)
    if (typeof validateTeamDataContract === 'function') {
      const validation = validateTeamDataContract(teamData);
      return validation.isValid ? "valid" : "invalid";
    }
    
    return "basic_valid";
    
  } catch (e) {
    return "error";
  }
}

/**
 * Calculates summary health statistics
 * @param {Array} teams - Array of team health objects
 * @return {Object} Summary statistics
 */
function calculateHealthSummary(teams) {
  const summary = {
    totalTeams: teams.length,
    activeTeams: 0,
    teamsWithData: 0,
    teamsWithCurrentWeek: 0,
    teamsWithNextWeek: 0,
    teamsWithBothWeeks: 0,
    averagePlayerCount: 0,
    dataIntegrityIssues: 0,
    recentlyUpdated: 0 // Within last 24 hours
  };
  
  let totalPlayers = 0;
  const now = Date.now();
  
  teams.forEach(team => {
    if (team.health.isActive) summary.activeTeams++;
    if (team.health.hasData) summary.teamsWithData++;
    if (team.health.hasCurrentWeek) summary.teamsWithCurrentWeek++;
    if (team.health.hasNextWeek) summary.teamsWithNextWeek++;
    if (team.health.hasCurrentWeek && team.health.hasNextWeek) summary.teamsWithBothWeeks++;
    
    totalPlayers += team.health.playerCount;
    
    if (team.health.dataIntegrity !== "valid" && team.health.dataIntegrity !== "basic_valid") {
      summary.dataIntegrityIssues++;
    }
    
    // Check if updated recently
    if (team.lastUpdated && team.lastUpdated !== "Never") {
      try {
        const updateTime = new Date(team.lastUpdated).getTime();
        if (now - updateTime < 24 * 60 * 60 * 1000) { // 24 hours
          summary.recentlyUpdated++;
        }
      } catch (e) {
        // Invalid date format
      }
    }
  });
  
  summary.averagePlayerCount = teams.length > 0 ? Math.round(totalPlayers / teams.length) : 0;
  
  return summary;
}

/**
 * Checks global week alignment across all teams
 * @param {Array} teams - Array of team health objects
 * @return {Object} Week alignment analysis
 */
function checkGlobalWeekAlignment(teams) {
  const currentWeek = getCurrentWeekNumber();
  const nextWeek = currentWeek + 1;
  
  // Count teams by week status
  const alignment = {
    currentWeek: currentWeek,
    nextWeek: nextWeek,
    status: "unknown",
    teamsWithCurrent: 0,
    teamsWithNext: 0,
    teamsWithBoth: 0,
    teamsWithNeither: 0,
    weekDistribution: {},
    recommendedAction: "none"
  };
  
  // Analyze each team's week status
  teams.forEach(team => {
    if (team.health.hasCurrentWeek) alignment.teamsWithCurrent++;
    if (team.health.hasNextWeek) alignment.teamsWithNext++;
    if (team.health.hasCurrentWeek && team.health.hasNextWeek) alignment.teamsWithBoth++;
    if (!team.health.hasCurrentWeek && !team.health.hasNextWeek) alignment.teamsWithNeither++;
    
    // Track week distribution
    if (team.weeksAvailable) {
      const weeks = team.weeksAvailable.split(',').map(w => parseInt(w.trim())).filter(w => !isNaN(w));
      weeks.forEach(week => {
        alignment.weekDistribution[week] = (alignment.weekDistribution[week] || 0) + 1;
      });
    }
  });
  
  // Determine alignment status
  const activeTeams = teams.filter(t => t.health.isActive).length;
  const currentPercentage = activeTeams > 0 ? (alignment.teamsWithCurrent / activeTeams) * 100 : 0;
  const nextPercentage = activeTeams > 0 ? (alignment.teamsWithNext / activeTeams) * 100 : 0;
  
  if (currentPercentage >= 80 && nextPercentage >= 80) {
    alignment.status = "excellent";
  } else if (currentPercentage >= 60 && nextPercentage >= 60) {
    alignment.status = "good";
  } else if (currentPercentage >= 40 || nextPercentage >= 40) {
    alignment.status = "fair";
  } else {
    alignment.status = "poor";
  }
  
  // Recommend actions
  if (alignment.teamsWithNeither > activeTeams * 0.3) {
    alignment.recommendedAction = "rollover_needed";
  } else if (alignment.teamsWithCurrent < activeTeams * 0.5) {
    alignment.recommendedAction = "encourage_updates";
  }
  
  return alignment;
}

// ========== UI INTEGRATION FUNCTIONS ==========

/**
 * Shows hub health status in admin UI
 */
function showHubHealthStatus() {
  const ui = SpreadsheetApp.getUi();
  
  try {
    ui.alert('Getting Hub Status', 'Analyzing hub health... This may take a moment.', ui.ButtonSet.OK);
    
    const healthStatus = getHubHealthStatus();
    
    if (healthStatus.error) {
      ui.alert('Hub Health Check Error', `Error: ${healthStatus.error}`, ui.ButtonSet.OK);
      return;
    }
    
    const summary = healthStatus.summary;
    const weekAlignment = healthStatus.weekAlignment;
    
    let message = `🏥 HUB HEALTH STATUS\n\n`;
    
    // Summary statistics
    message += `📊 TEAM OVERVIEW:\n`;
    message += `Total Teams: ${summary.totalTeams}\n`;
    message += `Active Teams: ${summary.activeTeams}\n`;
    message += `Teams with Data: ${summary.teamsWithData}\n`;
    message += `Average Players: ${summary.averagePlayerCount}\n\n`;
    
    // Week alignment
    message += `📅 WEEK ALIGNMENT (Week ${weekAlignment.currentWeek}):\n`;
    message += `Current Week: ${weekAlignment.teamsWithCurrent}/${summary.activeTeams} teams\n`;
    message += `Next Week: ${weekAlignment.teamsWithNext}/${summary.activeTeams} teams\n`;
    message += `Status: ${weekAlignment.status.toUpperCase()}\n\n`;
    
    // Issues
    if (summary.dataIntegrityIssues > 0) {
      message += `⚠️ DATA ISSUES:\n`;
      message += `Teams with integrity issues: ${summary.dataIntegrityIssues}\n\n`;
    }
    
    // Activity
    message += `📈 ACTIVITY:\n`;
    message += `Recently updated (24h): ${summary.recentlyUpdated}\n\n`;
    
    // Recommended actions
    if (weekAlignment.recommendedAction !== "none") {
      message += `💡 RECOMMENDED ACTION:\n`;
      switch (weekAlignment.recommendedAction) {
        case "rollover_needed":
          message += `Consider running week rollover - many teams missing current weeks\n`;
          break;
        case "encourage_updates":
          message += `Encourage teams to update their availability\n`;
          break;
      }
      message += `\n`;
    }
    
    message += `📋 For detailed team breakdown, use "View Detailed Team Status"`;
    
    ui.alert('🏥 Hub Health Status', message, ui.ButtonSet.OK);
    
  } catch (e) {
    Logger.log(`HubHealthCheck: UI error: ${e.message}`);
    ui.alert('Error', `Failed to get hub status: ${e.message}`, ui.ButtonSet.OK);
  }
}

/**
 * Shows detailed team status in admin UI
 */
function showDetailedTeamStatus() {
  const ui = SpreadsheetApp.getUi();
  
  try {
    ui.alert('Getting Team Details', 'Loading detailed team information...', ui.ButtonSet.OK);
    
    const healthStatus = getHubHealthStatus();
    
    if (healthStatus.error) {
      ui.alert('Error', `Error: ${healthStatus.error}`, ui.ButtonSet.OK);
      return;
    }
    
    // Show teams in chunks to avoid dialog size limits
    const teams = healthStatus.teams.filter(t => t.health.isActive);
    const chunkSize = 8;
    
    for (let i = 0; i < teams.length; i += chunkSize) {
      const chunk = teams.slice(i, i + chunkSize);
      
      let message = `📋 TEAM STATUS (${i + 1}-${Math.min(i + chunkSize, teams.length)} of ${teams.length})\n\n`;
      
      chunk.forEach((team, index) => {
        const teamNum = i + index + 1;
        message += `${teamNum}. ${team.name}\n`;
        message += `   Division: ${team.division}\n`;
        message += `   Players: ${team.health.playerCount}\n`;
        message += `   Current Week: ${team.health.hasCurrentWeek ? '✅' : '❌'}\n`;
        message += `   Next Week: ${team.health.hasNextWeek ? '✅' : '❌'}\n`;
        message += `   Last Push: ${team.health.lastPushAge}\n`;
        message += `   Data: ${getDataStatusIndicator(team.health.dataIntegrity)}\n\n`;
      });
      
      if (i + chunkSize < teams.length) {
        const response = ui.alert('Team Status', message + 'Continue to next page?', ui.ButtonSet.YES_NO);
        if (response !== ui.Button.YES) break;
      } else {
        ui.alert('Team Status', message, ui.ButtonSet.OK);
      }
    }
    
  } catch (e) {
    Logger.log(`HubHealthCheck: Detailed status error: ${e.message}`);
    ui.alert('Error', `Failed to get team details: ${e.message}`, ui.ButtonSet.OK);
  }
}

/**
 * Gets data status indicator for display
 * @param {string} integrity - Data integrity status
 * @return {string} User-friendly indicator
 */
function getDataStatusIndicator(integrity) {
  switch (integrity) {
    case "valid":
    case "basic_valid":
      return "✅ Good";
    case "incomplete":
      return "⚠️ Incomplete";
    case "malformed":
    case "invalid":
      return "❌ Invalid";
    case "corrupted":
    case "error":
      return "💥 Error";
    case "no_data":
      return "📭 No Data";
    default:
      return "❓ Unknown";
  }
}

// ========== TESTING FUNCTIONS ==========

/**
 * Test function for hub health check system
 * Can be run from Script Editor
 */
function debugTestHubHealthCheck() {
  try {
    Logger.log("=== HUB HEALTH CHECK TEST ===");
    
    const healthStatus = getHubHealthStatus();
    
    if (healthStatus.error) {
      Logger.log(`❌ Health check failed: ${healthStatus.error}`);
      return false;
    }
    
    const summary = healthStatus.summary;
    const weekAlignment = healthStatus.weekAlignment;
    
    Logger.log("✅ Health check completed successfully");
    Logger.log(`📊 Summary: ${summary.totalTeams} total, ${summary.activeTeams} active teams`);
    Logger.log(`📅 Week alignment: ${weekAlignment.status} (Current: ${weekAlignment.teamsWithCurrent}, Next: ${weekAlignment.teamsWithNext})`);
    Logger.log(`⚠️ Issues: ${summary.dataIntegrityIssues} data integrity problems`);
    Logger.log(`📈 Recent activity: ${summary.recentlyUpdated} teams updated in 24h`);
    
    // Test specific teams
    const testTeams = healthStatus.teams.slice(0, 3);
    Logger.log(`\n🔍 Sample team details:`);
    testTeams.forEach((team, i) => {
      Logger.log(`${i + 1}. ${team.name}: ${team.health.hasCurrentWeek ? '✅' : '❌'} current, ${team.health.hasNextWeek ? '✅' : '❌'} next, Data: ${team.health.dataIntegrity}`);
    });
    
    Logger.log("=== TEST COMPLETE ===");
    return true;
    
  } catch (e) {
    Logger.log(`❌ Test failed: ${e.message}`);
    return false;
  }
}

/**
 * Comprehensive hub monitoring system validation
 * Run this from Script Editor to validate complete functionality
 */
function validateHubMonitoringSystem() {
  try {
    Logger.log("=== COMPREHENSIVE HUB MONITORING VALIDATION ===");
    
    let allTestsPassed = true;
    const results = {
      hubAccess: false,
      dataProcessing: false,
      summaryCalculation: false,
      weekAlignment: false,
      dataIntegrity: false,
      uiIntegration: false
    };
    
    // Test 1: Hub Access
    Logger.log("\n📡 Testing hub access...");
    try {
      const hubSheet = SpreadsheetApp.openById(BLOCK_CONFIG.HUB.SPREADSHEET_ID);
      const masterlist = hubSheet.getSheetByName(BLOCK_CONFIG.HUB.MASTERLIST_SHEET);
      const dataSheet = hubSheet.getSheetByName(BLOCK_CONFIG.HUB.DATA_SHEET);
      
      if (masterlist && dataSheet) {
        results.hubAccess = true;
        Logger.log("✅ Hub access successful");
      } else {
        Logger.log("❌ Hub sheets not found");
        allTestsPassed = false;
      }
    } catch (e) {
      Logger.log(`❌ Hub access failed: ${e.message}`);
      allTestsPassed = false;
    }
    
    // Test 2: Data Processing
    Logger.log("\n🔄 Testing data processing...");
    try {
      const healthStatus = getHubHealthStatus();
      if (healthStatus && !healthStatus.error && healthStatus.teams) {
        results.dataProcessing = true;
        Logger.log(`✅ Data processing successful - found ${healthStatus.teams.length} teams`);
      } else {
        Logger.log(`❌ Data processing failed: ${healthStatus.error || 'Unknown error'}`);
        allTestsPassed = false;
      }
    } catch (e) {
      Logger.log(`❌ Data processing error: ${e.message}`);
      allTestsPassed = false;
    }
    
    // Test 3: Summary Calculation
    Logger.log("\n📊 Testing summary calculation...");
    try {
      const healthStatus = getHubHealthStatus();
      if (healthStatus.summary && typeof healthStatus.summary.totalTeams === 'number') {
        results.summaryCalculation = true;
        Logger.log(`✅ Summary calculation successful - ${healthStatus.summary.totalTeams} teams analyzed`);
      } else {
        Logger.log("❌ Summary calculation failed");
        allTestsPassed = false;
      }
    } catch (e) {
      Logger.log(`❌ Summary calculation error: ${e.message}`);
      allTestsPassed = false;
    }
    
    // Test 4: Week Alignment
    Logger.log("\n📅 Testing week alignment analysis...");
    try {
      const healthStatus = getHubHealthStatus();
      if (healthStatus.weekAlignment && healthStatus.weekAlignment.currentWeek) {
        results.weekAlignment = true;
        Logger.log(`✅ Week alignment analysis successful - current week ${healthStatus.weekAlignment.currentWeek}, status: ${healthStatus.weekAlignment.status}`);
      } else {
        Logger.log("❌ Week alignment analysis failed");
        allTestsPassed = false;
      }
    } catch (e) {
      Logger.log(`❌ Week alignment error: ${e.message}`);
      allTestsPassed = false;
    }
    
    // Test 5: Data Integrity Validation
    Logger.log("\n🔍 Testing data integrity validation...");
    try {
      const healthStatus = getHubHealthStatus();
      const teamsWithDataIssues = healthStatus.teams.filter(t => 
        t.health.dataIntegrity !== "valid" && 
        t.health.dataIntegrity !== "basic_valid" && 
        t.health.dataIntegrity !== "no_data"
      );
      
      results.dataIntegrity = true;
      Logger.log(`✅ Data integrity validation successful - ${teamsWithDataIssues.length} teams with issues identified`);
    } catch (e) {
      Logger.log(`❌ Data integrity validation error: ${e.message}`);
      allTestsPassed = false;
    }
    
    // Test 6: UI Integration Functions
    Logger.log("\n🖥️ Testing UI integration functions...");
    try {
      // Test that functions exist and can be called (without triggering UI)
      if (typeof showHubHealthStatus === 'function' && typeof showDetailedTeamStatus === 'function') {
        results.uiIntegration = true;
        Logger.log("✅ UI integration functions available");
      } else {
        Logger.log("❌ UI integration functions missing");
        allTestsPassed = false;
      }
    } catch (e) {
      Logger.log(`❌ UI integration test error: ${e.message}`);
      allTestsPassed = false;
    }
    
    // Final Results
    Logger.log("\n" + "=".repeat(50));
    Logger.log("📋 VALIDATION RESULTS:");
    Logger.log(`Hub Access: ${results.hubAccess ? '✅ PASS' : '❌ FAIL'}`);
    Logger.log(`Data Processing: ${results.dataProcessing ? '✅ PASS' : '❌ FAIL'}`);
    Logger.log(`Summary Calculation: ${results.summaryCalculation ? '✅ PASS' : '❌ FAIL'}`);
    Logger.log(`Week Alignment: ${results.weekAlignment ? '✅ PASS' : '❌ FAIL'}`);
    Logger.log(`Data Integrity: ${results.dataIntegrity ? '✅ PASS' : '❌ FAIL'}`);
    Logger.log(`UI Integration: ${results.uiIntegration ? '✅ PASS' : '❌ FAIL'}`);
    Logger.log("");
    Logger.log(`🎯 OVERALL RESULT: ${allTestsPassed ? '✅ ALL TESTS PASSED' : '❌ SOME TESTS FAILED'}`);
    
    if (allTestsPassed) {
      Logger.log("\n🎉 Hub Monitoring System is ready for production use!");
      Logger.log("📋 Available admin functions:");
      Logger.log("   - Hub Health Overview (quick status)");
      Logger.log("   - Detailed Team Status (team-by-team breakdown)");
      Logger.log("   - Menu: Schedule Manager [ADMIN] > 🏥 Hub Health Monitoring");
    }
    
    Logger.log("=== VALIDATION COMPLETE ===");
    return allTestsPassed;
    
  } catch (e) {
    Logger.log(`❌ Validation system error: ${e.message}`);
    return false;
  }
}