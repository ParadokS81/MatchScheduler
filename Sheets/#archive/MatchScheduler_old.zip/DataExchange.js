/**
 * Schedule Manager - Data Exchange (ENHANCED WITH UNIFIED LAYOUT)
 * 
 * @version 1.5.0 (2025-05-22)
 * 
 * Description: Simple, clean data exchange between teams with unified layout
 * ENHANCED: Unified team layout (5 players rows 4-8, logo A9:B15) for all teams
 */

/**
 * Stores the user's selected teams in properties
 * @version 1.3.1 (2025-05-21) - Improved ID standardization
 * @param {string[]} teamNames - Array of selected team names
 * @return {boolean} Success indicator
 */
function storeSelectedTeams(teamNames) {
  try {
    if (!Array.isArray(teamNames)) {
      Logger.log("Invalid team selection format");
      return false;
    }
    
    // Standardize all IDs as strings
    const standardizedIds = teamNames.map(id => String(id));
    
    const userProps = PropertiesService.getUserProperties();
    userProps.setProperty('selectedTeams', JSON.stringify(standardizedIds));
    
    Logger.log(`Saved selection of ${standardizedIds.length} teams`);
    return true;
  } catch (e) {
    Logger.log(`Error saving team selection: ${e.message}`);
    return false;
  }
}

/**
 * Gets the user's selected teams from properties
 * @version 1.3.1 (2025-05-21) - Added type standardization
 * @return {string[]} - Array of selected team names
 */
function getSelectedTeams() {
  const userProps = PropertiesService.getUserProperties();
  const selectedTeamsJson = userProps.getProperty('selectedTeams');
  
  if (selectedTeamsJson) {
    try {
      // Ensure all IDs are returned as strings for consistent comparison
      const teams = JSON.parse(selectedTeamsJson);
      return teams.map(id => String(id));
    } catch (e) {
      Logger.log(`Error parsing selected teams: ${e.message}`);
    }
  }
  
  return [];
}

/**
 * Pulls selected teams' availability and displays in the sheet with debug output
 * @version 1.4.2 (2025-05-21) - Added comprehensive debug output to UI
 * @return {boolean} Success indicator
 */
function displaySelectedTeamsAvailability() {
  const ui = SpreadsheetApp.getUi();
  let debugInfo = ""; // Collect debug info to show in UI
  
  try {
    // SYNC WARNING: Check if user should proceed with out-of-sync operation
    if (!showSyncWarningIfNeeded()) {
      Logger.log("User cancelled operation due to sync warning");
      return false;
    }
    
    // Get selected teams
    const selectedTeams = getSelectedTeams();
    
    if (!selectedTeams || selectedTeams.length === 0) {
      ui.alert("No teams selected. Please select teams from the sidebar first.");
      return false;
    }
    
    debugInfo += `Selected teams: ${selectedTeams.length}\n`;
    Logger.log(`Selected teams for display: ${JSON.stringify(selectedTeams)}`);
    
    // Fetch team data (this now uses smart filtering automatically)
    const teamsData = fetchTeamsData(selectedTeams);
    
    if (!teamsData || teamsData.length === 0) {
      ui.alert("No availability data found for the selected teams. This could be because there's no data for the current week (week " + getCurrentWeekNumber() + ").");
      return false;
    }
    
    // Check if any teams were filtered out due to no current/next week data
    const filteredOutCount = selectedTeams.length - teamsData.length;
    if (filteredOutCount > 0) {
      const continueResponse = ui.alert(
        "Smart Filtering Notice",
        `${filteredOutCount} team(s) don't have current or next week data and will be skipped.\n\nOnly teams with relevant week data will be displayed. Continue?`,
        ui.ButtonSet.YES_NO
      );
      
      if (continueResponse !== ui.Button.YES) {
        return false;
      }
    }
    
    // Get current sheet
    const sheet = SpreadsheetApp.getActiveSpreadsheet().getActiveSheet();
    
    // Clear other teams area before displaying new data
    Logger.log("DataExchange: Clearing other teams area before display");
    clearOtherTeamsArea(sheet);
    
    // Display teams starting below own team (position 1, 2, 3...)
    let successfulDisplays = 0;
    const maxTeams = Math.min(teamsData.length, 5); // Limit to 5 teams
    
    debugInfo += `Teams to display: ${maxTeams}\n\n`;
    
    for (let i = 0; i < maxTeams; i++) {
      const opponentPosition = i + 1; // Start at position 1 (below own team)
      
      try {
        // Get position info for debugging
        const teamPosition = getStandardBlockPosition(opponentPosition, false);
        debugInfo += `Team ${opponentPosition} (${teamsData[i].teamName}):\n`;
        debugInfo += `- Position: Row ${teamPosition.row}\n`;
        
        const success = displayTeamData(sheet, teamsData[i], opponentPosition);
        if (success) {
          successfulDisplays++;
          debugInfo += `- Status: ✅ Displayed\n`;
          
          // Apply colors and collect results
          Logger.log(`DataExchange: Applying colors after displaying team ${teamsData[i].teamName}`);
          try {
            // Call the coloring function from BlockApplier.js
            if (typeof applyColorToAllBlocks === 'function') {
              const result = applyColorToAllBlocks(false);
              debugInfo += `- Colors: ${result ? '✅ Applied' : '❌ Failed'}\n`;
              Logger.log(`DataExchange: Color result for team: ${result}`);
            } else {
              debugInfo += `- Colors: ❌ Function not found\n`;
              Logger.log("DataExchange: applyColorToAllBlocks function not found!");
            }
          } catch (colorError) {
            debugInfo += `- Colors: ❌ Error: ${colorError.message}\n`;
            Logger.log(`DataExchange: Color error: ${colorError.message}`);
          }
        } else {
          debugInfo += `- Status: ❌ Failed to display\n`;
        }
        debugInfo += `\n`;
        
      } catch (e) {
        debugInfo += `- Status: ❌ Error: ${e.message}\n\n`;
        Logger.log(`Error displaying ${teamsData[i].teamName}: ${e.message}`);
      }
    }
    
    // Check block detection after display
    try {
      const blocks = findAllBlocks();
      debugInfo += `Block Detection After Display:\n`;
      debugInfo += `- Total blocks found: ${blocks.length}\n`;
      blocks.forEach((block, i) => {
        debugInfo += `- Block ${i+1}: Week ${block.weekNumber} at Row ${block.row}\n`;
      });
    } catch (e) {
      debugInfo += `Block detection error: ${e.message}\n`;
    }
    
    // Show success message with comprehensive debug info
    let message = `Successfully displayed ${successfulDisplays} team(s) below your schedule.\n\n`;
    
    // Add info about smart filtering
    const currentWeek = getCurrentWeekNumber();
    message += `Smart filtering applied: Only showing weeks ${currentWeek} and ${currentWeek + 1}.\n\n`;
    
    // Add debug info
    message += `DEBUG INFO:\n${debugInfo}`;
    
    ui.alert("Display Results", message, ui.ButtonSet.OK);
    return true;
    
  } catch (e) {
    Logger.log(`Error displaying teams: ${e.message}`);
    ui.alert("Error: " + e.message);
    return false;
  }
}

/**
 * Enhanced team data display with freshness information and UNIFIED layout
 * @param {Sheet} sheet - The sheet to display on
 * @param {Object} teamData - Team data to display
 * @param {number} teamIndex - Team position index
 * @return {boolean} Success indicator
 */
function displayTeamData(sheet, teamData, teamIndex) {
  try {
    // Use standard positioning from BLOCK_CONFIG
    const teamPosition = getStandardBlockPosition(teamIndex, false); // Get left position
    const teamRowStart = teamPosition.row;
    
    Logger.log(`DataExchange: Displaying team ${teamData.teamName} at standard position row ${teamRowStart}`);
    Logger.log(`DataExchange: Standard position details: ${JSON.stringify(teamPosition)}`);
    
    // Get freshness info
    const freshness = getTeamFreshness(teamData);
    
    // Display team header with freshness indicator and proper background colors
    sheet.getRange(teamRowStart, 1).setValue("🏮 Team")
         .setFontWeight("bold")
         .setBackground(BLOCK_CONFIG.COLORS.TEAM_HEADER);
    sheet.getRange(teamRowStart, 2).setValue(`${freshness.indicator} ${teamData.teamName} (${freshness.status})`)
         .setFontWeight("bold")
         .setBackground(BLOCK_CONFIG.COLORS.TEAM_NAME);
    
    // Add freshness description as a note
    try {
      sheet.getRange(teamRowStart, 2).setNote(freshness.description);
    } catch (e) {
      // Ignore note errors
    }
    
    // UNIFIED: Display players with same layout as own team (only 5 players, rows 4-8 relative)
    const players = teamData.players || [];
    const playerIcons = ["🛡️", "⚔️", "🏹", "🎲", "👤"];
    const maxPlayers = Math.min(players.length, BLOCK_CONFIG.LAYOUT.MAX_PLAYERS); // Max 5 players
    
    for (let i = 0; i < BLOCK_CONFIG.LAYOUT.MAX_PLAYERS; i++) {
      const playerRow = teamRowStart + 1 + i; // teamRowStart + 1, 2, 3, 4, 5 (equivalent to rows 4-8)
      
      if (i < players.length) {
        const playerName = players[i];
        const playerInitial = playerName.substring(0, 2).toUpperCase();
        
        // Apply initials with background color (UNIFIED: same colors as own team)
        sheet.getRange(playerRow, 1).setValue(playerIcons[i] + " " + playerInitial)
             .setHorizontalAlignment("center")
             .setBackground(BLOCK_CONFIG.COLORS.PLAYER_INITIALS);
        
        // Apply player name with background color (UNIFIED: same colors as own team)
        sheet.getRange(playerRow, 2).setValue(playerName)
             .setBackground(BLOCK_CONFIG.COLORS.PLAYER_NAMES);
      } else {
        // Clear unused player slots but keep background colors for consistency
        sheet.getRange(playerRow, 1).setValue("")
             .setBackground(BLOCK_CONFIG.COLORS.PLAYER_INITIALS);
        sheet.getRange(playerRow, 2).setValue("")
             .setBackground(BLOCK_CONFIG.COLORS.PLAYER_NAMES);
      }
    }
    
    // UNIFIED: Display logo in same position as own team (A9:B15 relative)
    const logoRowStart = teamRowStart + 6; // teamRowStart + 6 = after 5 player rows
    try {
      const logoRange = sheet.getRange(logoRowStart, 1, 7, 2); // 7 rows, 2 columns (A9:B15 equivalent)
      logoRange.merge();
      
      if (teamData.logoUrl && teamData.logoUrl.trim() !== "") {
        // Display team logo if available
        logoRange.setFormula(`=IMAGE("${teamData.logoUrl}", 1)`);
        logoRange.setHorizontalAlignment("center");
        logoRange.setVerticalAlignment("middle");
        logoRange.setBorder(true, true, true, true, false, false, "#E0E0E0", SpreadsheetApp.BorderStyle.SOLID);
        Logger.log(`DataExchange: Set logo for ${teamData.teamName}: ${teamData.logoUrl}`);
      } else {
        // Display logo placeholder
        logoRange.setValue("🏮 Team Logo");
        logoRange.setFontSize(12);
        logoRange.setFontColor("#999999");
        logoRange.setHorizontalAlignment("center");
        logoRange.setVerticalAlignment("middle");
        logoRange.setBorder(true, true, true, true, false, false, "#E0E0E0", SpreadsheetApp.BorderStyle.DASHED);
        Logger.log(`DataExchange: Set logo placeholder for ${teamData.teamName}`);
      }
    } catch (logoError) {
      Logger.log(`DataExchange: Error setting up logo for ${teamData.teamName}: ${logoError.message}`);
    }
    
    // DEBUG: Log where we're about to create week blocks
    if (teamData.weeks && teamData.weeks.length > 0) {
      const weeks = [...teamData.weeks];
      weeks.sort((a, b) => a.weekNumber - b.weekNumber);
      
      for (let w = 0; w < Math.min(2, weeks.length); w++) {
        const isRightWeek = (w === 1);
        const weekPosition = getStandardBlockPosition(teamIndex, isRightWeek);
        Logger.log(`DataExchange: Week ${weeks[w].weekNumber} will be created at row ${teamRowStart}, col ${weekPosition.col}`);
      }
    }
    
    // Display weeks (up to 2, smart filtered)
    if (teamData.weeks && teamData.weeks.length > 0) {
      const weeks = [...teamData.weeks];
      weeks.sort((a, b) => a.weekNumber - b.weekNumber); // Sort by week number ascending
      
      for (let w = 0; w < Math.min(2, weeks.length); w++) {
        const week = weeks[w];
        const isRightWeek = (w === 1);
        
        // Use standard positioning for week blocks
        const weekPosition = getStandardBlockPosition(teamIndex, isRightWeek);
        const startCol = weekPosition.col;
        const timeCol = weekPosition.timeCol;
        
        Logger.log(`DataExchange: Creating week block for ${teamData.teamName} week ${week.weekNumber} at col ${startCol}`);
        
        try {
          const block = createWeekBlockAtPosition(
            sheet, 
            teamRowStart, 
            startCol,
            timeCol,
            calculateMondayFromWeekNumber(week.weekNumber)
          );
          
          // Fill with data
          if (week.grid && Array.isArray(week.grid)) {
            fillBlockWithCounts(sheet, block, week.grid);
          }
        } catch (e) {
          Logger.log(`Error creating block for ${teamData.teamName} week ${week.weekNumber}: ${e.message}`);
        }
      }
    }
    
    return true;
    
  } catch (e) {
    Logger.log(`Error displaying team ${teamData.teamName}: ${e.message}`);
    return false;
  }
}

/**
 * Fills a block with availability data
 * @param {Sheet} sheet - The sheet to modify
 * @param {Object} block - Block information
 * @param {Array} gridData - 2D array of availability data
 */
function fillBlockWithCounts(sheet, block, gridData) {
  if (!gridData || !gridData.length) return;
  
  try {
    // Clean the data
    const safeGridData = gridData.map(row => 
      row.map(cell => cell === null || cell === undefined ? "" : cell)
    );
    
    // Get the range
    const range = sheet.getRange(
      block.timeStartRow,
      block.col,
      Math.min(block.gridHeight, safeGridData.length),
      Math.min(block.gridWidth, safeGridData[0].length)
    );
    
    // Fill the range
    const existingValues = range.getValues();
    
    for (let r = 0; r < Math.min(existingValues.length, safeGridData.length); r++) {
      for (let c = 0; c < Math.min(existingValues[0].length, safeGridData[r].length); c++) {
        if (safeGridData[r][c].toString().trim() !== "") {
          existingValues[r][c] = safeGridData[r][c];
        }
      }
    }
    
    range.setValues(existingValues);
  } catch (e) {
    Logger.log(`Error filling block: ${e.message}`);
  }
}

/**
 * Clears the other teams area before displaying new data
 * @param {Sheet} sheet - The sheet to clear
 */
function clearOtherTeamsArea(sheet) {
  try {
    // Use standard positioning to calculate clear areas
    // Clear teams 1-5 (teamIndex 1-5, since 0 is own team)
    for (let teamIndex = 1; teamIndex <= 5; teamIndex++) {
      const teamPosition = getStandardBlockPosition(teamIndex, false);
      const teamRowStart = teamPosition.row;
      const teamRowEnd = teamRowStart + BLOCK_CONFIG.LAYOUT.TEAM_SPACING - 1;
      
      Logger.log(`DataExchange: Clearing team ${teamIndex} area rows ${teamRowStart}-${teamRowEnd}`);
      
      // Clear this team's entire area
      const clearRange = sheet.getRange(teamRowStart, 1, BLOCK_CONFIG.LAYOUT.TEAM_SPACING, 18);
      clearRange.clear(); // Clear content, formatting, and notes
    }
    
    Logger.log("DataExchange: Other teams area cleared using standard positions");
    
  } catch (e) {
    Logger.log(`DataExchange: Error clearing other teams area: ${e.message}`);
    // Fallback to old method
    const startRow = 18;
    const numRows = 75; 
    const numCols = 18;
    const clearRange = sheet.getRange(startRow, 1, numRows, numCols);
    clearRange.clear();
    Logger.log("DataExchange: Used fallback clearing method");
  }
}

/**
 * Calculates a Monday date from a week number
 * @param {number} weekNumber - ISO week number
 * @return {Date} Monday date
 */
function calculateMondayFromWeekNumber(weekNumber) {
  const year = new Date().getFullYear();
  const firstThursday = new Date(year, 0, 4);
  const dayOffset = firstThursday.getDay();
  const thursdayOffset = dayOffset === 0 ? 3 : dayOffset > 4 ? dayOffset - 4 : dayOffset + 3;
  
  firstThursday.setDate(firstThursday.getDate() - thursdayOffset);
  
  const targetThursday = new Date(firstThursday);
  targetThursday.setDate(firstThursday.getDate() + (weekNumber - 1) * 7);
  
  const targetMonday = new Date(targetThursday);
  targetMonday.setDate(targetThursday.getDate() - 3);
  
  return targetMonday;
}

// Enhanced placeholder functions
function freezeOwnTeamSchedule() {
  try {
    const sheet = SpreadsheetApp.getActiveSpreadsheet().getActiveSheet();
    
    // Freeze the first 17 rows (own team + headers) 
    sheet.setFrozenRows(17);
    
    Logger.log("DataExchange: Frozen first 17 rows for own team comparison");
    return true;
  } catch (e) {
    Logger.log(`DataExchange: Error freezing rows: ${e.message}`);
    return false;
  }
}