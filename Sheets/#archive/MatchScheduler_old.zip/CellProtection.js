/**
 * Schedule Manager - Native Cell Protection System
 * 
 * @version 2.0.0 (Phase 2 - Native Protection Implementation)
 * 
 * Description: Uses Google Sheets native range protection instead of reactive onEdit triggers
 * ARCHITECTURE: True protection - users cannot edit protected areas at all
 * BYPASS: Temporary protection removal for authorized sidebar operations
 */

// Protection range constants
const PROTECTED_RANGE = "A1:T17"; // Team info + own schedule grid
const PROTECTION_DESCRIPTION = "Schedule Manager Protected Area - Use sidebar to edit";

/**
 * Creates native range protection for the schedule area
 * @return {boolean} Success indicator
 */
function installNativeProtection() {
  try {
    const sheet = SpreadsheetApp.getActiveSpreadsheet().getActiveSheet();
    
    // Remove any existing protection first
    removeAllProtections();
    
    // Create protection on the range
    const range = sheet.getRange(PROTECTED_RANGE);
    const protection = range.protect();
    
    // Set description for user clarity
    protection.setDescription(PROTECTION_DESCRIPTION);
    
    // Remove all editors except the script itself
    protection.removeEditors(protection.getEditors());
    
    // Get current user/script owner and add as editor
    try {
      const currentUser = Session.getEffectiveUser().getEmail();
      if (currentUser) {
        protection.addEditor(currentUser);
      }
    } catch (e) {
      Logger.log(`Note: Could not add current user as editor: ${e.message}`);
    }
    
    Logger.log(`Native protection: Successfully protected range ${PROTECTED_RANGE}`);
    return true;
    
  } catch (e) {
    Logger.log(`Error installing native protection: ${e.message}`);
    return false;
  }
}

/**
 * Removes all existing protections from the sheet
 * @return {boolean} Success indicator
 */
function removeAllProtections() {
  try {
    const sheet = SpreadsheetApp.getActiveSpreadsheet().getActiveSheet();
    const protections = sheet.getProtections(SpreadsheetApp.ProtectionType.RANGE);
    
    let removed = 0;
    protections.forEach(protection => {
      try {
        protection.remove();
        removed++;
      } catch (e) {
        Logger.log(`Could not remove protection: ${e.message}`);
      }
    });
    
    Logger.log(`Native protection: Removed ${removed} existing protection(s)`);
    return true;
    
  } catch (e) {
    Logger.log(`Error removing protections: ${e.message}`);
    return false;
  }
}

/**
 * Executes a function with temporary protection bypass
 * This is the core bypass mechanism for all sidebar operations
 * @param {Function} operation - Function to execute with protection removed
 * @param {string} operationName - Name for logging purposes
 * @return {*} Result of the operation
 */
function withProtectionBypass(operation, operationName = "Unknown Operation") {
  let protectionWasActive = false;
  let protectionInstance = null;
  
  try {
    Logger.log(`Protection bypass: Starting "${operationName}"`);
    
    // Check if protection exists and remove it temporarily
    const sheet = SpreadsheetApp.getActiveSpreadsheet().getActiveSheet();
    const protections = sheet.getProtections(SpreadsheetApp.ProtectionType.RANGE);
    
    // Find our protection
    for (const protection of protections) {
      const range = protection.getRange();
      if (range.getA1Notation() === PROTECTED_RANGE) {
        protectionInstance = protection;
        protectionWasActive = true;
        protection.remove();
        Logger.log(`Protection bypass: Temporarily removed protection for "${operationName}"`);
        break;
      }
    }
    
    // Execute the operation
    const result = operation();
    
    Logger.log(`Protection bypass: Operation "${operationName}" completed successfully`);
    return result;
    
  } catch (e) {
    Logger.log(`Protection bypass: Error in operation "${operationName}": ${e.message}`);
    throw e;
    
  } finally {
    // Always restore protection if it was active
    if (protectionWasActive) {
      try {
        const sheet = SpreadsheetApp.getActiveSpreadsheet().getActiveSheet();
        const range = sheet.getRange(PROTECTED_RANGE);
        const newProtection = range.protect();
        newProtection.setDescription(PROTECTION_DESCRIPTION);
        newProtection.removeEditors(newProtection.getEditors());
        
        // Add current user back as editor
        try {
          const currentUser = Session.getEffectiveUser().getEmail();
          if (currentUser) {
            newProtection.addEditor(currentUser);
          }
        } catch (e) {
          Logger.log(`Note: Could not re-add current user as editor: ${e.message}`);
        }
        
        Logger.log(`Protection bypass: Restored protection after "${operationName}"`);
        
      } catch (e) {
        Logger.log(`CRITICAL: Failed to restore protection after "${operationName}": ${e.message}`);
        // Try to install fresh protection
        installNativeProtection();
      }
    }
  }
}

/**
 * Gets the current protection status
 * @return {Object} Protection system status
 */
function getProtectionStatus() {
  try {
    const sheet = SpreadsheetApp.getActiveSpreadsheet().getActiveSheet();
    const protections = sheet.getProtections(SpreadsheetApp.ProtectionType.RANGE);
    
    // Check if our protection exists
    let ourProtection = null;
    for (const protection of protections) {
      const range = protection.getRange();
      if (range.getA1Notation() === PROTECTED_RANGE) {
        ourProtection = protection;
        break;
      }
    }
    
    return {
      isProtected: !!ourProtection,
      protectedRange: PROTECTED_RANGE,
      description: ourProtection ? ourProtection.getDescription() : null,
      totalProtections: protections.length,
      protectionType: "native_range_protection",
      canEdit: ourProtection ? ourProtection.canEdit() : false
    };
    
  } catch (e) {
    Logger.log(`Error getting protection status: ${e.message}`);
    return {
      isProtected: false,
      protectedRange: PROTECTED_RANGE,
      description: null,
      totalProtections: 0,
      protectionType: "native_range_protection",
      canEdit: false,
      error: e.message
    };
  }
}

/**
 * Manual protection installer (for testing/setup)
 * @return {boolean} Success indicator
 */
function setupNativeProtection() {
  try {
    const success = installNativeProtection();
    
    if (success) {
      SpreadsheetApp.getActiveSpreadsheet().toast(
        'Native protection installed. Rows 1-17 are now protected.',
        'Protection Enabled',
        3
      );
    }
    
    return success;
    
  } catch (e) {
    Logger.log(`Error in setupNativeProtection: ${e.message}`);
    return false;
  }
}

/**
 * Manual protection remover (for testing/debugging)
 * @return {boolean} Success indicator
 */
function removeNativeProtection() {
  try {
    const success = removeAllProtections();
    
    if (success) {
      SpreadsheetApp.getActiveSpreadsheet().toast(
        'Native protection removed. All areas can now be edited.',
        'Protection Disabled',
        3
      );
    }
    
    return success;
    
  } catch (e) {
    Logger.log(`Error in removeNativeProtection: ${e.message}`);
    return false;
  }
}

/**
 * PHASE 2 COMPLETE: Comprehensive test function for native protection system
 * @return {Object} Test results for Phase 2 native implementation
 */
function testPhase2NativeProtectionComplete() {
  try {
    Logger.log("=== PHASE 2: NATIVE PROTECTION SYSTEM - COMPLETE TEST ===");
    
    const results = {
      protectionInstallation: false,
      bypassMechanism: false,
      protectionRestoration: false,
      systemIntegration: false,
      overallSuccess: false,
      error: null
    };
    
    // Test 1: Protection installation
    try {
      const installResult = installNativeProtection();
      const status = getProtectionStatus();
      results.protectionInstallation = installResult && status.isProtected;
      Logger.log(`✓ Protection installation: ${results.protectionInstallation ? 'PASS' : 'FAIL'} (Protected: ${status.isProtected})`);
    } catch (e) {
      Logger.log(`✗ Protection installation: ERROR (${e.message})`);
    }
    
    // Test 2: Bypass mechanism
    try {
      let testPassed = false;
      
      withProtectionBypass(() => {
        // Test operation that would normally be blocked
        const sheet = SpreadsheetApp.getActiveSpreadsheet().getActiveSheet();
        const testValue = "BYPASS_TEST_" + new Date().getTime();
        sheet.getRange("A1").setValue(testValue);
        
        // Verify the write worked
        const readValue = sheet.getRange("A1").getValue();
        testPassed = (readValue === testValue);
        
        // Clean up
        sheet.getRange("A1").setValue("Availability");
      }, "Test Bypass Operation");
      
      results.bypassMechanism = testPassed;
      Logger.log(`✓ Bypass mechanism: ${results.bypassMechanism ? 'PASS' : 'FAIL'}`);
    } catch (e) {
      Logger.log(`✗ Bypass mechanism: ERROR (${e.message})`);
    }
    
    // Test 3: Protection restoration after bypass
    try {
      const statusAfterBypass = getProtectionStatus();
      results.protectionRestoration = statusAfterBypass.isProtected;
      Logger.log(`✓ Protection restoration: ${results.protectionRestoration ? 'PASS' : 'FAIL'} (Still protected: ${statusAfterBypass.isProtected})`);
    } catch (e) {
      Logger.log(`✗ Protection restoration: ERROR (${e.message})`);
    }
    
    // Test 4: System integration readiness
    try {
      const hasCorrectFunctions = (typeof withProtectionBypass === 'function') &&
                                 (typeof installNativeProtection === 'function') &&
                                 (typeof getProtectionStatus === 'function');
      
      results.systemIntegration = hasCorrectFunctions;
      Logger.log(`✓ System integration: ${results.systemIntegration ? 'PASS' : 'FAIL'} (Functions available)`);
    } catch (e) {
      Logger.log(`✗ System integration: ERROR (${e.message})`);
    }
    
    // Overall result
    results.overallSuccess = results.protectionInstallation && results.bypassMechanism && 
                            results.protectionRestoration && results.systemIntegration;
    
    Logger.log("=== PHASE 2 NATIVE PROTECTION TEST RESULTS ===");
    Logger.log(`Protection Installation: ${results.protectionInstallation ? '✓' : '✗'}`);
    Logger.log(`Bypass Mechanism: ${results.bypassMechanism ? '✓' : '✗'}`);
    Logger.log(`Protection Restoration: ${results.protectionRestoration ? '✓' : '✗'}`);
    Logger.log(`System Integration: ${results.systemIntegration ? '✓' : '✗'}`);
    Logger.log(`PHASE 2 OVERALL: ${results.overallSuccess ? 'SUCCESS' : 'FAILED'}`);
    
    if (results.overallSuccess) {
      Logger.log("🎉 PHASE 2: NATIVE PROTECTION SYSTEM IMPLEMENTATION COMPLETE!");
      Logger.log("📋 Benefits over reactive system:");
      Logger.log("  • Users cannot edit protected cells AT ALL");
      Logger.log("  • No formatting/color corruption possible");
      Logger.log("  • Clean, immediate user feedback");
      Logger.log("  • Standard Google Sheets behavior");
      Logger.log("");
      Logger.log("📋 Next Steps:");
      Logger.log("  1. Try editing cells in rows 1-17 directly → Should be blocked");
      Logger.log("  2. Use sidebar 'Add Me'/'Remove Me' → Should work normally");
      Logger.log("  3. Verify cells below row 17 remain editable");
    } else {
      Logger.log("❌ PHASE 2: Issues detected - check individual test results above");
    }
    
    return results;
    
  } catch (e) {
    Logger.log(`=== PHASE 2 NATIVE PROTECTION TEST ERROR: ${e.message} ===`);
    return { error: e.message, overallSuccess: false };
  }
}