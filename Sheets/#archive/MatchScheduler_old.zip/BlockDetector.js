/**
 * Schedule Manager - Block Detector
 * 
 * @version 1.2.0 (2025-05-25 01:05)
 * 
 * Description: Identifies and analyzes week blocks - FIXED for 2x5 player layout
 * UPDATED: Adjusted column positions after adding 2 player columns (initials + names)
 * Week headers moved from D(4)+L(12) to F(6)+N(14)
 */

// Block cache with timestamp for invalidation
let blockCache = {
  blocks: null,
  timestamp: 0,
  sheetId: null
};

/**
 * Gets all blocks with position-based detection and caching
 * @param {Boolean} forceRefresh - Whether to force a refresh
 * @return {Object[]} Array of block objects
 */
function findAllBlocks(forceRefresh = false) {
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getActiveSheet();
  const currentSheetId = sheet.getSheetId();
  const now = new Date().getTime();
  
  // Check if we can use cache
  if (!forceRefresh && 
      blockCache.blocks && 
      blockCache.sheetId === currentSheetId && 
      (now - blockCache.timestamp < 300000)) {
    return blockCache.blocks;
  }
  
  const blocks = [];
  
  // FIXED: Updated positions for new 2x5 player layout (+2 columns shift)
  // Format: [team index, row, leftCol, rightCol]
  const knownPositions = [
    [0, 3, 6, 14],    // First team: week headers at F3 and N3 ✅ (was D3+L3)
    [1, 18, 6, 14],   // Second team: week headers at F18 and N18 ✅ (was D18+L18)
    [2, 33, 6, 14],   // Third team: week headers at F33 and N33 ✅ (was D33+L33)
    [3, 48, 6, 14],   // Fourth team: week headers at F48 and N48 ✅ (was D48+L48)
    [4, 63, 6, 14],   // Fifth team: week headers at F63 and N63 ✅ (was D63+L63)
  ];
  
  // Check up to 5 teams using the corrected positions
  for (let i = 0; i < knownPositions.length; i++) {
    const [teamIndex, weekRow, leftCol, rightCol] = knownPositions[i];
    
    // Check for left week block
    try {
      const leftValue = sheet.getRange(weekRow, leftCol).getValue();
      const leftWeekInfo = parseWeekHeader(String(leftValue));
      
      if (leftWeekInfo) {
        const leftBlock = createBlockFromPosition(sheet, weekRow, leftCol, leftWeekInfo.weekNumber);
        if (leftBlock) {
          blocks.push(leftBlock);
        }
      }
    } catch (e) {
      // No left block at this position
    }
    
    // Check for right week block
    try {
      const rightValue = sheet.getRange(weekRow, rightCol).getValue();
      const rightWeekInfo = parseWeekHeader(String(rightValue));
      
      if (rightWeekInfo) {
        const rightBlock = createBlockFromPosition(sheet, weekRow, rightCol, rightWeekInfo.weekNumber);
        if (rightBlock) {
          blocks.push(rightBlock);
        }
      }
    } catch (e) {
      // No right block at this position
    }
  }
  
  // Fallback: Check calculated positions if known positions don't yield results
  if (blocks.length <= 2) { // Only own team found
    for (let i = 0; i < 5; i++) {
      let weekRow;
      let leftCol, rightCol;
      
      // Calculate position based on team spacing: 3 + (i * 15)
      weekRow = 3 + (i * 15); // This matches the actual positioning system
      leftCol = 6;  // column F (was D=4, now +2 = F=6)
      rightCol = 14; // column N (was L=12, now +2 = N=14)
      
      // Skip if we already checked this position in knownPositions
      const alreadyChecked = knownPositions.some(pos => pos[1] === weekRow);
      if (alreadyChecked) continue;
      
      // Check for left week block
      try {
        const leftValue = sheet.getRange(weekRow, leftCol).getValue();
        const leftWeekInfo = parseWeekHeader(String(leftValue));
        
        if (leftWeekInfo) {
          const leftBlock = createBlockFromPosition(sheet, weekRow, leftCol, leftWeekInfo.weekNumber);
          if (leftBlock) {
            blocks.push(leftBlock);
          }
        }
      } catch (e) {
        // No left block at this position
      }
      
      // Check for right week block
      try {
        const rightValue = sheet.getRange(weekRow, rightCol).getValue();
        const rightWeekInfo = parseWeekHeader(String(rightValue));
        
        if (rightWeekInfo) {
          const rightBlock = createBlockFromPosition(sheet, weekRow, rightCol, rightWeekInfo.weekNumber);
          if (rightBlock) {
            blocks.push(rightBlock);
          }
        }
      } catch (e) {
        // No right block at this position
      }
    }
  }
  
  // Sort blocks by row position
  blocks.sort((a, b) => a.row - b.row);
  
  // Update cache
  blockCache = {
    blocks: blocks,
    timestamp: now,
    sheetId: currentSheetId
  };
  
  Logger.log(`Position-based detection found ${blocks.length} week blocks`);
  return blocks;
}

/**
 * Invalidates the block cache
 */
function invalidateBlockCache() {
  blockCache.blocks = null;
  blockCache.timestamp = 0;
  Logger.log("Block cache invalidated");
}

/**
 * Creates a block object based on known position and structure
 * @param {Sheet} sheet - The sheet containing the block
 * @param {Number} row - 1-based row index of week header
 * @param {Number} col - 1-based column index of week header
 * @param {Number} weekNumber - Week number from header
 * @return {Object|null} Block metadata
 */
function createBlockFromPosition(sheet, row, col, weekNumber) {
  try {
    // Get month header (to the left of week header)
    let monthHeader = "";
    try {
      monthHeader = sheet.getRange(row, col - 1).getValue();
    } catch (e) {
      // Month header might be missing
    }
    
    // Day headers are in the row below
    const dayHeadersRow = row + 1;
    const timeCol = col - 1;
    
    // Get day headers (we know there are exactly 7)
    const dayHeaders = [];
    try {
      // Get all day headers in one call
      const headerValues = sheet.getRange(dayHeadersRow, col, 1, 7).getValues()[0];
      for (const value of headerValues) {
        dayHeaders.push(String(value));
      }
    } catch (e) {
      // If range read fails, create empty day headers
      for (let i = 0; i < 7; i++) {
        dayHeaders.push("");
      }
    }
    
    // Time slots start below day headers
    const timeStartRow = dayHeadersRow + 1;
    const timeSlots = [];
    
    // Get time slots
    try {
      const timeCells = sheet.getRange(timeStartRow, timeCol, BLOCK_CONFIG.TIME.STANDARD_SLOTS.length, 1);
      const timeValues = timeCells.getValues();
      for (const row of timeValues) {
        timeSlots.push(String(row[0]));
      }
    } catch (e) {
      // Fallback to standard slots from config
      timeSlots.push(...BLOCK_CONFIG.TIME.STANDARD_SLOTS);
    }
    
    // Create block with standard dimensions
    return {
      row: row,
      col: col,
      timeCol: timeCol,
      weekNumber: weekNumber,
      month: monthHeader,
      dayHeaders: dayHeaders,
      timeSlots: timeSlots,
      gridWidth: 7, // Always 7 days
      gridHeight: timeSlots.length,
      dayHeadersRow: dayHeadersRow,
      timeStartRow: timeStartRow
    };
  } catch (e) {
    Logger.log(`Error creating block at position row ${row}, col ${col}: ${e.message}`);
    return null;
  }
}

/**
 * Gets a block at a specific position
 * @param {Number} teamIndex - Team index (0-based)
 * @param {Boolean} isRightWeek - Whether it's the right week
 * @return {Object|null} Block metadata or null if not found
 */
function getBlockByPosition(teamIndex, isRightWeek) {
  // FIXED: Use the actual positioning system: 3 + (teamIndex * 15)
  const weekRow = 3 + (teamIndex * 15);
  const weekCol = isRightWeek ? 14 : 6; // N or F column (was L=12 or D=4)
  
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getActiveSheet();
  
  try {
    // Check if there's a week header at this position
    const value = sheet.getRange(weekRow, weekCol).getValue();
    const weekInfo = parseWeekHeader(String(value));
    
    if (weekInfo) {
      return createBlockFromPosition(sheet, weekRow, weekCol, weekInfo.weekNumber);
    }
  } catch (e) {
    // Position doesn't have a valid block
  }
  
  // Fallback to cached blocks if direct position check fails
  const blocks = findAllBlocks();
  
  if (blocks.length === 0) {
    Logger.log("No blocks found through detection");
    return null;
  }
  
  // If we have exactly 2 blocks and teamIndex is 0, use position to determine
  if (blocks.length === 2 && teamIndex === 0) {
    // Sort by column position
    blocks.sort((a, b) => a.col - b.col);
    
    return isRightWeek ? blocks[1] : blocks[0];
  }
  
  // For multiple teams, we expect blocks to be in pairs
  const teamStartIdx = teamIndex * 2;
  if (teamStartIdx + 1 < blocks.length) {
    // Sort by row then column
    blocks.sort((a, b) => {
      if (a.row !== b.row) return a.row - b.row;
      return a.col - b.col;
    });
    
    return isRightWeek ? blocks[teamStartIdx + 1] : blocks[teamStartIdx];
  }
  
  Logger.log(`No block found for team ${teamIndex}, ${isRightWeek ? "right" : "left"} week`);
  return null;
}

/**
 * Parses a week header string
 * @param {String} text - Text to parse
 * @return {Object|null} Week information or null if invalid
 */
function parseWeekHeader(text) {
  if (!text) return null;
  
  // Match "Week XX" format with flexible spacing
  const match = String(text).match(/week\s*(\d+)/i);
  
  if (match) {
    return {
      weekNumber: parseInt(match[1])
    };
  }
  
  return null;
}

/**
 * Checks if a value is likely a day header
 * @param {*} value - Value to check
 * @return {Boolean} True if likely a day header
 */
function isLikelyDayHeader(value) {
  if (!value) return false;
  
  const text = String(value).toLowerCase();
  
  // Check for day abbreviations
  const dayAbbrs = ["mon", "tue", "wed", "thu", "fri", "sat", "sun"];
  return dayAbbrs.some(day => text.includes(day));
}

/**
 * Checks if a value is in time format
 * @param {*} value - Value to check
 * @return {Boolean} True if a time value
 */
function isTimeValue(value) {
  if (!value) return false;
  
  const text = String(value);
  
  // Match common time formats
  return text.match(/^\d{1,2}:\d{2}$/) !== null;
}
