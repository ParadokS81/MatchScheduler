/**
 * Schedule Manager - Block Creator (PHASE 2: NATIVE PROTECTION INTEGRATED)
 * 
 * @version 1.3.0 (2025-05-25) - PHASE 2 COMPLETE - NATIVE PROTECTION BYPASS
 * 
 * Description: Creates and formats week blocks - UPDATED for 2x5 roster layout (10 players) with native protection
 * PHASE 2: All schedule creation uses protection bypass and ensures protection reinstallation
 * ARCHITECTURE: Single authority for schedule creation with complete protection handling
 */

/**
 * Creates a week block at the standard position
 * @param {Sheet} sheet - Sheet to create block in
 * @param {Number} teamIndex - Team index (0-based)
 * @param {Boolean} isRightWeek - Whether this is the right block
 * @param {Date} weekStart - Start date for this week (Monday)
 * @return {Object} Created block metadata
 */
function createWeekBlock(sheet, teamIndex, isRightWeek, weekStart) {
  // Get standard position for this block
  const position = getStandardBlockPosition(teamIndex, isRightWeek);
  
  // Create the block at the specified position
  return createWeekBlockAtPosition(
    sheet, 
    position.row, 
    position.col, 
    position.timeCol,
    weekStart
  );
}

/**
 * Creates a week block at a specific position
 * @param {Sheet} sheet - Sheet to create block in
 * @param {Number} row - 1-based row index for week header
 * @param {Number} col - 1-based column index for week header
 * @param {Number} timeCol - 1-based column index for time column
 * @param {Date} weekStart - Start date for this week (Monday)
 * @return {Object} Created block metadata
 */
function createWeekBlockAtPosition(sheet, row, col, timeCol, weekStart) {
  try {
    // 1. Calculate week info
    const monday = new Date(weekStart);
    const weekNumber = getISOWeekNumber(monday);
    const monthName = getMonthName(monday);
    
    // 2. Set month and week headers
    sheet.getRange(row, col - 1).setValue(monthName);
    sheet.getRange(row, col).setValue("Week " + weekNumber);
    
    // Format headers
    sheet.getRange(row, col - 1, 1, 2)
         .setFontWeight("bold")
         .setHorizontalAlignment("center")
         .setBackground(BLOCK_CONFIG.COLORS.MONTH_HEADER);
    
    // 3. Set day headers
    const dayHeadersRow = row + 1;
    setDayHeaders(sheet, dayHeadersRow, col, monday);
    
    // 4. Set time slots
    const timeStartRow = dayHeadersRow + 1;
    const timeSlotCount = setTimeSlots(sheet, timeStartRow, timeCol);
    
    // 5. Set day cells with appropriate backgrounds
    setEmptyDayCells(sheet, timeStartRow, col, timeSlotCount);
    
    // 6. Add borders
    sheet.getRange(dayHeadersRow, col, timeSlotCount + 1, 7)
      .setBorder(true, true, true, true, false, false);
    
    // Return block metadata
    return {
      row: row,
      col: col,
      timeCol: timeCol,
      weekNumber: weekNumber,
      month: monthName,
      dayHeaders: getDayHeadersArray(monday),
      timeSlots: BLOCK_CONFIG.TIME.STANDARD_SLOTS,
      gridWidth: 7,
      gridHeight: timeSlotCount,
      dayHeadersRow: dayHeadersRow,
      timeStartRow: timeStartRow
    };
  } catch (e) {
    Logger.log(`Error creating week block: ${e.message}`);
    throw e;
  }
}

/**
 * PHASE 2 COMPLIANT: Creates a complete schedule with protection bypass and reinstallation
 * Single authority function for all schedule creation
 * @param {String} teamName - Team name to use (or null to preserve existing)
 * @param {String[]} playerNames - Array of player names (or null to preserve existing)
 * @return {Object[]} Created blocks or error
 */
function createScheduleWithProtection(teamName, playerNames) {
  try {
    Logger.log("Creating complete schedule with Phase 2 protection compliance");
    
    // PHASE 2: Use protection bypass for entire schedule creation
    const result = withProtectionBypass(() => {
      const sheet = SpreadsheetApp.getActiveSpreadsheet().getActiveSheet();
      
      // 1. Save existing team and player names if needed
      if (!teamName || !playerNames) {
        const existingTeamName = sheet.getRange("B3").getValue() || "";
        
        const existingPlayerNames = [];
        const maxPlayers = BLOCK_CONFIG.LAYOUT.MAX_PLAYERS; // Now 10
        
        // UPDATED: Read from 2x5 layout positions
        const allPositions = getAllSlotPositions();
        for (const position of allPositions) {
          const existingValue = sheet.getRange(position.row, position.nameCol).getValue();
          // Safe string conversion - handle null, undefined, or non-string values
          const existingName = existingValue && typeof existingValue === 'string' ? existingValue.trim() : "";
          existingPlayerNames.push(existingName);
        }
        
        teamName = teamName || existingTeamName;
        playerNames = playerNames || existingPlayerNames;
      }
      
      // 2. Clear the schedule areas (preserve A-D columns for roster)
      clearScheduleAreas(sheet);
      
      // 3. Set up title and team header
      setupTitleAndTeamHeader(sheet, teamName);
      
      // 4. Set player rows (UPDATED: 2x5 layout, 10 players)
      setupPlayerRows(sheet, playerNames);
      
      // 5. Create week blocks
      const currentMonday = getCurrentMonday();
      const nextMonday = getNextMonday();
      
      // 6. Create current week block (left)
      const leftBlock = createWeekBlock(sheet, 0, false, currentMonday);
      
      // 7. Create next week block (right)
      const rightBlock = createWeekBlock(sheet, 0, true, nextMonday);
      
      // 8. Set column widths
      setColumnWidths(sheet);
      
      // 9. Set up logo placeholder (A9:D15) to make the area visible
      const logoRange = sheet.getRange(9, 1, 7, 4); // A9:D15
      logoRange.merge();
      logoRange.setValue("🏮 Team Logo (A9:D15)");
      logoRange.setFontSize(12);
      logoRange.setFontColor("#999999");
      logoRange.setHorizontalAlignment("center");
      logoRange.setVerticalAlignment("middle");
      logoRange.setBorder(true, true, true, true, false, false, "#E0E0E0", SpreadsheetApp.BorderStyle.DASHED);
      
      return [leftBlock, rightBlock];
      
    }, "Create Complete Schedule");
    
    // PHASE 2 CRITICAL: Always reinstall protection after schedule creation
    if (result && typeof installNativeProtection === 'function') {
      const protectionSuccess = installNativeProtection();
      if (protectionSuccess) {
        Logger.log("Protection successfully reinstalled after schedule creation");
      } else {
        Logger.log("WARNING: Failed to reinstall protection after schedule creation");
      }
    }
    
    Logger.log("Schedule creation completed with Phase 2 protection compliance");
    return result;
    
  } catch (e) {
    Logger.log(`Error in createScheduleWithProtection: ${e.message}`);
    
    // Emergency protection reinstallation attempt
    try {
      if (typeof installNativeProtection === 'function') {
        installNativeProtection();
        Logger.log("Emergency protection reinstallation attempted");
      }
    } catch (protectionError) {
      Logger.log(`Emergency protection reinstallation failed: ${protectionError.message}`);
    }
    
    throw e;
  }
}

/**
 * LEGACY: Maintains backward compatibility for existing calls
 * Routes to Phase 2 compliant function
 * @param {String} teamName - Team name
 * @param {String[]} playerNames - Player names
 * @return {Object[]} Created blocks
 */
function createSchedule(teamName, playerNames) {
  Logger.log("Legacy createSchedule() called - routing to Phase 2 compliant function");
  return createScheduleWithProtection(teamName, playerNames);
}

/**
 * UPDATED: Clears schedule areas without touching roster (A-D columns) and team info
 * @param {Sheet} sheet - Sheet to clear
 */
function clearScheduleAreas(sheet) {
  try {
    // Check if sheet has any content first
    const lastRow = Math.max(sheet.getLastRow(), 30); // Ensure we clear enough rows
    const lastCol = sheet.getLastColumn();
    
    // Only clear if sheet has columns beyond D (column 4)
    if (lastCol > 4) {
      // Clear columns E and beyond (preserve A-D for roster)
      sheet.getRange(1, 5, lastRow, lastCol - 4).clear();
    } else {
      Logger.log("Sheet has no content beyond column D, skipping clear");
    }
    
    SpreadsheetApp.flush();
  } catch (e) {
    Logger.log(`Warning in clearScheduleAreas: ${e.message} - continuing anyway`);
    // Continue anyway - this is just a clearing operation
  }
}

/**
 * Sets up title and team header
 * @param {Sheet} sheet - Sheet to modify
 * @param {String} teamName - Team name to use
 */
function setupTitleAndTeamHeader(sheet, teamName) {
  // No title row - start directly with team header
  
  // Team header in row 3
  sheet.getRange(3, 1)
       .setValue("Team")
       .setFontWeight("bold")
       .setHorizontalAlignment("center")
       .setBackground(BLOCK_CONFIG.COLORS.TEAM_HEADER);
  
  // Set team name with custom background color
  if (teamName) {
    sheet.getRange(3, 2)
         .setValue(teamName)
         .setBackground(BLOCK_CONFIG.COLORS.TEAM_NAME);
  }
}

/**
 * UPDATED: Sets up player rows with 2x5 layout (10 players in A-D columns, rows 4-8)
 * @param {Sheet} sheet - Sheet to modify
 * @param {String[]} playerNames - Player names to use (up to 10)
 */
function setupPlayerRows(sheet, playerNames) {
  const defaultNames = [
    "Player 1", "Player 2", "Player 3", "Player 4", "Player 5",
    "Player 6", "Player 7", "Player 8", "Player 9", "Player 10"
  ]; // UPDATED: 10 default players
  
  // SAFETY: Ensure playerNames is an array and contains safe string values
  const safePlayerNames = Array.isArray(playerNames) ? playerNames : [];
  
  const maxPlayers = BLOCK_CONFIG.LAYOUT.MAX_PLAYERS; // 10 players
  const allPositions = getAllSlotPositions(); // Get all 10 slot positions
  
  // Clear roster area first (A4:D8)
  sheet.getRange(4, 1, 5, 4).clearContent();
  
  for (let slotNumber = 1; slotNumber <= maxPlayers; slotNumber++) {
    const position = getSlotPosition(slotNumber);
    const playerIndex = slotNumber - 1;
    
    // Safe string handling - check if value exists and is a string
    const playerValue = safePlayerNames[playerIndex];
    const hasValidPlayer = playerValue && typeof playerValue === 'string' && playerValue.trim() !== "";
    
    if (hasValidPlayer) {
      // Player provided
      const name = String(playerValue).trim();
      const initial = name.substring(0, 2).toUpperCase();
      
      // Set initials with background color
      sheet.getRange(position.row, position.initialsCol)
           .setValue(initial)
           .setHorizontalAlignment("center")
           .setBackground(BLOCK_CONFIG.COLORS.PLAYER_INITIALS);
      
      // Set player name with background color
      sheet.getRange(position.row, position.nameCol)
           .setValue(name)
           .setBackground(BLOCK_CONFIG.COLORS.PLAYER_NAMES);
           
    } else if (slotNumber <= 5) {
      // For slots 1-5, use default names if no player provided
      const name = defaultNames[playerIndex];
      const initial = name.substring(0, 2).toUpperCase();
      
      sheet.getRange(position.row, position.initialsCol)
           .setValue(initial)
           .setHorizontalAlignment("center")
           .setBackground(BLOCK_CONFIG.COLORS.PLAYER_INITIALS);
      
      sheet.getRange(position.row, position.nameCol)
           .setValue(name)
           .setBackground(BLOCK_CONFIG.COLORS.PLAYER_NAMES);
    } else {
      // For slots 6-10, leave empty if no player provided, but set background colors
      sheet.getRange(position.row, position.initialsCol)
           .setValue("")
           .setBackground(BLOCK_CONFIG.COLORS.PLAYER_INITIALS);
      
      sheet.getRange(position.row, position.nameCol)
           .setValue("")
           .setBackground(BLOCK_CONFIG.COLORS.PLAYER_NAMES);
    }
  }
  
  Logger.log(`Setup 2x5 roster layout with ${Math.min(safePlayerNames.length, maxPlayers)} players`);
}

/**
 * Sets day headers for a week block
 * @param {Sheet} sheet - Sheet to modify
 * @param {Number} row - 1-based row index for day headers
 * @param {Number} startCol - 1-based column index for first day
 * @param {Date} monday - Monday date for this week
 */
function setDayHeaders(sheet, row, startCol, monday) {
  const weekdays = BLOCK_CONFIG.LAYOUT.DAYS;
  
  for (let d = 0; d < 7; d++) {
    const day = new Date(monday);
    day.setDate(monday.getDate() + d);
    const date = day.getDate();
    const suffix = getOrdinalSuffix(date);
    const label = `${weekdays[d]} ${date}${suffix}`;
    
    sheet.getRange(row, startCol + d)
         .setValue(label)
         .setFontWeight("bold")
         .setBackground(BLOCK_CONFIG.COLORS.DAY_HEADER);
  }
}

/**
 * Creates an array of day header strings
 * @param {Date} monday - Monday date for this week
 * @return {String[]} Array of day header strings
 */
function getDayHeadersArray(monday) {
  const weekdays = BLOCK_CONFIG.LAYOUT.DAYS;
  const headers = [];
  
  for (let d = 0; d < 7; d++) {
    const day = new Date(monday);
    day.setDate(monday.getDate() + d);
    const date = day.getDate();
    const suffix = getOrdinalSuffix(date);
    headers.push(`${weekdays[d]} ${date}${suffix}`);
  }
  
  return headers;
}

/**
 * Sets time slots for a block
 * @param {Sheet} sheet - Sheet to modify
 * @param {Number} startRow - 1-based row index for first time slot
 * @param {Number} col - 1-based column index for time values
 * @return {Number} Number of time slots created
 */
function setTimeSlots(sheet, startRow, col) {
  const timeSlots = BLOCK_CONFIG.TIME.STANDARD_SLOTS;
  
  for (let t = 0; t < timeSlots.length; t++) {
    const timeValue = timeSlots[t];
    const isHourMark = timeValue.endsWith(":00");
    
    sheet.getRange(startRow + t, col)
         .setValue(timeValue)
         .setHorizontalAlignment("center")
         .setFontWeight(isHourMark ? "bold" : "normal")
         .setBackground(BLOCK_CONFIG.COLORS.TIME_COLUMN);
  }
  
  return timeSlots.length;
}

/**
 * Sets empty day cells with appropriate backgrounds
 * @param {Sheet} sheet - Sheet to modify
 * @param {Number} startRow - 1-based row index for first grid cell
 * @param {Number} startCol - 1-based column index for first grid cell
 * @param {Number} rowCount - Number of rows to create
 */
function setEmptyDayCells(sheet, startRow, startCol, rowCount) {
  // Prepare backgrounds array for batch update
  const backgrounds = [];
  
  for (let r = 0; r < rowCount; r++) {
    const rowBackgrounds = [];
    
    for (let d = 0; d < 7; d++) {
      const isWeekend = (d >= 5); // Sat and Sun
      rowBackgrounds.push(isWeekend ? 
                          BLOCK_CONFIG.COLORS.WEEKEND : 
                          BLOCK_CONFIG.COLORS.WEEKDAY);
    }
    
    backgrounds.push(rowBackgrounds);
  }
  
  // Apply all backgrounds at once
  sheet.getRange(startRow, startCol, rowCount, 7).setBackgrounds(backgrounds);
}

/**
 * UPDATED: Sets optimized column widths for 2x5 roster layout
 * @param {Sheet} sheet - Sheet to modify
 */
function setColumnWidths(sheet) {
  const widths = BLOCK_CONFIG.LAYOUT.COLUMN_WIDTHS;
  
  // ROSTER COLUMNS (A-D)
  sheet.setColumnWidth(1, widths.INITIALS);    // A: Left initials (70px - 4 char width)
  sheet.setColumnWidth(2, widths.NAMES);       // B: Left names (100px, 12 chars)
  sheet.setColumnWidth(3, widths.INITIALS);    // C: Right initials (70px - 4 char width)
  sheet.setColumnWidth(4, widths.NAMES);       // D: Right names (100px, 12 chars)
  
  // TIME COLUMNS (no buffer columns)
  sheet.setColumnWidth(5, widths.TIME);        // E: Left time column (60px)
  sheet.setColumnWidth(13, widths.TIME);       // M: Right time column (60px)
  
  // LEFT WEEK DAYS (F-L)
  for (let col = 6; col <= 12; col++) {
    sheet.setColumnWidth(col, widths.SCHEDULE_DAY); // 95px each
  }
  
  // RIGHT WEEK DAYS (N-T)
  for (let col = 14; col <= 20; col++) {
    sheet.setColumnWidth(col, widths.SCHEDULE_DAY); // 95px each
  }
  
  Logger.log("Set column widths for 2x5 roster layout: A(70) B(100) C(70) D(100) E(60) F-L(95) M(60) N-T(95)");
}

/**
 * Gets the month name for a date
 * @param {Date} date - The date to get month from
 * @return {String} Month name
 */
function getMonthName(date) {
  return Utilities.formatDate(date, BLOCK_CONFIG.TIME.TIMEZONE, "MMMM");
}