/**
 * Schedule Manager - UI Controller (PHASE 1: BACKEND SAFETY - AUTH INTEGRATION)
 * 
 * @version 1.8.0 (2025-05-24) - PHASE 1 COMPLETE - BACKEND SAFETY
 * 
 * Description: Handles user interface interactions and sidebar with slot adoption support
 * PHASE 1: Added missing backend functions for auth-only system preparation
 * NEW: joinTeam(), getSlotStatus(), banPlayerFromTeam() for sidebar interface
 * SAFETY: All changes are additive - no existing functionality removed
 */

/**
 * Gets available divisions from teams data (more efficient than separate hub call)
 * @return {string[]} Array of unique division names
 */
function getAvailableDivisions() {
  try {
    Logger.log("Getting available divisions from teams data");
    
    // Get teams data (we already have division info here)
    const teams = getAvailableTeams("no"); // Exclude own team
    
    if (teams.length === 0) {
      Logger.log("No teams found, returning empty divisions array");
      return [];
    }
    
    // Extract unique divisions from teams data
    const divisions = new Set();
    for (const team of teams) {
      if (team.division && String(team.division).trim() !== "") {
        divisions.add(String(team.division).trim());
      }
    }
    
    // Convert to array and sort
    const divisionsArray = Array.from(divisions).sort();
    Logger.log(`Found ${divisionsArray.length} unique divisions: ${divisionsArray.join(', ')}`);
    
    return divisionsArray;
    
  } catch (e) {
    Logger.log(`Error getting divisions: ${e.message}`);
    return [];
  }
}

/**
 * Generates clean teams HTML with division filtering (simplified display)
 * @param {boolean} includeOwnTeam - Whether to include own team
 * @param {string} divisionFilter - Division to filter by (empty string for all)
 * @return {string} HTML string to display
 */
function getTeamsHtmlForSidebarFiltered(includeOwnTeam, divisionFilter = '') {
  try {
    const teamsParam = includeOwnTeam ? "yes" : "no";
    Logger.log(`Getting filtered teams HTML: includeOwnTeam=${teamsParam}, division="${divisionFilter}"`);
    
    // Get teams data
    const teams = getAvailableTeams(teamsParam);
    Logger.log(`Found ${teams.length} total teams`);
    
    if (teams.length === 0) {
      return '<div class="note">No teams available. Try registering your team first.</div>';
    }
    
    // Filter by division if specified
    let filteredTeams = teams;
    if (divisionFilter && divisionFilter.trim() !== '') {
      filteredTeams = teams.filter(team => 
        team.division && String(team.division).trim() === divisionFilter.trim()
      );
      Logger.log(`After division filter "${divisionFilter}": ${filteredTeams.length} teams`);
    }
    
    if (filteredTeams.length === 0) {
      return `<div class="note">No teams found in ${divisionFilter || 'selected division'}.</div>`;
    }
    
    // Get selected teams for checkbox state
    let selectedTeamIds = [];
    try {
      const userProps = PropertiesService.getUserProperties();
      const selectedTeamsJson = userProps.getProperty('selectedTeams');
      if (selectedTeamsJson) {
        selectedTeamIds = JSON.parse(selectedTeamsJson).map(id => String(id));
      }
    } catch (e) {
      Logger.log("Error getting selected teams: " + e.message);
    }
    
    // Generate clean HTML
    let html = '';
    
    for (const team of filteredTeams) {
      // Skip own team
      if (team.isOwnTeam) continue;
      
      // Standardize team ID for comparison
      const teamIdStr = String(team.sheetId);
      const isSelected = selectedTeamIds.includes(teamIdStr);
      
      html += '<div class="team-item">';
      html += '<input type="checkbox" class="team-checkbox" ' + 
              'data-team-name="' + escapeHtml(team.name) + '" ' +
              'data-team-id="' + teamIdStr + '" ' +
              (isSelected ? ' checked' : '') + '>';
      
      html += '<div class="team-content">';
      
      // Clean team name (no indicators, no status)
      html += '<div class="team-name">' + escapeHtml(team.name) + '</div>';
      
      // Clean players display (just the player names)
      let players = team.players || "No players listed";
      if (players.length > 80) {
        // Truncate if too long
        players = players.substring(0, 77) + "...";
      }
      
      html += '<div class="team-players">' + escapeHtml(players) + '</div>';
      html += '</div>';
      html += '</div>';
    }
    
    return html;
    
  } catch (e) {
    Logger.log("Error generating filtered teams HTML: " + e.message);
    return '<div class="note">Error loading teams: ' + e.message + '</div>';
  }
}

/**
 * Legacy function - redirects to filtered version for backward compatibility
 * @param {boolean} includeOwnTeam - Whether to include own team
 * @return {string} HTML string to display
 */
function getTeamsHtmlForSidebar(includeOwnTeam) {
  return getTeamsHtmlForSidebarFiltered(includeOwnTeam, '');
}

// ========== SLOT ADOPTION BACKEND FUNCTIONS ==========

/**
 * Checks if slot interface is needed for current user
 * @return {Object} Interface status and slot data
 */
function checkSlotInterfaceNeeded() {
  try {
    const accessMode = getAccessMode();
    const isAuthMode = (accessMode === "google_only");
    
    if (!isAuthMode) {
      return {isAuthMode: false, isAuthenticated: false};
    }
    
    const user = getCurrentAuthenticatedUser();
    if (!user) {
      return {isAuthMode: true, isAuthenticated: false};
    }
    
    const userSlot = getCurrentUserPlayerInfo();
    const rosterData = getTeamRosterForLeader();
    
    return {
      isAuthMode: true,
      isAuthenticated: true,
      userSlot: userSlot,
      availableSlots: rosterData.players.filter(p => !p.claimed).map(p => p.slot),
      allSlots: rosterData.players
    };
  } catch (e) {
    Logger.log(`Error checking slot interface: ${e.message}`);
    return {isAuthMode: false, isAuthenticated: false};
  }
}

/**
 * Releases current user's slot
 * @return {Object} Success status
 */
function releaseCurrentUserSlot() {
  try {
    const user = getCurrentAuthenticatedUser();
    if (!user) {
      return {success: false, message: "Not authenticated"};
    }
    
    const userSlot = getCurrentUserPlayerInfo();
    if (!userSlot) {
      return {success: false, message: "You don't have a slot to release"};
    }
    
    // Use existing function from UserManagerAuth.js
    const bindings = getUserBindings();
    delete bindings.players[user.email];
    saveUserBindings(bindings);
    
    // Clear from sheet
    const sheet = SpreadsheetApp.getActiveSpreadsheet().getActiveSheet();
    const playerRow = 3 + userSlot.slot;
    sheet.getRange(playerRow, 1).setValue("");
    sheet.getRange(playerRow, 2).setValue("");
    
    Logger.log(`User ${user.email} released slot ${userSlot.slot}`);
    return {success: true, message: "Slot released successfully"};
  } catch (e) {
    Logger.log(`Error releasing slot: ${e.message}`);
    return {success: false, message: "System error: " + e.message};
  }
}

/**
 * NEW: Edit user initials in authenticated mode
 * @return {Object} Success status and updated initials
 */
function editUserInitials() {
  try {
    const user = getCurrentAuthenticatedUser();
    if (!user) {
      return {success: false, message: "Authentication required"};
    }
    
    const userSlot = getCurrentUserPlayerInfo();
    if (!userSlot) {
      return {success: false, message: "You must have an adopted slot to edit initials"};
    }
    
    // Prompt for new initials
    const ui = SpreadsheetApp.getUi();
    const response = ui.prompt(
      'Edit Your Initials',
      `Current initials: ${userSlot.initials}\n\nEnter new initials (2 characters):`,
      ui.ButtonSet.OK_CANCEL
    );
    
    if (response.getSelectedButton() !== ui.Button.OK) {
      return {success: false, message: "Operation cancelled"};
    }
    
    const newInitials = response.getResponseText().trim().toUpperCase();
    
    if (!newInitials || newInitials.length !== 2) {
      return {success: false, message: "Initials must be exactly 2 characters"};
    }
    
    // Update user bindings
    const bindings = getUserBindings();
    if (bindings.players[user.email]) {
      bindings.players[user.email].initials = newInitials;
      const saveSuccess = saveUserBindings(bindings);
      
      if (!saveSuccess) {
        return {success: false, message: "Failed to save initials update"};
      }
      
      // Update sheet
      const sheet = SpreadsheetApp.getActiveSpreadsheet().getActiveSheet();
      const playerRow = 3 + userSlot.slot;
      sheet.getRange(playerRow, 1).setValue(newInitials);
      
      Logger.log(`User ${user.email} updated initials from ${userSlot.initials} to ${newInitials}`);
      
      return {
        success: true, 
        message: `Initials updated to ${newInitials}`,
        newInitials: newInitials
      };
    } else {
      return {success: false, message: "User slot binding not found"};
    }
    
  } catch (e) {
    Logger.log(`Error editing user initials: ${e.message}`);
    return {success: false, message: "System error: " + e.message};
  }
}

// ========== PHASE 1: NEW BACKEND FUNCTIONS FOR SIDEBAR SUPPORT ==========

/**
 * PHASE 1 NEW: Join team function for sidebar interface
 * Routes to existing slot claiming system with automatic slot selection
 * @param {string} playerName - Player name to use
 * @param {string} initials - Optional initials (auto-generated if empty)
 * @return {Object} Result with success status and message
 */
function joinTeam(playerName, initials = '') {
  try {
    Logger.log(`joinTeam called: playerName="${playerName}", initials="${initials}"`);
    
    if (!playerName || playerName.trim() === '') {
      return {success: false, message: "Player name is required"};
    }
    
    // Auto-generate initials if not provided
    let finalInitials = initials.trim().toUpperCase();
    if (!finalInitials || finalInitials.length === 0) {
      const nameParts = playerName.trim().split(/\s+/);
      finalInitials = nameParts.map(part => part.charAt(0)).join('').toUpperCase().substring(0, 2);
      if (finalInitials.length === 1) {
        finalInitials += playerName.charAt(1).toUpperCase();
      }
      if (finalInitials.length === 0) {
        finalInitials = 'XX';
      }
    }
    
    // Validate initials length
    if (finalInitials.length !== 2) {
      finalInitials = finalInitials.substring(0, 2).padEnd(2, 'X');
    }
    
    // Get available slots
    const rosterData = getTeamRosterForLeader();
    const availableSlots = rosterData.players.filter(p => !p.claimed);
    
    if (availableSlots.length === 0) {
      return {success: false, message: "No slots available on this team"};
    }
    
    // Find the first available slot (prioritize slot 1 for team leader)
    let slotNumber = availableSlots[0].slot;
    
    // Use existing claimPlayerSlotAuth function
    const result = claimPlayerSlotAuth(slotNumber, playerName.trim());
    
    Logger.log(`joinTeam result: ${JSON.stringify(result)}`);
    return result;
    
  } catch (e) {
    Logger.log(`Error in joinTeam: ${e.message}`);
    return {success: false, message: "System error: " + e.message};
  }
}

/**
 * PHASE 1 NEW: Get slot status information for sidebar
 * @return {Object} Slot availability status
 */
function getSlotStatus() {
  try {
    Logger.log("getSlotStatus called");
    
    const rosterData = getTeamRosterForLeader();
    const availableSlots = rosterData.players.filter(p => !p.claimed);
    const totalSlots = rosterData.players.length;
    
    const result = {
      availableSlots: availableSlots.length,
      totalSlots: totalSlots,
      teamLocked: false // TODO: Add team locking feature later
    };
    
    Logger.log(`getSlotStatus result: ${JSON.stringify(result)}`);
    return result;
    
  } catch (e) {
    Logger.log(`Error in getSlotStatus: ${e.message}`);
    return {availableSlots: 0, totalSlots: 10, teamLocked: false};
  }
}

/**
 * PHASE 1 NEW: Ban/remove player from team (team leader function)
 * Routes to existing kick system for compatibility
 * @param {string} email - Email of player to remove
 * @param {boolean} permanent - True for permanent ban, false for temporary
 * @return {Object} Result with success status and message
 */
function banPlayerFromTeam(email, permanent = false) {
  try {
    Logger.log(`banPlayerFromTeam called: email="${email}", permanent=${permanent}`);
    
    if (!email || email.trim() === '') {
      return {success: false, message: "Email address is required"};
    }
    
    // Route to existing kickUserFromTeam function
    const result = kickUserFromTeam(email.trim(), permanent);
    
    Logger.log(`banPlayerFromTeam result: ${JSON.stringify(result)}`);
    return result;
    
  } catch (e) {
    Logger.log(`Error in banPlayerFromTeam: ${e.message}`);
    return {success: false, message: "System error: " + e.message};
  }
}

/**
 * PHASE 1 NEW: Lock team to prevent new members (team leader function)
 * @param {number} maxSlots - Maximum number of slots to allow
 * @return {Object} Result with success status and message
 */
function lockTeamSize(maxSlots) {
  try {
    Logger.log(`lockTeamSize called: maxSlots=${maxSlots}`);
    
    if (!isCurrentUserTeamLeader()) {
      return {success: false, message: "Only team leaders can lock team size"};
    }
    
    if (maxSlots < 1 || maxSlots > 10) {
      return {success: false, message: "Team size must be between 1 and 10 players"};
    }
    
    // TODO: Implement team locking mechanism
    // For now, return success but note that feature needs implementation
    Logger.log(`Team lock requested for ${maxSlots} slots - feature pending implementation`);
    
    return {
      success: true,
      message: `Team size lock requested for ${maxSlots} players (feature pending implementation)`
    };
    
  } catch (e) {
    Logger.log(`Error in lockTeamSize: ${e.message}`);
    return {success: false, message: "System error: " + e.message};
  }
}

// ========== EXISTING FUNCTIONS (UNCHANGED) ==========

/**
 * Confirms and resets the schedule
 */
function resetScheduleWithConfirmation() {
  const ui = SpreadsheetApp.getUi();
  const response = ui.alert(
    'Reset Schedule',
    'This will create a new clean schedule with current and next week.\n\nExisting team and player names will be preserved. Continue?',
    ui.ButtonSet.YES_NO
  );
  
  if (response === ui.Button.YES) {
    createSchedule();
    ui.alert('Schedule has been reset to current and next week.');
  }
}

/**
 * Confirms and rolls forward one week
 */
function rollOneWeekWithConfirmation() {
  const ui = SpreadsheetApp.getUi();
  const response = ui.alert(
    'Roll Forward',
    'This will roll the schedule forward by one week.\n\nThe newer week will move to the left position and a new week will be created on the right. Continue?',
    ui.ButtonSet.YES_NO
  );
  
  if (response === ui.Button.YES) {
    rollOneWeekForward();
  }
}

/**
 * Tests hub connection and shows results in UI
 */
function testHubConnectionUI() {
  const result = testHubConnectivity();
  SpreadsheetApp.getUi().alert('Hub Connection Test', result, SpreadsheetApp.getUi().ButtonSet.OK);
}

/**
 * Handler for team registration from sidebar
 * @param {Object} data - Registration data from sidebar
 */
function registerTeamHandler(data) {
  try {
    const division = data.division || "Other";
    const success = registerTeamWithHub(division);
    
    if (success) {
      Logger.log(`Team registration updated with division: ${division}`);
    }
    
    return success;
  } catch (e) {
    Logger.log(`Error in registerTeamHandler: ${e.message}`);
    throw e;
  }
}

/**
 * Handler for changing user initials from sidebar
 */
function changeMyInitialsHandler() {
  try {
    // Clear stored initials to force re-prompt
    const userProps = PropertiesService.getUserProperties();
    userProps.deleteProperty('userInitials');
    
    // Get new initials (will prompt user)
    const newInitials = getUserInitials();
    
    if (newInitials) {
      SpreadsheetApp.getUi().alert(`Initials updated to: ${newInitials}`);
      return true;
    }
    
    return false;
  } catch (e) {
    Logger.log(`Error in changeMyInitialsHandler: ${e.message}`);
    throw e;
  }
}