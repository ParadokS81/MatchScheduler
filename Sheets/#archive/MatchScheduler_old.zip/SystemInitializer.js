/**
 * Schedule Manager - System Initializer
 * 
 * @version 1.4.0 (2025-05-25) - PHASE 2 COMPLETE: NATIVE PROTECTION SYSTEM
 * 
 * Description: Initializes the system and ensures a valid schedule exists + Native protection
 * PHASE 1: Single source architecture implemented ✅
 * PHASE 2: Native protection system with bypass mechanism ✅
 */

/**
 * Initializes the system when the spreadsheet opens
 * PHASE 2: Now installs native protection instead of onEdit triggers
 */
function initializeSystem() {
  Logger.log("Initializing Schedule Manager system (v1.4.0 - Native Protection + Slot Support)");
  
  try {
    // PHASE 2: Install native protection instead of triggers
    if (typeof installNativeProtection === 'function') {
      installNativeProtection();
      Logger.log("Native range protection installed");
    } else {
      Logger.log("WARNING: Native protection not available - installNativeProtection function missing");
    }
    
    // Check if a valid schedule exists
    if (!hasValidSchedule()) {
      Logger.log("No valid schedule found, determining initialization type");
      
      // NEW: Determine what type of team to initialize
      const initType = determineInitializationType();
      Logger.log(`Initialization type determined: ${initType}`);
      
      if (initType === "slot_based") {
        initializeSlotBasedTeam();
      } else {
        initializeFixedRosterTeam();
      }
    } else {
      Logger.log("Valid schedule found, ensuring rows are frozen");
      // Ensure rows are frozen even if schedule exists
      freezeOwnTeamRows();
    }
    
    return true;
  } catch (e) {
    Logger.log(`Error initializing system: ${e.message}`);
    console.error(e);
    return false;
  }
}

/**
 * NEW: Determines whether to initialize as slot-based or fixed roster team
 * @return {string} "slot_based" or "fixed_roster"
 */
function determineInitializationType() {
  try {
    // Method 1: Check if slot data already exists (migration case)
    const documentProps = PropertiesService.getDocumentProperties();
    const existingSlotData = documentProps.getProperty('slotData');
    if (existingSlotData) {
      Logger.log("Found existing slot data, initializing as slot-based team");
      return "slot_based";
    }
    
    // Method 2: Check URL parameters for team setup intent
    // In the future, this could check for ?type=slot_based in the URL
    
    // Method 3: Check for team leader setup intent
    // Could check for specific setup flags or user properties
    
    // Method 4: Default based on system configuration
    // For now, default to fixed roster to maintain backward compatibility
    // In the future, this could be configurable
    
    Logger.log("No slot data found, defaulting to fixed roster initialization");
    return "fixed_roster";
    
  } catch (e) {
    Logger.log(`Error determining initialization type: ${e.message}`);
    return "fixed_roster"; // Safe fallback
  }
}

/**
 * NEW: Initializes a slot-based team
 */
function initializeSlotBasedTeam() {
  Logger.log("Initializing slot-based team");
  
  try {
    // Check if TeamManager slot functions are available
    if (typeof setupTeamWithEmptySlots === 'undefined') {
      Logger.log("ERROR: setupTeamWithEmptySlots function not available, falling back to fixed roster");
      initializeFixedRosterTeam();
      return;
    }
    
    // For now, use placeholder values - in Phase 5 this would come from UI
    const defaultTeamName = "New Team";
    const defaultTeamLeader = getCurrentUserEmail() || "leader@example.com";
    
    // Set up team with empty slots
    setupTeamWithEmptySlots(defaultTeamName, defaultTeamLeader);
    
    // Apply row freezing
    freezeOwnTeamRows();
    
    Logger.log("Slot-based team initialization completed");
    
  } catch (e) {
    Logger.log(`Error in slot-based initialization: ${e.message}`);
    // Fallback to fixed roster
    Logger.log("Falling back to fixed roster initialization");
    initializeFixedRosterTeam();
  }
}

/**
 * NEW: Initializes a fixed roster team (legacy method)
 */
function initializeFixedRosterTeam() {
  Logger.log("Initializing fixed roster team");
  
  try {
    createSchedule();
    Logger.log("Fixed roster team initialization completed");
  } catch (e) {
    Logger.log(`Error in fixed roster initialization: ${e.message}`);
    throw e;
  }
}

/**
 * NEW: Gets current user email for slot-based team leader setup
 * @return {string|null} User email or null
 */
function getCurrentUserEmail() {
  try {
    const user = Session.getActiveUser();
    return user ? user.getEmail() : null;
  } catch (e) {
    Logger.log(`Error getting current user email: ${e.message}`);
    return null;
  }
}

/**
 * CRITICAL FUNCTION: Checks if the sheet has a valid schedule - ENHANCED DEBUGGING
 * @return {boolean} Whether a valid schedule exists
 */
function hasValidSchedule() {
  try {
    Logger.log("=== CRITICAL DEBUG: hasValidSchedule STARTED ===");
    
    const sheet = SpreadsheetApp.getActiveSpreadsheet().getActiveSheet();
    Logger.log("DEBUG: Got sheet: " + sheet.getName());
    
    // Check 1: Basic sheet dimensions
    Logger.log("DEBUG: Checking sheet dimensions...");
    const maxRows = sheet.getMaxRows();
    const maxCols = sheet.getMaxColumns();
    Logger.log("DEBUG: Sheet dimensions: " + maxRows + " rows x " + maxCols + " columns");
    
    if (maxRows < 15 || maxCols < 10) {
      Logger.log("DEBUG: Sheet too small (need at least 15 rows x 10 columns)");
      return false;
    }
    Logger.log("DEBUG: Sheet dimensions OK");
    
    // Check 2: Team name in correct position
    Logger.log("DEBUG: Checking team name in B3...");
    try {
      const teamCell = sheet.getRange("B3");
      const teamValue = teamCell.getValue();
      Logger.log("DEBUG: Team name in B3: '" + teamValue + "' (type: " + typeof teamValue + ")");
      
      if (!teamValue || String(teamValue).trim() === "") {
        Logger.log("DEBUG: No team name found in B3");
        return false;
      }
      Logger.log("DEBUG: Team name found: " + teamValue);
    } catch (e) {
      Logger.log("DEBUG: Error accessing B3: " + e.message);
      return false;
    }
    
    // Check 3: Block detection OR slot-based team structure
    Logger.log("DEBUG: Checking for blocks or slot-based structure...");
    let hasValidStructure = false;
    
    try {
      // Check if findAllBlocks function exists
      if (typeof findAllBlocks === 'undefined') {
        Logger.log("CRITICAL ERROR: findAllBlocks function is undefined!");
        return false;
      }
      
      const blocks = findAllBlocks();
      Logger.log("DEBUG: findAllBlocks() returned: " + (blocks ? "array with " + blocks.length + " items" : "null/undefined"));
      
      if (blocks && blocks.length > 0) {
        Logger.log("DEBUG: Found valid schedule blocks");
        hasValidStructure = true;
        
        blocks.forEach((block, i) => {
          Logger.log("DEBUG:   Block " + i + ": Week " + block.weekNumber + " at row " + block.row + ", col " + block.col);
        });
      } else {
        // NEW: Check for slot-based team structure
        Logger.log("DEBUG: No blocks found, checking for slot-based team...");
        const documentProps = PropertiesService.getDocumentProperties();
        const slotData = documentProps.getProperty('slotData');
        
        if (slotData) {
          Logger.log("DEBUG: Found slot-based team data");
          hasValidStructure = true;
        } else {
          Logger.log("DEBUG: No slot data found either");
        }
      }
    } catch (e) {
      Logger.log("CRITICAL ERROR: Structure check threw error: " + e.message);
      Logger.log("CRITICAL ERROR stack: " + e.stack);
      return false;
    }
    
    const isValid = hasValidStructure;
    Logger.log("=== CRITICAL DEBUG: hasValidSchedule RESULT: " + isValid + " ===");
    return isValid;
    
  } catch (e) {
    Logger.log("=== CRITICAL FAILURE: hasValidSchedule FAILED ===");
    Logger.log("CRITICAL ERROR: " + e.message);
    Logger.log("CRITICAL STACK: " + e.stack);
    return false;
  }
}

/**
 * Creates a new schedule preserving the team name and player names
 * @return {boolean} Success indicator
 */
function createSchedule() {
  Logger.log("Creating new schedule");
  
  try {
    const sheet = SpreadsheetApp.getActiveSpreadsheet().getActiveSheet();
    
    // Try to get existing team and player names
    let teamName = "";
    const playerNames = [];
    
    try {
      teamName = sheet.getRange("B3").getValue() || "Team";
      
      // UPDATED: Support both fixed roster (B4:B9) and slot-based (2x5 layout)
      const maxPlayers = BLOCK_CONFIG.LAYOUT.MAX_PLAYERS; // Now 10 for 2x5 layout
      
      if (isSlotBasedTeam()) {
        // For slot-based teams, get player names from slot data
        const adoptedPlayers = getAdoptedPlayers();
        for (let i = 0; i < adoptedPlayers.length; i++) {
          playerNames.push(adoptedPlayers[i].playerName);
        }
      } else {
        // For fixed roster teams, get from traditional positions
        for (let i = 0; i < Math.min(5, maxPlayers); i++) {
          try {
            playerNames.push(sheet.getRange(4 + i, 2).getValue() || "");
          } catch (e) {
            playerNames.push("");
          }
        }
      }
    } catch (e) {
      // Ignore errors - use defaults if we can't get existing names
    }
    
    // Calculate dates
    const today = new Date();
    const dayOffset = today.getDay() === 0 ? 6 : today.getDay() - 1; // Convert Sun(0)...Sat(6) to offset from Monday
    const currentMonday = new Date(today);
    currentMonday.setDate(today.getDate() - dayOffset);
    currentMonday.setHours(0, 0, 0, 0);
    
    // Calculate next Monday
    const nextMonday = new Date(currentMonday);
    nextMonday.setDate(currentMonday.getDate() + 7);
    
    // NEW: Preserve slot roster during schedule creation
    if (isSlotBasedTeam()) {
      Logger.log("Creating schedule for slot-based team, preserving slot structure");
      setupTeamHeaderOnly(sheet, teamName);
    } else {
      // 1. Clear the entire sheet to start fresh
      sheet.clear();
      
      // 2. Set title
      sheet.getRange("A1").setValue("Availability");
      sheet.getRange("A1").setFontWeight("bold").setFontSize(12);
      
      // 3. Set team info
      setupTeamSection(teamName, playerNames);
    }
    
    // 4. Create current week (left block)
    createWeekBlock(sheet, 0, false, currentMonday);
    
    // 5. Create next week (right block)
    createWeekBlock(sheet, 0, true, nextMonday);
    
    // 6. Apply colors
    applyColorsToAllBlocks();
    
    // 7. Set column widths
    setOptimizedColumnWidths(sheet);
    
    // 8. FREEZE OWN TEAM ROWS (rows 1-17) for easy comparison with other teams
    freezeOwnTeamRows();
    
    Logger.log("New schedule created successfully with frozen own team rows");
    return true;
  } catch (e) {
    Logger.log(`Error creating schedule: ${e.message}`);
    console.error(e);
    return false;
  }
}

/**
 * NEW: Sets up only team header, preserving existing slot structure
 * @param {Sheet} sheet - Sheet to modify  
 * @param {string} teamName - Team name
 */
function setupTeamHeaderOnly(sheet, teamName) {
  try {
    // Clear only the schedule areas (E and beyond), preserve A-D for slots
    const lastCol = sheet.getLastColumn();
    if (lastCol > 4) {
      sheet.getRange(1, 5, sheet.getLastRow(), lastCol - 4).clear();
    }
    
    // Set team header if not already set
    const currentTeamName = sheet.getRange("B3").getValue();
    if (!currentTeamName || String(currentTeamName).trim() === "") {
      sheet.getRange("A3").setValue("Team")
           .setFontWeight("bold")
           .setHorizontalAlignment("center")
           .setBackground(BLOCK_CONFIG.COLORS.TEAM_HEADER);
      sheet.getRange("B3").setValue(teamName)
           .setBackground(BLOCK_CONFIG.COLORS.TEAM_NAME);
    }
    
    Logger.log("Set up team header while preserving slot structure");
    
  } catch (e) {
    Logger.log(`Error in setupTeamHeaderOnly: ${e.message}`);
  }
}

/**
 * NEW: Sets optimized column widths for 2x5 roster layout
 * @param {Sheet} sheet - Sheet to modify
 */
function setOptimizedColumnWidths(sheet) {
  try {
    if (typeof BLOCK_CONFIG !== 'undefined' && BLOCK_CONFIG.LAYOUT && BLOCK_CONFIG.LAYOUT.COLUMN_WIDTHS) {
      // Use the configuration-based column widths
      const widths = BLOCK_CONFIG.LAYOUT.COLUMN_WIDTHS;
      
      // ROSTER COLUMNS (A-D)
      sheet.setColumnWidth(1, widths.INITIALS);    // A: Left initials
      sheet.setColumnWidth(2, widths.NAMES);       // B: Left names  
      sheet.setColumnWidth(3, widths.INITIALS);    // C: Right initials
      sheet.setColumnWidth(4, widths.NAMES);       // D: Right names
      
      // TIME COLUMNS
      sheet.setColumnWidth(5, widths.TIME);        // E: Left time
      sheet.setColumnWidth(13, widths.TIME);       // M: Right time
      
      // SCHEDULE DAYS
      for (let col = 6; col <= 12; col++) {
        sheet.setColumnWidth(col, widths.SCHEDULE_DAY); // F-L: Left week
      }
      for (let col = 14; col <= 20; col++) {
        sheet.setColumnWidth(col, widths.SCHEDULE_DAY); // N-T: Right week
      }
    } else {
      // Fallback to legacy column widths
      sheet.setColumnWidth(1, 60);   // Icons column
      sheet.setColumnWidth(2, 120);  // Names column
      sheet.setColumnWidth(3, 60);   // Left time column
      sheet.setColumnWidth(11, 60);  // Right time column
      
      // Left week days
      for (let col = 4; col <= 10; col++) {
        sheet.setColumnWidth(col, 95);
      }
      
      // Right week days
      for (let col = 12; col <= 18; col++) {
        sheet.setColumnWidth(col, 95);
      }
    }
    
    Logger.log("Set optimized column widths");
    
  } catch (e) {
    Logger.log(`Error setting column widths: ${e.message}`);
  }
}

/**
 * Freezes the own team rows (1-17) for easy comparison scrolling
 * @return {boolean} Success indicator
 */
function freezeOwnTeamRows() {
  try {
    const sheet = SpreadsheetApp.getActiveSpreadsheet().getActiveSheet();
    
    // Freeze first 17 rows (title + team info + own team schedule)
    sheet.setFrozenRows(17);
    
    Logger.log("SystemInitializer: Frozen first 17 rows for own team comparison");
    return true;
    
  } catch (e) {
    Logger.log(`SystemInitializer: Error freezing rows: ${e.message}`);
    return false;
  }
}

/**
 * DEBUG FUNCTION: Test schedule validation independently
 * @return {Object} Debug results
 */
function debugScheduleValidation() {
  try {
    Logger.log("=== DEBUG SCHEDULE VALIDATION TEST ===");
    
    const sheet = SpreadsheetApp.getActiveSpreadsheet().getActiveSheet();
    Logger.log("Sheet: " + sheet.getName());
    Logger.log("Sheet ID: " + SpreadsheetApp.getActiveSpreadsheet().getId());
    
    // Test each validation step
    const results = {
      sheetAccess: false,
      dimensions: false,
      teamName: false,
      blockDetection: false,
      slotDetection: false,
      finalResult: false
    };
    
    // Step 1: Sheet access
    try {
      const sheetName = sheet.getName();
      results.sheetAccess = true;
      Logger.log("✓ Sheet access: OK (" + sheetName + ")");
    } catch (e) {
      Logger.log("✗ Sheet access: FAILED (" + e.message + ")");
    }
    
    // Step 2: Dimensions
    try {
      const maxRows = sheet.getMaxRows();
      const maxCols = sheet.getMaxColumns();
      results.dimensions = (maxRows >= 15 && maxCols >= 10);
      Logger.log("✓ Dimensions: " + maxRows + "x" + maxCols + " (" + (results.dimensions ? "OK" : "TOO SMALL") + ")");
    } catch (e) {
      Logger.log("✗ Dimensions: FAILED (" + e.message + ")");
    }
    
    // Step 3: Team name
    try {
      const teamValue = sheet.getRange("B3").getValue();
      results.teamName = (teamValue && String(teamValue).trim() !== "");
      Logger.log("✓ Team name: '" + teamValue + "' (" + (results.teamName ? "OK" : "EMPTY") + ")");
    } catch (e) {
      Logger.log("✗ Team name: FAILED (" + e.message + ")");
    }
    
    // Step 4: Block detection
    try {
      const blocks = findAllBlocks();
      results.blockDetection = (blocks && blocks.length > 0);
      Logger.log("✓ Block detection: Found " + (blocks ? blocks.length : 0) + " blocks (" + (results.blockDetection ? "OK" : "NONE FOUND") + ")");
    } catch (e) {
      Logger.log("✗ Block detection: FAILED (" + e.message + ")");
    }
    
    // Step 5: NEW - Slot detection
    try {
      const documentProps = PropertiesService.getDocumentProperties();
      const slotData = documentProps.getProperty('slotData');
      results.slotDetection = (slotData !== null);
      Logger.log("✓ Slot detection: " + (results.slotDetection ? "FOUND slot data" : "NO slot data"));
    } catch (e) {
      Logger.log("✗ Slot detection: FAILED (" + e.message + ")");
    }
    
    // Final result - valid if either blocks OR slots exist
    results.finalResult = results.sheetAccess && results.dimensions && results.teamName && 
                         (results.blockDetection || results.slotDetection);
    Logger.log("=== FINAL VALIDATION RESULT: " + (results.finalResult ? "VALID" : "INVALID") + " ===");
    
    return results;
    
  } catch (e) {
    Logger.log("=== DEBUG VALIDATION ERROR: " + e.message + " ===");
    return { error: e.message };
  }
}