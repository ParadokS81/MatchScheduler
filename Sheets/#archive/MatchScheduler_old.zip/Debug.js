/**
 * Debug Functions for Schedule Manager (CONSOLIDATED + TIMER MONITORING)
 * All troubleshooting and testing functions - designed for spreadsheet menu use
 * @version 1.3.0 (2025-05-22)
 * 
 * CONSOLIDATED: Added debug functions from other files for centralized troubleshooting
 * UPDATED: Added testGetTeams function moved from UIController.js
 * NEW: Added comprehensive timer monitoring system
 */

// ========== SIDEBAR TESTING ==========

/**
 * Test minimal sidebar (menu-triggered)
 */
function debugTestMinimalSidebar() {
  try {
    const timestamp = new Date().toLocaleTimeString();
    const minimalHtml = HtmlService.createHtmlOutput(
      '<!DOCTYPE html>' +
      '<html>' +
      '<head>' +
      '<base target="_top">' +
      '<style>' +
      'body { font-family: Arial, sans-serif; padding: 20px; }' +
      '.test { background: #e8f5e8; padding: 15px; border-radius: 5px; }' +
      '</style>' +
      '</head>' +
      '<body>' +
      '<div class="test">' +
      '<h2>🧪 Minimal Sidebar Test</h2>' +
      '<p><strong>Time:</strong> ' + timestamp + '</p>' +
      '<p><strong>Status:</strong> HTML loading correctly!</p>' +
      '<button onclick="alert(\'JavaScript working!\')">Test JS</button>' +
      '<button onclick="google.script.run.showSidebar()">Load Real Sidebar</button>' +
      '</div>' +
      '<script>' +
      'console.log("Minimal sidebar JavaScript loaded at ' + timestamp + '");' +
      '</script>' +
      '</body>' +
      '</html>'
    )
    .setTitle('🧪 Debug Test')
    .setWidth(300);
    
    SpreadsheetApp.getUi().showSidebar(minimalHtml);
    
  } catch (e) {
    SpreadsheetApp.getUi().alert("Error: " + e.message);
  }
}

/**
 * UI-friendly version of the fix selected teams IDs function
 * @version 1.0.0 (2025-05-22)
 */
function fixSelectedTeamIdsUI() {
  try {
    const result = fixSelectedTeamIdsNoUI();
    
    let message = "";
    if (result.success) {
      message = `✅ Successfully standardized team IDs!\n\n` +
                `Original count: ${result.originalCount}\n` +
                `Standardized count: ${result.standardizedCount}\n\n` +
                `This should resolve display issues when selecting teams.`;
    } else {
      message = `❌ Error: ${result.error || "Unknown error occurred"}`;
    }
    
    SpreadsheetApp.getUi().alert("Team IDs Fix", message, SpreadsheetApp.getUi().ButtonSet.OK);
    
  } catch (e) {
    SpreadsheetApp.getUi().alert("Error fixing team IDs: " + e.message);
  }
}

/**
 * Force cache clear test
 */
function debugForceCacheClear() {
  try {
    const timestamp = new Date().getTime();
    const html = HtmlService.createHtmlOutput(
      '<!DOCTYPE html>' +
      '<html>' +
      '<head>' +
      '<base target="_top">' +
      '<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">' +
      '<meta http-equiv="Pragma" content="no-cache">' +
      '<meta http-equiv="Expires" content="0">' +
      '</head>' +
      '<body>' +
      '<h3>🔄 Cache Test</h3>' +
      '<p><strong>Timestamp:</strong> ' + timestamp + '</p>' +
      '<p>If you see this with a NEW timestamp each time, caching is working.</p>' +
      '<button onclick="google.script.run.showSidebar()">Load Real Sidebar</button>' +
      '</body>' +
      '</html>'
    )
    .setTitle('🔄 Cache Test - ' + timestamp)
    .setWidth(300);
    
    SpreadsheetApp.getUi().showSidebar(html);
    
  } catch (e) {
    SpreadsheetApp.getUi().alert("Cache test error: " + e.message);
  }
}

/**
 * Test registration check function
 */
function debugRegistrationCheck() {
  try {
    const status = checkTeamRegistration();
    const message = "Registration Status:\n\n" +
                   "Registered: " + status.isRegistered + "\n" +
                   "Needs Registration: " + status.needsRegistration + "\n" +
                   "Team Name: " + (status.teamName || 'N/A') + "\n" +
                   "Division: " + (status.division || 'N/A') + "\n" +
                   "Error: " + (status.error || 'None');
    
    SpreadsheetApp.getUi().alert("🎯 Registration Debug", message, SpreadsheetApp.getUi().ButtonSet.OK);
    
  } catch (e) {
    SpreadsheetApp.getUi().alert("Registration check error: " + e.message);
  }
}

/**
 * Debug function to directly test getting teams (moved from UIController.js)
 */
function testGetTeams() {
  try {
    Logger.log("Testing getAvailableTeams with 'yes'");
    
    // Check if BLOCK_CONFIG is defined
    if (!BLOCK_CONFIG || !BLOCK_CONFIG.HUB || !BLOCK_CONFIG.HUB.SPREADSHEET_ID) {
      Logger.log("ERROR: BLOCK_CONFIG is missing or incomplete");
      return { error: "BLOCK_CONFIG is missing or incomplete", teams: [] };
    }
    
    Logger.log("Hub ID from config: " + BLOCK_CONFIG.HUB.SPREADSHEET_ID);
    
    // Try to open the hub spreadsheet directly
    try {
      const hubSheet = SpreadsheetApp.openById(BLOCK_CONFIG.HUB.SPREADSHEET_ID);
      Logger.log("Successfully opened hub: " + hubSheet.getName());
    } catch (hubError) {
      Logger.log("ERROR opening hub: " + hubError.message);
      return { error: "Failed to open hub: " + hubError.message, teams: [] };
    }
    
    // Get current sheet ID  
    const currentSheetId = SpreadsheetApp.getActiveSpreadsheet().getId();
    Logger.log("Current sheet ID: " + currentSheetId);
    
    // Call the actual function
    const teams = getAvailableTeams("yes");
    
    // Log results
    Logger.log("Teams returned: " + JSON.stringify(teams));
    
    return {
      success: true,
      count: teams.length,
      teams: teams
    };
  } catch (e) {
    Logger.log("ERROR in testGetTeams: " + e.message);
    Logger.log("Stack trace: " + e.stack);
    return {
      error: e.message,
      stack: e.stack,
      teams: []
    };
  }
}

// ========== COMPREHENSIVE TIMER MONITORING ==========

/**
 * Shows ALL active timers across the entire system
 * Monitors: Auto-roll, Batch share, Auto-refresh, and Unknown timers  
 */
function debugAllActiveTimers() {
  const ui = SpreadsheetApp.getUi();
  
  try {
    const triggers = ScriptApp.getProjectTriggers();
    
    let message = `🕐 ALL ACTIVE TIMERS SYSTEM-WIDE\n`;
    message += `Total triggers: ${triggers.length}\n\n`;
    
    if (triggers.length === 0) {
      message += `No active triggers found.`;
      ui.alert("Timer Monitor", message, ui.ButtonSet.OK);
      return;
    }
    
    // Categorize triggers
    const autoRollTriggers = [];
    const batchShareTriggers = [];
    const autoRefreshTriggers = [];
    const unknownTriggers = [];
    
    triggers.forEach(trigger => {
      const handlerFunction = trigger.getHandlerFunction();
      const triggerId = trigger.getUniqueId();
      const triggerType = trigger.getTriggerSource();
      
      if (handlerFunction === 'checkAndAutoRoll') {
        autoRollTriggers.push({
          id: triggerId,
          handler: handlerFunction,
          type: triggerType,
          trigger: trigger
        });
      } else if (handlerFunction === 'executeBatchShare') {
        batchShareTriggers.push({
          id: triggerId,
          handler: handlerFunction,
          type: triggerType,
          trigger: trigger
        });
      } else if (handlerFunction === 'autoRefreshTeams') {
        autoRefreshTriggers.push({
          id: triggerId,
          handler: handlerFunction,
          type: triggerType,
          trigger: trigger
        });
      } else {
        unknownTriggers.push({
          id: triggerId,
          handler: handlerFunction,
          type: triggerType,
          trigger: trigger
        });
      }
    });
    
    // AUTO-ROLL TIMERS (Weekly Rollover)
    message += `⏰ AUTO-ROLL TIMERS (Weekly Rollover):\n`;
    if (autoRollTriggers.length > 0) {
      autoRollTriggers.forEach((timer, index) => {
        message += `  ${index + 1}. ${timer.handler}\n`;
        message += `     ID: ${timer.id}\n`;
        message += `     Schedule: Monday 00:01 CET\n`;
      });
    } else {
      message += `  None active\n`;
    }
    message += `\n`;
    
    // BATCH SHARE TIMERS (After user edits)
    message += `📤 BATCH SHARE TIMERS (After user edits):\n`;
    if (batchShareTriggers.length > 0) {
      // Get timer details from storage
      const userProps = PropertiesService.getUserProperties();
      const timerDataJson = userProps.getProperty('activeBatchTimers');
      
      batchShareTriggers.forEach((timer, index) => {
        message += `  ${index + 1}. ${timer.handler}\n`;
        message += `     ID: ${timer.id}\n`;
        
        if (timerDataJson) {
          try {
            const timerData = JSON.parse(timerDataJson);
            const age = new Date().getTime() - timerData.createdAt;
            const ageMinutes = Math.floor(age / (1000 * 60));
            
            if (timer.id === timerData.shortTimerId) {
              message += `     Type: 2-minute batch timer\n`;
              message += `     Age: ${ageMinutes} minutes\n`;
            } else if (timer.id === timerData.longTimerId) {
              message += `     Type: 30-minute batch timer\n`;
              message += `     Age: ${ageMinutes} minutes\n`;
            }
          } catch (e) {
            message += `     Type: Unknown batch timer\n`;
          }
        }
      });
    } else {
      message += `  None active\n`;
    }
    message += `\n`;
    
    // AUTO-REFRESH TIMERS (Team data refresh)
    message += `🔄 AUTO-REFRESH TIMERS (Team data refresh):\n`;
    if (autoRefreshTriggers.length > 0) {
      autoRefreshTriggers.forEach((timer, index) => {
        message += `  ${index + 1}. ${timer.handler}\n`;
        message += `     ID: ${timer.id}\n`;
        message += `     Schedule: Every 3 hours (12PM-12AM)\n`;
      });
    } else {
      message += `  None active\n`;
    }
    message += `\n`;
    
    // UNKNOWN TIMERS
    if (unknownTriggers.length > 0) {
      message += `❓ UNKNOWN/OTHER TIMERS:\n`;
      unknownTriggers.forEach((timer, index) => {
        message += `  ${index + 1}. ${timer.handler}\n`;
        message += `     ID: ${timer.id}\n`;
        message += `     Type: ${timer.type}\n`;
      });
      message += `\n`;
    }
    
    // SUMMARY
    message += `📊 SUMMARY:\n`;
    message += `  Auto-roll: ${autoRollTriggers.length}\n`;
    message += `  Batch share: ${batchShareTriggers.length}\n`;
    message += `  Auto-refresh: ${autoRefreshTriggers.length}\n`;
    message += `  Unknown: ${unknownTriggers.length}\n`;
    message += `  Total: ${triggers.length}`;
    
    ui.alert("🕐 All Active Timers", message, ui.ButtonSet.OK);
    
  } catch (e) {
    ui.alert("Error monitoring timers: " + e.message);
  }
}

/**
 * Quick timer cleanup function for admin use
 */
function adminCancelAllBatchTimers() {
  const ui = SpreadsheetApp.getUi();
  
  const response = ui.alert(
    'Cancel Batch Timers',
    'This will cancel all active batch share timers (2min/30min).\n\nAuto-roll and auto-refresh timers will remain active.\n\nContinue?',
    ui.ButtonSet.YES_NO
  );
  
  if (response === ui.Button.YES) {
    try {
      const success = cancelActiveBatchTimers(false);
      
      if (success) {
        ui.alert('Batch timers cancelled successfully.');
      } else {
        ui.alert('No batch timers to cancel or cancellation failed.');
      }
    } catch (e) {
      ui.alert('Error cancelling batch timers: ' + e.message);
    }
  }
}

/**
 * Emergency timer cleanup - cancels ALL triggers (use with caution)
 */
function adminEmergencyTimerCleanup() {
  const ui = SpreadsheetApp.getUi();
  
  const response = ui.alert(
    '⚠️ EMERGENCY TIMER CLEANUP',
    'This will DELETE ALL ACTIVE TIMERS including:\n• Auto-roll (weekly rollover)\n• Batch share timers\n• Auto-refresh timers\n\nThis should only be used if timers are stuck or malfunctioning.\n\nContinue?',
    ui.ButtonSet.YES_NO
  );
  
  if (response === ui.Button.YES) {
    try {
      const triggers = ScriptApp.getProjectTriggers();
      let deletedCount = 0;
      
      triggers.forEach(trigger => {
        ScriptApp.deleteTrigger(trigger);
        deletedCount++;
      });
      
      // Clear stored timer data
      const userProps = PropertiesService.getUserProperties();
      userProps.deleteProperty('activeBatchTimers');
      
      ui.alert(`Emergency cleanup complete.\n\n${deletedCount} timers deleted.\n\nYou may need to re-enable auto-roll and auto-refresh manually.`);
      
    } catch (e) {
      ui.alert('Error in emergency cleanup: ' + e.message);
    }
  }
}

// ========== SYSTEM STATUS ==========

/**
 * Check current sheet state 
 */
function debugSheetState() {
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getActiveSheet();
  
  let message = "📊 Sheet State:\n\n";
  message += "Sheet: " + sheet.getName() + "\n";
  message += "Max rows: " + sheet.getMaxRows() + "\n";
  message += "Max columns: " + sheet.getMaxColumns() + "\n";
  message += "Last row: " + sheet.getLastRow() + "\n";
  message += "Last column: " + sheet.getLastColumn() + "\n\n";
  
  // Check key cells
  try {
    const b3 = sheet.getRange("B3").getValue();
    const a10 = sheet.getRange("A10").getValue();
    
    message += "B3 (team): \"" + b3 + "\"\n";
    message += "A10 (logo): \"" + a10 + "\"\n";
  } catch (e) {
    message += "Cell access error: " + e.message;
  }
  
  SpreadsheetApp.getUi().alert("📊 Sheet State", message, SpreadsheetApp.getUi().ButtonSet.OK);
}

/**
 * Debug team info reading
 */
function debugTeamInfo() {
  try {
    const teamInfo = getTeamInfo();
    
    let message = "👥 Team Info:\n\n";
    message += "Name: \"" + teamInfo.name + "\"\n";
    message += "Players: " + teamInfo.players.length + "\n";
    message += "Valid: " + teamInfo.isValid + "\n\n";
    
    if (teamInfo.players.length > 0) {
      message += "Players:\n";
      teamInfo.players.forEach((player, i) => {
        message += (i+1) + ". " + player.name + " (" + player.initial + ")\n";
      });
    }
    
    if (teamInfo.error) {
      message += "\nError: " + teamInfo.error;
    }
    
    SpreadsheetApp.getUi().alert("👥 Team Info", message, SpreadsheetApp.getUi().ButtonSet.OK);
    
  } catch (e) {
    SpreadsheetApp.getUi().alert("Team info error: " + e.message);
  }
}

/**
 * Debug block detection
 */
function debugBlockDetection() {
  try {
    const blocks = findAllBlocks();
    
    let message = "🔍 Block Detection:\n\nFound " + blocks.length + " blocks\n\n";
    
    blocks.forEach((block, i) => {
      message += "Block " + (i+1) + ":\n";
      message += "- Week: " + block.weekNumber + "\n";
      message += "- Position: Row " + block.row + ", Col " + block.col + "\n";
      message += "- Size: " + block.gridWidth + "x" + block.gridHeight + "\n\n";
    });
    
    if (blocks.length === 0) {
      message += "No blocks found. Run 'Test Auto-Initialization' if needed.";
    }
    
    SpreadsheetApp.getUi().alert("🔍 Block Detection", message, SpreadsheetApp.getUi().ButtonSet.OK);
    
  } catch (e) {
    SpreadsheetApp.getUi().alert("Block detection error: " + e.message);
  }
}

/**
 * Debug auto-initialization process
 */
function debugAutoInitialization() {
  let message = "🔄 Auto-Initialization Test:\n\n";
  
  try {
    // Test hasValidSchedule()
    const isValid = hasValidSchedule();
    message += "1. hasValidSchedule(): " + isValid + "\n";
    
    // If invalid, test createSchedule()
    if (!isValid) {
      message += "2. Running createSchedule()...\n";
      createSchedule();
      message += "3. createSchedule() completed!\n";
      
      const isValidAfter = hasValidSchedule();
      message += "4. hasValidSchedule() after: " + isValidAfter + "\n";
      
      if (isValidAfter) {
        message += "\n✅ Auto-initialization working perfectly!";
      } else {
        message += "\n❌ Schedule still invalid after creation";
      }
    } else {
      message += "\n✅ Schedule already valid - no action needed";
    }
    
  } catch (e) {
    message += "\n❌ ERROR: " + e.message;
  }
  
  SpreadsheetApp.getUi().alert("🔄 Auto-Init Debug", message, SpreadsheetApp.getUi().ButtonSet.OK);
}

// ========== LOGO TESTING ==========

/**
 * Test logo fetching with safe URL
 */
function debugLogoFetchSafe() {
  const testUrl = "https://via.placeholder.com/300x300/4CAF50/FFFFFF?text=TEST";
  const testTeam = "Debug Team";
  
  let message = "🎨 Logo Fetch Test:\n\n";
  message += "URL: " + testUrl + "\n";
  message += "Team: " + testTeam + "\n\n";
  
  try {
    const driveUrl = fetchAndSaveTeamLogo(testUrl, testTeam);
    message += "✅ SUCCESS!\n\nDrive URL:\n" + driveUrl + "\n\nCheck your Google Drive for 'Schedule Manager - Team Logos' folder.";
    
  } catch (e) {
    message += "❌ FAILED:\n" + e.message;
  }
  
  SpreadsheetApp.getUi().alert("🎨 Logo Test", message, SpreadsheetApp.getUi().ButtonSet.OK);
}

/**
 * Test logo setup in spreadsheet
 */
function debugLogoSetup() {
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getActiveSheet();
  const testUrl = "https://via.placeholder.com/200x200/FF5722/FFFFFF?text=LOGO";
  
  try {
    setupTeamLogo(sheet, testUrl);
    SpreadsheetApp.getUi().alert("🎨 Logo Setup", "✅ Test logo set up in A10:B15\n\nCheck your sheet for the test logo!", SpreadsheetApp.getUi().ButtonSet.OK);
    
  } catch (e) {
    SpreadsheetApp.getUi().alert("❌ Logo setup error: " + e.message);
  }
}

/**
 * Check Drive folder status
 */
function debugDriveFolder() {
  try {
    const folder = getOrCreateLogoFolder();
    const files = folder.getFiles();
    let fileCount = 0;
    let fileList = "";
    
    while (files.hasNext()) {
      const file = files.next();
      fileCount++;
      fileList += fileCount + ". " + file.getName() + "\n";
    }
    
    let message = "📁 Drive Folder Status:\n\n";
    message += "Folder: " + folder.getName() + "\n";
    message += "Files: " + fileCount + "\n\n";
    
    if (fileCount > 0) {
      message += "Files:\n" + fileList;
    } else {
      message += "No logo files found.";
    }
    
    SpreadsheetApp.getUi().alert("📁 Drive Status", message, SpreadsheetApp.getUi().ButtonSet.OK);
    
  } catch (e) {
    SpreadsheetApp.getUi().alert("Drive folder error: " + e.message);
  }
}

// ========== HUB TESTING ==========

/**
 * Test hub connectivity
 */
function debugHubConnectivity() {
  try {
    const result = testHubConnectivity();
    SpreadsheetApp.getUi().alert("🔗 Hub Test", result, SpreadsheetApp.getUi().ButtonSet.OK);
    
  } catch (e) {
    SpreadsheetApp.getUi().alert("Hub connectivity error: " + e.message);
  }
}

/**
 * Test team registration status
 */
function debugTeamRegistrationStatus() {
  try {
    const status = checkTeamRegistration();
    
    let message = "📋 Registration Status:\n\n";
    message += "Registered: " + status.isRegistered + "\n";
    
    if (status.isRegistered) {
      message += "Team: " + status.teamName + "\n";
      message += "Division: " + status.division + "\n";
      message += "Status: " + status.status + "\n";
      message += "Last Updated: " + status.lastUpdated + "\n";
    } else {
      message += "Needs Registration: " + status.needsRegistration + "\n";
      if (status.error) {
        message += "Error: " + status.error + "\n";
      }
    }
    
    SpreadsheetApp.getUi().alert("📋 Registration", message, SpreadsheetApp.getUi().ButtonSet.OK);
    
  } catch (e) {
    SpreadsheetApp.getUi().alert("Registration status error: " + e.message);
  }
}

/**
 * Test available teams
 */
function debugAvailableTeams() {
  try {
    const teams = getAvailableTeams("no"); // Exclude own team
    
    let message = "👥 Available Teams:\n\nFound " + teams.length + " teams\n\n";
    
    if (teams.length > 0) {
      teams.forEach((team, i) => {
        message += (i+1) + ". " + team.name + "\n";
        message += "   Division: " + team.division + "\n";
        message += "   Players: " + team.players + "\n\n";
      });
    } else {
      message += "No teams found in hub.";
    }
    
    SpreadsheetApp.getUi().alert("👥 Available Teams", message, SpreadsheetApp.getUi().ButtonSet.OK);
    
  } catch (e) {
    SpreadsheetApp.getUi().alert("Available teams error: " + e.message);
  }
}

// ========== DISPLAY TEAMS DEBUGGING ==========

/**
 * Debug function to trace the display selected teams process
 * Run from the Script Editor to see full logs or menu for UI output
 * @version 1.0.0 (2025-05-22)
 * @return {string} Debug results summary
 */
function debugDisplaySelectedTeams() {
  Logger.log("=== DEBUG: Display Selected Teams Process ===");
  
  try {
    // Step 1: Check if we can get selected teams
    Logger.log("1. Checking selected teams...");
    const selectedTeams = getSelectedTeams();
    Logger.log(`   Found ${selectedTeams.length} selected teams: ${JSON.stringify(selectedTeams)}`);
    
    if (!selectedTeams || selectedTeams.length === 0) {
      Logger.log("   ERROR: No teams selected. Process would stop here.");
      return "ERROR: No teams selected. Please select teams in the sidebar first.";
    }
    
    // Step 2: Check sync warning
    Logger.log("2. Checking sync warning status...");
    const isInSync = checkCurrentWeekStatus();
    Logger.log(`   Schedule in sync with current week: ${isInSync}`);
    
    // Step 3: Test fetching team data
    Logger.log("3. Fetching team data...");
    Logger.log(`   Team IDs being used for fetch: ${JSON.stringify(selectedTeams)}`);
    
    const teamsData = fetchTeamsData(selectedTeams);
    Logger.log(`   Received ${teamsData.length} teams' data`);
    
    if (teamsData.length === 0) {
      Logger.log("   ERROR: No team data retrieved. Process would stop here.");
      const currentWeek = getCurrentWeekNumber();
      Logger.log(`   Current week number: ${currentWeek}`);
      return "ERROR: No team data retrieved. Teams might not have current week data.";
    }
    
    // Log details about each team's data
    teamsData.forEach((team, index) => {
      Logger.log(`   Team ${index + 1}: ${team.teamName}`);
      Logger.log(`     sheetId: ${team.sheetId}`);
      Logger.log(`     Number of weeks: ${team.weeks ? team.weeks.length : 0}`);
      if (team.weeks && team.weeks.length > 0) {
        const weekNumbers = team.weeks.map(w => w.weekNumber).join(", ");
        Logger.log(`     Week numbers: ${weekNumbers}`);
      }
    });
    
    // Step 4: Test display function directly
    Logger.log("4. Testing display function for first team...");
    const sheet = SpreadsheetApp.getActiveSpreadsheet().getActiveSheet();
    const firstTeam = teamsData[0];
    
    try {
      const displayResult = displayTeamData(sheet, firstTeam, 1);
      Logger.log(`   Display result: ${displayResult}`);
    } catch (displayError) {
      Logger.log(`   ERROR in displayTeamData: ${displayError.message}`);
      return `ERROR in displayTeamData: ${displayError.message}`;
    }
    
    // Check if team IDs are different formats
    Logger.log("5. Checking ID format consistency...");
    const selectedTeamTypes = selectedTeams.map(id => `${id} (${typeof id})`);
    Logger.log(`   Selected team IDs types: ${selectedTeamTypes}`);
    
    if (teamsData.length > 0 && teamsData[0].sheetId) {
      const dataTeamTypes = teamsData.map(team => `${team.sheetId} (${typeof team.sheetId})`);
      Logger.log(`   Data team IDs types: ${dataTeamTypes}`);
      
      // Compare for exact matches including type
      const exactMatches = selectedTeams.filter(id => 
        teamsData.some(team => team.sheetId === id)
      );
      Logger.log(`   Exact type matches: ${exactMatches.length}/${selectedTeams.length}`);
      
      // Compare as strings
      const stringMatches = selectedTeams.filter(id => 
        teamsData.some(team => String(team.sheetId) === String(id))
      );
      Logger.log(`   String matches: ${stringMatches.length}/${selectedTeams.length}`);
    }
    
    // Final summary
    return `Debug complete. Selected teams: ${selectedTeams.length}, Retrieved data: ${teamsData.length}. Check logs for details.`;
    
  } catch (e) {
    Logger.log(`CRITICAL ERROR: ${e.message}`);
    Logger.log(`Stack trace: ${e.stack}`);
    return `CRITICAL ERROR: ${e.message}. See logs for details.`;
  }
}

/**
 * UI-friendly version that shows debug results in an alert
 * Can be added to the debug menu for easy access
 */
function debugDisplaySelectedTeamsUI() {
  try {
    const result = debugDisplaySelectedTeams();
    const ui = SpreadsheetApp.getUi();
    ui.alert("Display Teams Debug Results", result, ui.ButtonSet.OK);
  } catch (e) {
    SpreadsheetApp.getUi().alert("Error running debug: " + e.message);
  }
}

// ========== TEAM ID DEBUGGING ==========

/**
 * Fixes selected team IDs without requiring UI access
 * @version 1.0.0 (2025-05-21)
 * @return {object} Results of the operation
 */
function fixSelectedTeamIdsNoUI() {
  try {
    // Get current selected teams
    const selectedTeams = getSelectedTeams();
    Logger.log("Current selected teams (" + selectedTeams.length + "): " + JSON.stringify(selectedTeams));
    
    // Convert all to strings
    const standardizedIds = selectedTeams.map(id => String(id));
    
    // Store the standardized IDs
    const success = storeSelectedTeams(standardizedIds);
    
    // Log results
    Logger.log("Type fix operation " + (success ? "succeeded" : "failed"));
    
    return {
      success: success,
      originalCount: selectedTeams.length,
      standardizedCount: standardizedIds.length,
      originalTeams: selectedTeams,
      standardizedTeams: standardizedIds
    };
  } catch (e) {
    const errorMsg = "Error fixing team IDs: " + e.message;
    Logger.log(errorMsg);
    return { 
      error: errorMsg,
      success: false
    };
  }
}

/**
 * Direct test of whether Team A can access Team B's data
 * @version 1.0.0 (2025-05-21)
 * @return {object} Test results
 */
function testTeamDataAccess() {
  try {
    // Hard-code both team IDs for testing
    const teamAId = "13QgVc4Tt1V2oq3ZvcSyPSh54ZQSVax5lUa7-PSG498g"; // Suddendeath
    const teamBId = "1i6ZIMBnhAtuxNvs14BT2PJLYrmvrjihQqEVfY1YpzQE"; // Eagles
    
    // Test by trying to access the data for each team
    const currentSheetId = SpreadsheetApp.getActiveSpreadsheet().getId();
    const isTeamA = (currentSheetId === teamAId);
    const otherTeamId = isTeamA ? teamBId : teamAId;
    
    Logger.log("I am " + (isTeamA ? "Team A (Suddendeath)" : "Team B (Eagles)"));
    Logger.log("Testing if I can access data for " + (isTeamA ? "Team B (Eagles)" : "Team A (Suddendeath)"));
    
    // Try to fetch the other team's data
    const teamData = fetchTeamsData([otherTeamId]);
    
    if (teamData.length === 0) {
      Logger.log("TEST FAILED: Could not retrieve data for the other team");
      return {
        success: false,
        message: "Could not retrieve data for the other team"
      };
    }
    
    Logger.log("TEST PASSED: Successfully retrieved data for " + teamData[0].teamName);
    Logger.log("Found " + teamData[0].weeks.length + " weeks of data");
    
    // Return success info
    return {
      success: true,
      teamName: teamData[0].teamName,
      weeksCount: teamData[0].weeks.length,
      players: teamData[0].players.length
    };
    
  } catch (e) {
    Logger.log("TEST ERROR: " + e.message);
    return {
      success: false,
      error: e.message
    };
  }
}

// ========== FRESHNESS DEBUGGING (MOVED FROM UICONTROLLER) ==========

/**
 * Debug function to show freshness calculation details
 * @version 1.0.0 (2025-05-22)
 */
function debugFreshnessCalculation() {
  try {
    const ui = SpreadsheetApp.getUi();
    const currentWeek = getCurrentWeekNumber();
    
    // Get teams and their data
    const teams = getAvailableTeams("no"); // Exclude own team
    const teamIds = teams.map(team => team.sheetId);
    const detailedTeamData = fetchTeamsData(teamIds);
    
    let message = `Freshness Calculation Debug (Current Week: ${currentWeek})\n\n`;
    
    if (detailedTeamData.length === 0) {
      message += "No team data found for freshness calculation.";
    } else {
      detailedTeamData.forEach((teamData, index) => {
        const freshness = getTeamFreshness(teamData);
        const teamWeeks = teamData.weeks ? teamData.weeks.map(w => w.weekNumber) : [];
        
        message += `${index + 1}. ${teamData.teamName}\n`;
        message += `   Weeks available: [${teamWeeks.join(', ')}]\n`;
        message += `   Freshness: ${freshness.indicator} ${freshness.status}\n`;
        message += `   Description: ${freshness.description}\n\n`;
      });
    }
    
    ui.alert("Freshness Debug", message, ui.ButtonSet.OK);
    
  } catch (e) {
    SpreadsheetApp.getUi().alert("Error debugging freshness: " + e.message);
  }
}

// ========== COLORING SYSTEM DEBUG (MOVED FROM DATAEXCHANGE) ==========

/**
 * Comprehensive debug function to diagnose coloring issues
 * Call this from the script editor to see what's happening
 */
function debugColoringSystem() {
  try {
    Logger.log("=== COLOR SYSTEM DEBUG START ===");
    
    // 1. Check if color functions exist
    Logger.log("1. CHECKING FUNCTION AVAILABILITY:");
    Logger.log(`- applyColorToAllBlocks exists: ${typeof applyColorToAllBlocks !== 'undefined'}`);
    Logger.log(`- updateColorsManually exists: ${typeof updateColorsManually !== 'undefined'}`);
    
    // 2. Check current sheet state
    const sheet = SpreadsheetApp.getActiveSpreadsheet().getActiveSheet();
    Logger.log("2. SHEET STATE:");
    Logger.log(`- Sheet name: ${sheet.getName()}`);
    Logger.log(`- Last row: ${sheet.getLastRow()}`);
    Logger.log(`- Last col: ${sheet.getLastColumn()}`);
    
    // 3. Check for blocks
    Logger.log("3. BLOCK DETECTION:");
    try {
      const blocks = findAllBlocks();
      Logger.log(`- Blocks found: ${blocks.length}`);
      blocks.forEach((block, i) => {
        Logger.log(`  Block ${i+1}: Week ${block.weekNumber}, Row ${block.row}, Col ${block.col}`);
      });
    } catch (e) {
      Logger.log(`- Block detection error: ${e.message}`);
    }
    
    // 4. Test sample cell coloring
    Logger.log("4. SAMPLE CELL TEST:");
    try {
      // Find a cell with data
      let testCell = null;
      for (let row = 5; row <= 15; row++) {
        for (let col = 4; col <= 10; col++) {
          const value = sheet.getRange(row, col).getValue();
          if (value && String(value).trim() !== "") {
            testCell = {row: row, col: col, value: String(value)};
            break;
          }
        }
        if (testCell) break;
      }
      
      if (testCell) {
        Logger.log(`- Test cell: ${testCell.row}, ${testCell.col} = "${testCell.value}"`);
        
        // Test the color logic
        const entries = testCell.value.split(/[,\s]+/).filter(e => e.trim());
        const count = entries.length;
        Logger.log(`- Parsed entries: [${entries.join(', ')}]`);
        Logger.log(`- Entry count: ${count}`);
        
        // Determine expected color
        let expectedColor;
        if (count === 0) {
          expectedColor = "WEEKDAY/WEEKEND";
        } else if (count === 1) {
          expectedColor = "RED (1 player)";
        } else if (count <= 3) {
          expectedColor = "YELLOW (2-3 players)";
        } else {
          expectedColor = "GREEN (4+ players)";
        }
        Logger.log(`- Expected color: ${expectedColor}`);
        
        // Check current background
        const currentBg = sheet.getRange(testCell.row, testCell.col).getBackground();
        Logger.log(`- Current background: ${currentBg}`);
        
      } else {
        Logger.log("- No test cells with data found");
      }
    } catch (e) {
      Logger.log(`- Sample cell test error: ${e.message}`);
    }
    
    // 5. Try calling color functions
    Logger.log("5. FUNCTION CALL TEST:");
    try {
      if (typeof applyColorToAllBlocks !== 'undefined') {
        Logger.log("- Calling applyColorToAllBlocks(false)...");
        const result = applyColorToAllBlocks(false);
        Logger.log(`- Result: ${result}`);
      } else {
        Logger.log("- applyColorToAllBlocks not available");
      }
    } catch (e) {
      Logger.log(`- Function call error: ${e.message}`);
      Logger.log(`- Error stack: ${e.stack}`);
    }
    
    Logger.log("=== COLOR SYSTEM DEBUG END ===");
    
  } catch (e) {
    Logger.log(`DEBUG ERROR: ${e.message}`);
    Logger.log(`DEBUG STACK: ${e.stack}`);
  }
}

/**
 * Debug function to test sync warning functionality
 */
function debugSyncWarning() {
  const ui = SpreadsheetApp.getUi();
  
  try {
    const currentWeek = getCurrentWeekNumber();
    const isInSync = checkCurrentWeekStatus();
    const blocks = findAllBlocks();
    const localWeeks = blocks.map(block => block.weekNumber);
    
    let message = `Sync Status Debug:\n\n`;
    message += `Current week: ${currentWeek}\n`;
    message += `Local weeks: [${localWeeks.join(', ')}]\n`;
    message += `In sync: ${isInSync ? 'Yes' : 'No'}\n\n`;
    
    if (!isInSync) {
      message += "Warning would be shown for operations.";
    } else {
      message += "No warning needed - schedule is in sync.";
    }
    
    ui.alert("Sync Warning Debug", message, ui.ButtonSet.OK);
    
  } catch (e) {
    ui.alert("Error debugging sync warning: " + e.message);
  }
}

// ========== TEAM TESTING FUNCTIONS (MOVED FROM DATAEXCHANGE) ==========

/**
 * Simple test - run this directly in script editor
 */
function quickTeamCheck() {
  const hubSheet = SpreadsheetApp.openById(BLOCK_CONFIG.HUB.SPREADSHEET_ID);
  const masterlist = hubSheet.getSheetByName(BLOCK_CONFIG.HUB.MASTERLIST_SHEET);
  const teamData = masterlist.getDataRange().getValues();
  
  console.log(`Found ${teamData.length - 1} teams in masterlist`);
  
  for (let i = 1; i < teamData.length; i++) {
    const teamName = teamData[i][0]; // Column A
    const status = teamData[i][6]; // Column G (status)
    console.log(`Team: ${teamName}, Status: "${status}"`);
  }
  
  // Test the function
  const availableTeams = getAvailableTeams(false);
  console.log(`getAvailableTeams() returned ${availableTeams.length} teams`);
}

// ========== HUB TESTING FUNCTIONS (MOVED FROM HUBCONNECTOR) ==========

/**
 * Debug function to show team data in masterlist
 */
function debugMyTeamData() {
  const hubSheet = SpreadsheetApp.openById(BLOCK_CONFIG.HUB.SPREADSHEET_ID);
  const masterlist = hubSheet.getSheetByName(BLOCK_CONFIG.HUB.MASTERLIST_SHEET);
  const currentSheetId = SpreadsheetApp.getActiveSpreadsheet().getId();
  
  const teamData = masterlist.getDataRange().getValues();
  
  for (let i = 1; i < teamData.length; i++) {
    if (teamData[i][BLOCK_CONFIG.HUB.COLUMNS.SHEET_ID] === currentSheetId) {
      Logger.log("Found team data:");
      Logger.log("Row " + i + ": " + JSON.stringify(teamData[i]));
      return;
    }
  }
  Logger.log("Team not found in masterlist");
}

/**
 * Simple registration check for debugging
 */
function checkTeamRegistrationSimple() {
  try {
    const currentSheetId = SpreadsheetApp.getActiveSpreadsheet().getId();
    Logger.log("Current sheet ID: " + currentSheetId);
    
    const hubSheet = SpreadsheetApp.openById(BLOCK_CONFIG.HUB.SPREADSHEET_ID);
    const masterlist = hubSheet.getSheetByName(BLOCK_CONFIG.HUB.MASTERLIST_SHEET);
    const teamData = masterlist.getDataRange().getValues();
    
    for (let i = 1; i < teamData.length; i++) {
      if (teamData[i][BLOCK_CONFIG.HUB.COLUMNS.SHEET_ID] === currentSheetId) {
        Logger.log("Team found! Returning registered status");
        const result = {
          isRegistered: true,
          needsRegistration: false
        };
        Logger.log("Result: " + JSON.stringify(result));
        return result;
      }
    }
    
    Logger.log("Team not found, returning not registered");
    const result = {
      isRegistered: false,
      needsRegistration: true
    };
    Logger.log("Result: " + JSON.stringify(result));
    return result;
    
  } catch (e) {
    Logger.log("Error: " + e.message);
    const result = {
      isRegistered: false,
      error: e.message,
      needsRegistration: true
    };
    Logger.log("Error result: " + JSON.stringify(result));
    return result;
  }
}

// ========== INITIALS TESTING FUNCTIONS (MOVED FROM INITIALSMANAGER) ==========

/**
 * Debug function to test adding initials
 */
function debugAddInitials() {
  try {
    Logger.log("=== DEBUG: Testing Add Initials ===");
    
    // Check if the core function exists
    Logger.log("1. Checking if addMyInitials function exists...");
    
    // Test getting user initials
    Logger.log("2. Testing getUserInitials...");
    const initials = getUserInitials();
    Logger.log("Got initials: " + initials);
    
    if (!initials) {
      Logger.log("ERROR: No initials returned");
      return;
    }
    
    // Test the selection
    Logger.log("3. Testing sheet selection...");
    const sheet = SpreadsheetApp.getActiveSpreadsheet().getActiveSheet();
    const selection = sheet.getSelection();
    
    if (!selection) {
      Logger.log("ERROR: No selection found - please select some cells first");
      return;
    }
    
    const ranges = selection.getActiveRangeList().getRanges();
    Logger.log("Found " + ranges.length + " selected ranges");
    
    // Test calling the actual function
    Logger.log("4. Calling addMyInitials()...");
    const result = addMyInitials();
    Logger.log("Function returned: " + result);
    
    Logger.log("=== DEBUG COMPLETE ===");
    
  } catch (e) {
    Logger.log("ERROR in debug: " + e.message);
    Logger.log("Stack: " + e.stack);
  }
}

// ========== BLOCK TESTING FUNCTIONS (MOVED FROM BLOCKAPPLIER) ==========

/**
 * Debug function to show detailed block information
 */
function debugBlockInfo() {
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getActiveSheet();
  const blocks = findAllBlocks();
  
  let message = `Found ${blocks.length} blocks:\n\n`;
  
  blocks.forEach((block, index) => {
    message += `Block ${index + 1}:\n`;
    message += `- Position: Row ${block.row}, Col ${block.col}\n`;
    message += `- Week: ${block.weekNumber}\n`;
    message += `- Month: ${block.month}\n`;
    message += `- Grid: ${block.gridWidth} x ${block.gridHeight}\n`;
    message += `- Time slots: ${block.timeSlots.length}\n\n`;
  });
  
  if (blocks.length === 0) {
    message += "No blocks found. Check if your sheet contains proper week headers.";
  }
  
  SpreadsheetApp.getUi().alert(message);
}

function debugAtomicSync() {
  try {
    console.log("=== ATOMIC SYNC DEBUG ===");
    
    // Test 1: Can we build atomic data?
    console.log("Building atomic data...");
    const atomicData = buildAtomicTeamData();
    console.log("✓ Atomic data built:", atomicData.teamName, "version", atomicData.version);
    
    // Test 2: Can we access hub?
    console.log("Testing hub access...");
    const hubSheet = SpreadsheetApp.openById(BLOCK_CONFIG.HUB.SPREADSHEET_ID);
    console.log("✓ Hub accessible");
    
    // Test 3: Can we find hub sheets?
    const dataSheet = hubSheet.getSheetByName(BLOCK_CONFIG.HUB.DATA_SHEET);
    const masterlist = hubSheet.getSheetByName(BLOCK_CONFIG.HUB.MASTERLIST_SHEET);
    console.log("✓ Data sheet found:", !!dataSheet);
    console.log("✓ Masterlist found:", !!masterlist);
    
    return "Debug completed - check console for details";
    
  } catch (e) {
    console.error("❌ Debug failed at:", e.message);
    return "Debug failed: " + e.message;
  }
}

/**
 * Diagnostic test to verify block detection issue
 * Run this in Script Editor to see what's happening
 */
function debugBlockDetection() {
  try {
    const sheet = SpreadsheetApp.getActiveSpreadsheet().getActiveSheet();
    console.log("=== BLOCK DETECTION DIAGNOSTIC ===");
    
    // Test current detection logic
    console.log("1. Testing current BlockDetector positions...");
    const currentBlocks = findAllBlocks();
    console.log(`Current detection found: ${currentBlocks.length} blocks`);
    
    // Test the actual positions we can see in your sheet
    console.log("2. Testing actual sheet positions...");
    
    // Check what's actually at row 3 (your team's week headers)
    // Based on first diagnostic: Month headers are at E(5) and M(13)
    // So week headers should be at F(6) and N(14)
    const row3ColD = sheet.getRange(3, 4).getValue(); // Column D
    const row3ColE = sheet.getRange(3, 5).getValue(); // Column E (month header)
    const row3ColF = sheet.getRange(3, 6).getValue(); // Column F (likely week header)
    const row3ColL = sheet.getRange(3, 12).getValue(); // Column L
    const row3ColM = sheet.getRange(3, 13).getValue(); // Column M (month header)  
    const row3ColN = sheet.getRange(3, 14).getValue(); // Column N (likely week header)
    
    console.log(`Row 3, Col D (4): "${row3ColD}"`);
    console.log(`Row 3, Col E (5): "${row3ColE}" <- Month header`);
    console.log(`Row 3, Col F (6): "${row3ColF}" <- Should be Week header`);
    console.log(`Row 3, Col L (12): "${row3ColL}"`);
    console.log(`Row 3, Col M (13): "${row3ColM}" <- Month header`);
    console.log(`Row 3, Col N (14): "${row3ColN}" <- Should be Week header`);
    
    // Test if we can parse week headers at the correct positions
    console.log("3. Testing week header parsing...");
    
    function testParseWeekHeader(text) {
      if (!text) return null;
      const match = String(text).match(/week\s*(\d+)/i);
      return match ? { weekNumber: parseInt(match[1]) } : null;
    }
    
    const weekF = testParseWeekHeader(row3ColF);
    const weekN = testParseWeekHeader(row3ColN);
    
    console.log(`Week in col F: ${weekF ? `Week ${weekF.weekNumber}` : 'Not found'}`);
    console.log(`Week in col N: ${weekN ? `Week ${weekN.weekNumber}` : 'Not found'}`);
    
    // Conclusion
    if (weekF && weekN) {
      console.log("✓ DIAGNOSIS CONFIRMED: Week headers are at columns F(6) and N(14)");
      console.log("✗ BlockDetector is looking at columns D(4) and L(12)");
      console.log("FIX NEEDED: Update BlockDetector positions to [0, 3, 6, 14]");
    } else if (weekF || weekN) {
      console.log("✓ PARTIAL: Found week header at", weekF ? "F(6)" : "N(14)");
      console.log("FIX NEEDED: Update BlockDetector positions");
    } else {
      console.log("? Still different issue - week headers not at F(6) or N(14) either");
      console.log("Let's check a wider range...");
      
      // Check columns C through O for any week headers
      for (let col = 3; col <= 15; col++) {
        const value = sheet.getRange(3, col).getValue();
        const weekInfo = testParseWeekHeader(value);
        if (weekInfo) {
          console.log(`✓ Found Week ${weekInfo.weekNumber} at column ${col}`);
        }
      }
    }
    
    return "Diagnostic complete - check console for results";
    
  } catch (e) {
    console.error("Diagnostic error:", e.message);
    return `Diagnostic failed: ${e.message}`;
  }
}

/**
 * Diagnostic to check atomic data structure and find forEach error
 */
function debugAtomicDataStructure() {
  try {
    console.log("=== ATOMIC DATA STRUCTURE DIAGNOSTIC ===");
    
    // Step 1: Build atomic data
    console.log("1. Building atomic data...");
    const atomicData = buildAtomicTeamData();
    console.log("✓ Atomic data built successfully");
    console.log("  - Team:", atomicData.teamName);
    console.log("  - Version:", atomicData.version);
    console.log("  - Timestamp:", atomicData.timestamp);
    
    // Step 2: Check weeks structure
    console.log("2. Checking weeks structure...");
    if (atomicData.weeks) {
      console.log("✓ Weeks array exists");
      console.log("  - Length:", atomicData.weeks.length);
      
      // Check each week
      atomicData.weeks.forEach((week, index) => {
        console.log(`  - Week ${index + 1}:`, {
          weekNumber: week.weekNumber,
          hasAvailability: !!week.availability,
          hasGrid: !!(week.availability && week.availability.grid),
          gridType: week.availability ? typeof week.availability.grid : 'no availability'
        });
      });
    } else {
      console.log("✗ No weeks array found!");
      console.log("Atomic data keys:", Object.keys(atomicData));
    }
    
    // Step 3: Test compression function
    console.log("3. Testing compression function...");
    try {
      const compressedData = compressForHubStorage(atomicData);
      console.log("✓ Compression successful");
      console.log("  - Compressed weeks length:", compressedData.weeks ? compressedData.weeks.length : 'undefined');
    } catch (compressionError) {
      console.log("✗ Compression failed:", compressionError.message);
      console.log("✗ Error stack:", compressionError.stack);
      
      // Check what's causing the forEach error
      if (compressionError.message.includes('forEach')) {
        console.log("DIAGNOSIS: forEach error in compression");
        console.log("- atomicData.weeks type:", typeof atomicData.weeks);
        console.log("- atomicData.weeks value:", atomicData.weeks);
        console.log("- Is array?", Array.isArray(atomicData.weeks));
      }
    }
    
    // Step 4: Full structure inspection
    console.log("4. Full atomic data structure:");
    console.log(JSON.stringify(atomicData, null, 2));
    
    return {
      success: true,
      atomicDataExists: !!atomicData,
      weeksExists: !!(atomicData && atomicData.weeks),
      weeksLength: atomicData && atomicData.weeks ? atomicData.weeks.length : 0,
      compressionWorks: false // Will be updated if compression succeeds
    };
    
  } catch (e) {
    console.log("=== DIAGNOSTIC ERROR ===");
    console.log("Error:", e.message);
    console.log("Stack:", e.stack);
    return { error: e.message };
  }
}

/**
 * Diagnostic to trace data flow through the sync process
 */
function debugSyncDataFlow() {
  try {
    console.log("=== SYNC DATA FLOW DIAGNOSTIC ===");
    
    // Step 1: Build atomic data
    console.log("1. Building atomic data...");
    const localData = buildAtomicTeamData();
    console.log("✓ Local data built");
    console.log("  - Type:", typeof localData);
    console.log("  - Has weeks:", !!localData.weeks);
    console.log("  - Weeks length:", localData.weeks ? localData.weeks.length : 'undefined');
    
    // Step 2: Get hub data (simulate conflict resolution input)
    console.log("2. Getting hub data...");
    const hubData = getCurrentHubData(localData.sheetId);
    console.log("✓ Hub data retrieved:", hubData ? 'found' : 'not found');
    
    // Step 3: Detect conflicts
    console.log("3. Detecting conflicts...");
    const conflictResult = detectConflicts(localData, hubData);
    console.log("✓ Conflict detection completed");
    console.log("  - Has conflicts:", conflictResult.hasConflicts);
    
    // Step 4: Resolve conflicts - THIS IS WHERE DATA MIGHT GET CORRUPTED
    console.log("4. Resolving conflicts...");
    const resolution = resolveConflicts(localData, hubData, conflictResult);
    console.log("✓ Conflict resolution completed");
    console.log("  - Resolved:", resolution.resolved);
    console.log("  - Final data type:", typeof resolution.finalData);
    
    if (resolution.finalData) {
      console.log("  - Final data has weeks:", !!resolution.finalData.weeks);
      console.log("  - Final weeks length:", resolution.finalData.weeks ? resolution.finalData.weeks.length : 'undefined');
      console.log("  - Final data keys:", Object.keys(resolution.finalData));
      
      // Check if finalData.weeks is actually an array
      if (resolution.finalData.weeks) {
        console.log("  - Weeks is array:", Array.isArray(resolution.finalData.weeks));
        console.log("  - Weeks type:", typeof resolution.finalData.weeks);
      }
      
      // Step 5: Test compression on final data
      console.log("5. Testing compression on final data...");
      try {
        const compressedFinal = compressForHubStorage(resolution.finalData);
        console.log("✓ Final data compression successful");
      } catch (compressionError) {
        console.log("✗ Final data compression failed:", compressionError.message);
        console.log("✗ This is likely where the forEach error occurs!");
        
        // Deep inspection of what's wrong
        console.log("PROBLEM ANALYSIS:");
        console.log("- resolution.finalData:", typeof resolution.finalData);
        console.log("- resolution.finalData.weeks:", typeof resolution.finalData.weeks);
        console.log("- resolution.finalData.weeks value:", resolution.finalData.weeks);
      }
    } else {
      console.log("✗ No final data from conflict resolution!");
    }
    
    return {
      success: true,
      localDataValid: !!(localData && localData.weeks),
      conflictResolutionValid: !!(resolution && resolution.finalData),
      finalDataValid: !!(resolution.finalData && resolution.finalData.weeks)
    };
    
  } catch (e) {
    console.log("=== SYNC FLOW DIAGNOSTIC ERROR ===");
    console.log("Error:", e.message);
    console.log("Stack:", e.stack);
    return { error: e.message };
  }
}

function testFixedSync() {
  console.log("Testing sync with fixed compression handling...");
  const result = pushAvailabilityToHub();
  console.log("Result:", JSON.stringify(result, null, 2));
  return result;
}

/**
 * Comprehensive pull performance test including actual display simulation
 */
function testFullPullToDisplayPerformance() {
  console.log("=== FULL PULL-TO-DISPLAY PERFORMANCE TEST ===");
  
  const overallStart = new Date().getTime();
  
  try {
    // Step 1: Simulate the actual DataExchange workflow
    console.log("1. Simulating actual team selection and display...");
    
    const currentSheetId = SpreadsheetApp.getActiveSpreadsheet().getId();
    
    // Store current team as "selected" (simulate user selection)
    const testStart = new Date().getTime();
    storeSelectedTeams([currentSheetId]);
    
    // Test the actual display function (this is what users experience)
    console.log("2. Running actual display function...");
    const displayStart = new Date().getTime();
    
    // Get selected teams (simulates user workflow)
    const selectedTeams = getSelectedTeams();
    console.log(`  - Selected teams: ${selectedTeams.length}`);
    
    // Fetch teams data (this is the main performance bottleneck)
    const fetchStart = new Date().getTime();
    const teamsData = fetchTeamsData(selectedTeams);
    const fetchTime = new Date().getTime() - fetchStart;
    
    console.log(`✓ Data fetch completed: ${fetchTime}ms`);
    console.log(`  - Teams retrieved: ${teamsData.length}`);
    
    if (teamsData.length > 0) {
      const team = teamsData[0];
      console.log(`  - Team: ${team.teamName}`);
      console.log(`  - Data size: ~${JSON.stringify(team).length} characters`);
      console.log(`  - Contract version: ${team.contractVersion || 'legacy'}`);
      console.log(`  - Weeks: ${team.weeks ? team.weeks.length : 0}`);
      
      // Validate and normalize (part of display process)
      const processStart = new Date().getTime();
      
      const validation = validateIncomingTeamData ? validateIncomingTeamData(team) : { isValid: true };
      const normalized = normalizeForDisplay ? normalizeForDisplay(team) : team;
      
      const processTime = new Date().getTime() - processStart;
      console.log(`✓ Data processing: ${processTime}ms`);
      console.log(`  - Validation: ${validation.isValid ? 'PASS' : 'FAIL'}`);
      console.log(`  - Normalization: ${normalized.contractVersion || 'applied'}`);
    }
    
    const displayTime = new Date().getTime() - displayStart;
    console.log(`✓ Total display workflow: ${displayTime}ms`);
    
    // Step 2: Multi-team simulation
    console.log("3. Testing 5-team scenario...");
    const multiStart = new Date().getTime();
    
    // Simulate 5 different teams (use same ID 5 times for testing)
    const fiveTeams = Array(5).fill(currentSheetId);
    storeSelectedTeams(fiveTeams);
    
    const fiveTeamData = fetchTeamsData(fiveTeams);
    const multiTime = new Date().getTime() - multiStart;
    
    console.log(`✓ 5-team fetch: ${multiTime}ms`);
    console.log(`  - Teams processed: ${fiveTeamData.length}`);
    
    // Step 3: Performance benchmarking
    const totalTime = new Date().getTime() - overallStart;
    
    console.log("=== PERFORMANCE BENCHMARKS ===");
    console.log(`Single team: ${displayTime}ms`);
    console.log(`5-team simulation: ${multiTime}ms`);
    console.log(`Total test: ${totalTime}ms`);
    
    // Real-world analysis
    console.log("=== REAL-WORLD PERFORMANCE ANALYSIS ===");
    
    const singleTeamSeconds = (displayTime / 1000).toFixed(1);
    const fiveTeamSeconds = (multiTime / 1000).toFixed(1);
    
    console.log(`Single team pull-to-display: ${singleTeamSeconds} seconds`);
    console.log(`5-team pull-to-display: ${fiveTeamSeconds} seconds`);
    
    // User experience rating
    if (multiTime < 2000) {
      console.log("🚀 EXCELLENT: Users will love this speed!");
    } else if (multiTime < 4000) {
      console.log("✅ GOOD: Professional-grade performance");
    } else if (multiTime < 6000) {
      console.log("⚠️ ACCEPTABLE: Users won't complain");
    } else {
      console.log("❌ SLOW: Consider optimization");
    }
    
    // Scale projection
    console.log("=== SCALE PROJECTIONS ===");
    const perTeamTime = multiTime / 5;
    console.log(`Average per team: ${perTeamTime}ms`);
    console.log(`Projected 10-team fetch: ${(perTeamTime * 10 / 1000).toFixed(1)} seconds`);
    console.log(`Projected 20-team fetch: ${(perTeamTime * 20 / 1000).toFixed(1)} seconds`);
    
    return {
      success: true,
      performance: {
        singleTeam: displayTime,
        fiveTeams: multiTime,
        perTeam: perTeamTime,
        total: totalTime
      },
      dataSize: teamsData.length > 0 ? JSON.stringify(teamsData[0]).length : 0,
      userExperience: multiTime < 4000 ? "good" : multiTime < 6000 ? "acceptable" : "needs_optimization"
    };
    
  } catch (e) {
    console.log("=== TEST ERROR ===");
    console.log("Error:", e.message);
    return { error: e.message };
  }
}

/**
 * Real-world pull performance test for atomic data system
 */
function testPullPerformance() {
  console.log("=== BASIC PULL PERFORMANCE TEST ===");
  
  const startTime = new Date().getTime();
  let fetchTime, validateTime, displayTime;
  
  try {
    // Step 1: Test fetching your own team data (we know it exists)
    console.log("1. Testing single team fetch...");
    const fetchStart = new Date().getTime();
    
    const currentSheetId = SpreadsheetApp.getActiveSpreadsheet().getId();
    const teamData = fetchTeamsData([currentSheetId]);
    
    fetchTime = new Date().getTime() - fetchStart;
    console.log(`✓ Fetch completed: ${fetchTime}ms`);
    console.log(`  - Teams retrieved: ${teamData.length}`);
    
    if (teamData.length > 0) {
      const team = teamData[0];
      console.log(`  - Team name: ${team.teamName}`);
      console.log(`  - Data size: ~${JSON.stringify(team).length} characters`);
      console.log(`  - Weeks available: ${team.weeks ? team.weeks.length : 0}`);
      
      // Step 2: Test validation
      console.log("2. Testing data validation...");
      const validateStart = new Date().getTime();
      
      const validation = validateIncomingTeamData(team);
      
      validateTime = new Date().getTime() - validateStart;
      console.log(`✓ Validation completed: ${validateTime}ms`);
      console.log(`  - Valid: ${validation.isValid}`);
      console.log(`  - Errors: ${validation.errors ? validation.errors.length : 0}`);
      console.log(`  - Warnings: ${validation.warnings ? validation.warnings.length : 0}`);
      
      // Step 3: Test normalization for display
      console.log("3. Testing display normalization...");
      const displayStart = new Date().getTime();
      
      const normalized = normalizeForDisplay(team);
      
      displayTime = new Date().getTime() - displayStart;
      console.log(`✓ Normalization completed: ${displayTime}ms`);
      console.log(`  - Contract version: ${normalized.contractVersion}`);
      console.log(`  - Display players: ${normalized.players ? normalized.players.length : 0}`);
    }
    
    // Step 4: Simulate 5-team fetch
    console.log("4. Simulating 5-team fetch...");
    const multiStart = new Date().getTime();
    
    // Test with 5 copies of the same team (simulates 5 different teams)
    const fiveTeamIds = Array(5).fill(currentSheetId);
    const fiveTeamData = fetchTeamsData(fiveTeamIds);
    
    const multiTime = new Date().getTime() - multiStart;
    console.log(`✓ 5-team fetch completed: ${multiTime}ms`);
    console.log(`  - Teams retrieved: ${fiveTeamData.length}`);
    console.log(`  - Total data size: ~${JSON.stringify(fiveTeamData).length} characters`);
    
    // Summary
    const totalTime = new Date().getTime() - startTime;
    console.log("=== PERFORMANCE SUMMARY ===");
    console.log(`Single team fetch: ${fetchTime}ms`);
    console.log(`Data validation: ${validateTime}ms`);
    console.log(`Display preparation: ${displayTime}ms`);
    console.log(`5-team simulation: ${multiTime}ms`);
    console.log(`Total test time: ${totalTime}ms`);
    
    // Performance analysis
    console.log("=== ANALYSIS ===");
    if (multiTime < 2000) {
      console.log("✅ EXCELLENT: 5-team pull under 2 seconds");
    } else if (multiTime < 4000) {
      console.log("✅ GOOD: 5-team pull under 4 seconds");
    } else if (multiTime < 6000) {
      console.log("⚠️ ACCEPTABLE: 5-team pull under 6 seconds");
    } else {
      console.log("❌ SLOW: 5-team pull over 6 seconds - optimization needed");
    }
    
    return {
      success: true,
      timings: {
        singleFetch: fetchTime,
        validation: validateTime,
        display: displayTime,
        fiveTeamFetch: multiTime,
        total: totalTime
      },
      dataSize: teamData.length > 0 ? JSON.stringify(teamData[0]).length : 0,
      teamsFound: teamData.length
    };
    
  } catch (e) {
    console.log("=== TEST ERROR ===");
    console.log("Error:", e.message);
    console.log("Stack:", e.stack);
    return { error: e.message };
  }
}

/**
 * Quick fix for missing showSyncWarningIfNeeded function
 * Add this to your script editor to continue testing
 */

/**
 * Shows sync warning if team data is out of sync (stub for testing)
 * @return {boolean} True to proceed, false to cancel
 */
function showSyncWarningIfNeeded() {
  try {
    // For testing purposes, always proceed
    // In production, this would check if local data is newer than hub data
    Logger.log("Sync warning check: Proceeding with operation");
    return true;
  } catch (e) {
    Logger.log(`Sync warning error: ${e.message}`);
    return true; // Proceed on error to avoid blocking
  }
}

/**
 * Alternative: Simple bypass version of the performance test
 * This skips the sync warning check entirely
 */
function testPullPerformanceBypass() {
  console.log("=== PULL PERFORMANCE TEST (BYPASS VERSION) ===");
  
  try {
    const startTime = new Date().getTime();
    
    // Get current team ID
    const currentSheetId = SpreadsheetApp.getActiveSpreadsheet().getId();
    
    // Step 1: Test single team fetch
    console.log("1. Testing single team fetch...");
    const singleStart = new Date().getTime();
    
    const singleTeamData = fetchTeamsData([currentSheetId]);
    const singleTime = new Date().getTime() - singleStart;
    
    console.log(`✓ Single team fetch: ${singleTime}ms`);
    console.log(`  - Teams found: ${singleTeamData.length}`);
    
    if (singleTeamData.length > 0) {
      const dataSize = JSON.stringify(singleTeamData[0]).length;
      console.log(`  - Data size: ~${dataSize} characters`);
    }
    
    // Step 2: Get all available teams (your 5 test teams)
    console.log("2. Getting all available teams...");
    const availableTeams = getAvailableTeams(true); // Include own team
    console.log(`✓ Available teams: ${availableTeams.length}`);
    
    // Step 3: Test multi-team fetch (up to 5 teams)
    console.log("3. Testing multi-team fetch...");
    const multiStart = new Date().getTime();
    
    const teamIds = availableTeams.slice(0, 5).map(team => team.sheetId);
    console.log(`  - Testing with ${teamIds.length} teams`);
    
    const multiTeamData = fetchTeamsData(teamIds);
    const multiTime = new Date().getTime() - multiStart;
    
    console.log(`✓ Multi-team fetch: ${multiTime}ms`);
    console.log(`  - Teams retrieved: ${multiTeamData.length}`);
    
    if (multiTeamData.length > 0) {
      const totalDataSize = JSON.stringify(multiTeamData).length;
      console.log(`  - Total data size: ~${totalDataSize} characters`);
      console.log(`  - Average per team: ~${Math.round(totalDataSize / multiTeamData.length)} characters`);
    }
    
    // Performance analysis
    const totalTime = new Date().getTime() - startTime;
    
    console.log("=== PERFORMANCE RESULTS ===");
    console.log(`Single team: ${singleTime}ms`);
    console.log(`${teamIds.length} teams: ${multiTime}ms`);
    console.log(`Total test: ${totalTime}ms`);
    
    // User experience analysis
    const multiSeconds = (multiTime / 1000).toFixed(1);
    console.log(`\n=== USER EXPERIENCE ===`);
    console.log(`${teamIds.length}-team pull: ${multiSeconds} seconds`);
    
    if (multiTime < 4000) {
      console.log("🚀 EXCELLENT: Professional-grade performance!");
    } else if (multiTime < 8000) {
      console.log("✅ GOOD: Users will be satisfied");
    } else if (multiTime < 12000) {
      console.log("⚠️ ACCEPTABLE: Users won't complain");
    } else {
      console.log("❌ SLOW: Consider optimization");
    }
    
    // Scale projections
    const perTeamTime = multiTime / teamIds.length;
    console.log(`\n=== SCALE PROJECTIONS ===`);
    console.log(`Average per team: ${perTeamTime.toFixed(0)}ms`);
    console.log(`Projected 10-team fetch: ${(perTeamTime * 10 / 1000).toFixed(1)} seconds`);
    console.log(`Projected 20-team fetch: ${(perTeamTime * 20 / 1000).toFixed(1)} seconds`);
    
    return {
      success: true,
      performance: {
        singleTeam: singleTime,
        multiTeam: multiTime,
        perTeam: perTeamTime,
        teamsCount: teamIds.length
      },
      userExperience: multiTime < 4000 ? "excellent" : multiTime < 8000 ? "good" : "acceptable"
    };
    
  } catch (e) {
    console.log("=== TEST ERROR ===");
    console.log("Error:", e.message);
    return { error: e.message };
  }
}

/**
 * Debug why team data retrieval is failing
 */
function debugTeamDataRetrieval() {
  console.log("=== TEAM DATA RETRIEVAL DEBUG ===");
  
  try {
    // Step 1: Check what's actually in the hub
    console.log("1. Checking hub masterlist...");
    const availableTeams = getAvailableTeams(true);
    console.log(`✓ Found ${availableTeams.length} teams in masterlist`);
    
    availableTeams.forEach((team, i) => {
      console.log(`  Team ${i + 1}: ${team.name} (ID: ${team.sheetId})`);
    });
    
    // Step 2: Test raw hub data access
    console.log("2. Testing direct hub data access...");
    const hubSheet = SpreadsheetApp.openById(BLOCK_CONFIG.HUB.SPREADSHEET_ID);
    const dataSheet = hubSheet.getSheetByName(BLOCK_CONFIG.HUB.DATA_SHEET);
    
    if (!dataSheet) {
      console.log("❌ Data sheet not found!");
      return { error: "Data sheet not found" };
    }
    
    const dataValues = dataSheet.getDataRange().getValues();
    console.log(`✓ Data sheet has ${dataValues.length - 1} team records (excluding header)`);
    
    // Step 3: Check each team's raw data
    console.log("3. Examining raw team data...");
    
    for (let i = 1; i < Math.min(6, dataValues.length); i++) { // Check first 5 teams
      const sheetId = String(dataValues[i][0]);
      const rawJson = dataValues[i][1];
      
      console.log(`\nTeam ${i}:`);
      console.log(`  - Sheet ID: ${sheetId}`);
      console.log(`  - Raw JSON length: ${rawJson ? rawJson.length : 'NULL'}`);
      
      if (rawJson) {
        try {
          const parsed = JSON.parse(rawJson);
          console.log(`  - Team Name: ${parsed.teamName || 'undefined'}`);
          console.log(`  - Contract Version: ${parsed.contractVersion || 'none'}`);
          console.log(`  - Has weeks: ${!!(parsed.weeks && parsed.weeks.length)}`);
          console.log(`  - Weeks count: ${parsed.weeks ? parsed.weeks.length : 0}`);
          
          if (parsed.weeks && parsed.weeks.length > 0) {
            const week = parsed.weeks[0];
            console.log(`  - First week number: ${week.weekNumber}`);
            console.log(`  - Has availability: ${!!(week.availability && week.availability.grid)}`);
            console.log(`  - Grid dimensions: ${week.availability?.grid ? week.availability.grid.length + 'x' + week.availability.grid[0]?.length : 'none'}`);
          }
          
        } catch (parseError) {
          console.log(`  - JSON Parse Error: ${parseError.message}`);
        }
      } else {
        console.log(`  - No data stored for this team`);
      }
    }
    
    // Step 4: Test fetchTeamsData with specific team
    console.log("4. Testing fetchTeamsData function...");
    
    if (availableTeams.length > 1) {
      const testTeamId = availableTeams[1].sheetId; // Use second team to avoid own team
      console.log(`Testing with team ID: ${testTeamId}`);
      
      try {
        const fetchedData = fetchTeamsData([testTeamId]);
        console.log(`✓ fetchTeamsData returned ${fetchedData.length} teams`);
        
        if (fetchedData.length > 0) {
          const team = fetchedData[0];
          console.log(`  - Fetched team name: ${team.teamName || 'undefined'}`);
          console.log(`  - Fetched weeks: ${team.weeks ? team.weeks.length : 0}`);
          console.log(`  - Team data keys: ${Object.keys(team)}`);
        } else {
          console.log(`❌ fetchTeamsData returned empty for team ${testTeamId}`);
        }
        
      } catch (fetchError) {
        console.log(`❌ fetchTeamsData error: ${fetchError.message}`);
        console.log(`Stack: ${fetchError.stack}`);
      }
    }
    
    return {
      success: true,
      teamsInMasterlist: availableTeams.length,
      teamsWithData: dataValues.length - 1
    };
    
  } catch (e) {
    console.log("=== DEBUG ERROR ===");
    console.log("Error:", e.message);
    console.log("Stack:", e.stack);
    return { error: e.message };
  }
}

/**
 * Check if test team sheet has the updated code versions
 */
function checkCodeVersions() {
  console.log("=== CODE VERSION CHECK ===");
  
  try {
    // Check 1: Block Detection Fix
    console.log("1. Checking BlockDetector version...");
    const blocks = findAllBlocks(true);
    console.log(`✓ Block detection found: ${blocks.length} blocks`);
    
    if (blocks.length > 0) {
      console.log(`  - Week ${blocks[0].weekNumber} at row ${blocks[0].row}, col ${blocks[0].col}`);
      console.log("✅ BlockDetector appears to be working");
    } else {
      console.log("❌ BlockDetector not finding blocks - OLD VERSION?");
    }
    
    // Check 2: Atomic Data Building
    console.log("2. Testing atomic data building...");
    try {
      const atomicData = buildAtomicTeamData();
      console.log(`✓ Atomic data built for: ${atomicData.teamName}`);
      console.log(`  - Version: ${atomicData.version}`);
      console.log(`  - Contract version: ${atomicData.contractVersion}`);
      console.log(`  - Weeks: ${atomicData.weeks ? atomicData.weeks.length : 0}`);
      console.log("✅ DataContract appears to be working");
    } catch (atomicError) {
      console.log(`❌ Atomic data building failed: ${atomicError.message}`);
      console.log("❌ DataContract OLD VERSION or missing?");
    }
    
    // Check 3: Hub Connector Version
    console.log("3. Testing hub connector...");
    try {
      const result = testHubConnectivity();
      console.log(`✓ Hub connectivity: ${result}`);
      console.log("✅ HubConnector appears to be working");
    } catch (hubError) {
      console.log(`❌ Hub connector error: ${hubError.message}`);
    }
    
    // Check 4: Team Sheet Data
    console.log("4. Checking team sheet data...");
    const sheet = SpreadsheetApp.getActiveSpreadsheet().getActiveSheet();
    const teamName = sheet.getRange("B3").getValue();
    console.log(`  - Team name in B3: "${teamName}"`);
    
    // Check for week headers at the NEW positions (F and N)
    const weekF = sheet.getRange(3, 6).getValue(); // Column F
    const weekN = sheet.getRange(3, 14).getValue(); // Column N
    console.log(`  - Week header at F3: "${weekF}"`);
    console.log(`  - Week header at N3: "${weekN}"`);
    
    if (weekF && weekN) {
      console.log("✅ Week headers at correct positions (F6, N14)");
    } else {
      console.log("❌ Week headers not found - layout issue?");
    }
    
    // Check 5: Properties/Version Storage
    console.log("5. Checking Properties...");
    const props = PropertiesService.getDocumentProperties();
    const dataVersion = props.getProperty('dataVersion');
    console.log(`  - Data version: ${dataVersion || 'not set'}`);
    
    return {
      success: true,
      blocksFound: blocks.length,
      teamName: teamName,
      hasWeekHeaders: !!(weekF && weekN),
      dataVersion: dataVersion
    };
    
  } catch (e) {
    console.log("=== VERSION CHECK ERROR ===");
    console.log("Error:", e.message);
    return { error: e.message };
  }
}

/**
 * Debug what data is actually reaching the display functions
 */
function debugDisplayPipeline() {
  console.log("=== DISPLAY PIPELINE DEBUG ===");
  
  try {
    // Step 1: Get selected teams (same as display function)
    const selectedTeams = getSelectedTeams();
    console.log(`✓ Selected teams: ${selectedTeams.length}`);
    console.log(`  Team IDs: ${JSON.stringify(selectedTeams)}`);
    
    // Step 2: Fetch teams data (same as display function)
    console.log("Fetching teams data...");
    const teamsData = fetchTeamsData(selectedTeams);
    console.log(`✓ Teams data retrieved: ${teamsData.length}`);
    
    // Step 3: Examine each team's data structure
    teamsData.forEach((team, index) => {
      console.log(`\n--- TEAM ${index + 1} DATA ANALYSIS ---`);
      console.log(`Team type: ${typeof team}`);
      console.log(`Team keys: ${Object.keys(team)}`);
      
      if (team) {
        console.log(`  - teamName: "${team.teamName}" (${typeof team.teamName})`);
        console.log(`  - contractVersion: "${team.contractVersion}"`);
        console.log(`  - sheetId: "${team.sheetId}"`);
        console.log(`  - weeks: ${team.weeks ? team.weeks.length : 'undefined'} (${typeof team.weeks})`);
        console.log(`  - players: ${team.players ? team.players.length : 'undefined'} (${typeof team.players})`);
        
        if (team.weeks && team.weeks.length > 0) {
          console.log(`  - First week: ${team.weeks[0].weekNumber}`);
          console.log(`  - Has availability grid: ${!!(team.weeks[0].availability && team.weeks[0].availability.grid)}`);
        }
        
        if (team.players && team.players.length > 0) {
          console.log(`  - First player: "${team.players[0].playerName}"`);
        }
      } else {
        console.log("  ❌ Team data is null/undefined");
      }
    });
    
    // Step 4: Test the validation functions
    console.log("\n--- VALIDATION TESTING ---");
    if (teamsData.length > 0) {
      const testTeam = teamsData[0];
      
      try {
        console.log("Testing validateIncomingTeamData...");
        const validation = validateIncomingTeamData ? validateIncomingTeamData(testTeam) : { isValid: true };
        console.log(`✓ Validation result: ${validation.isValid}`);
        console.log(`  - Errors: ${validation.errors ? validation.errors.length : 0}`);
        console.log(`  - Warnings: ${validation.warnings ? validation.warnings.length : 0}`);
      } catch (valError) {
        console.log(`❌ Validation error: ${valError.message}`);
      }
      
      try {
        console.log("Testing normalizeForDisplay...");
        const normalized = normalizeForDisplay ? normalizeForDisplay(testTeam) : testTeam;
        console.log(`✓ Normalization completed`);
        console.log(`  - Normalized teamName: "${normalized.teamName}"`);
        console.log(`  - Normalized weeks: ${normalized.weeks ? normalized.weeks.length : 'undefined'}`);
      } catch (normError) {
        console.log(`❌ Normalization error: ${normError.message}`);
      }
    }
    
    // Step 5: Test team freshness function
    console.log("\n--- FRESHNESS TESTING ---");
    if (teamsData.length > 0) {
      try {
        const freshness = getTeamFreshness(teamsData[0]);
        console.log(`✓ Team freshness: ${freshness.status} (${freshness.indicator})`);
        console.log(`  - Description: ${freshness.description}`);
      } catch (freshError) {
        console.log(`❌ Freshness error: ${freshError.message}`);
      }
    }
    
    return {
      success: true,
      selectedTeams: selectedTeams.length,
      retrievedTeams: teamsData.length,
      firstTeamValid: teamsData.length > 0 && teamsData[0] && teamsData[0].teamName
    };
    
  } catch (e) {
    console.log("=== DISPLAY PIPELINE ERROR ===");
    console.log("Error:", e.message);
    console.log("Stack:", e.stack);
    return { error: e.message };
  }
}

/**
 * Check what's actually stored in the hub (raw data inspection)
 */
function debugRawHubData() {
  console.log("=== RAW HUB DATA DIAGNOSTIC ===");
  
  try {
    const hubSheet = SpreadsheetApp.openById(BLOCK_CONFIG.HUB.SPREADSHEET_ID);
    const dataSheet = hubSheet.getSheetByName(BLOCK_CONFIG.HUB.DATA_SHEET);
    
    if (!dataSheet) {
      console.log("❌ Data sheet not found");
      return { error: "Data sheet not found" };
    }
    
    const dataValues = dataSheet.getDataRange().getValues();
    console.log(`✓ Data sheet has ${dataValues.length - 1} records`);
    
    // Check first few teams
    for (let i = 1; i < Math.min(4, dataValues.length); i++) {
      const sheetId = String(dataValues[i][0]);
      const rawJson = dataValues[i][1];
      
      console.log(`\n--- TEAM ${i} (${sheetId.substring(0, 8)}...) ---`);
      console.log(`Raw data type: ${typeof rawJson}`);
      console.log(`Raw data length: ${rawJson ? rawJson.length : 'null'}`);
      
      if (rawJson) {
        // Show first 100 characters
        const preview = rawJson.substring(0, 100);
        console.log(`Raw data preview: "${preview}..."`);
        
        // Check if it starts with a quote (indicating double-stringified)
        if (rawJson.startsWith('"')) {
          console.log(`⚠️  DOUBLE-STRINGIFIED: Data starts with quote mark`);
          
          try {
            // Try double-parsing
            const firstParse = JSON.parse(rawJson);
            console.log(`First parse type: ${typeof firstParse}`);
            
            if (typeof firstParse === 'string') {
              const secondParse = JSON.parse(firstParse);
              console.log(`Second parse type: ${typeof secondParse}`);
              console.log(`Second parse teamName: ${secondParse.teamName || 'undefined'}`);
              console.log(`✅ SOLUTION: Need double JSON.parse()`);
            }
          } catch (doubleParseError) {
            console.log(`❌ Double parse failed: ${doubleParseError.message}`);
          }
        } else {
          console.log(`✓ NORMAL: Data doesn't start with quote`);
          
          try {
            const parsed = JSON.parse(rawJson);
            console.log(`Parse type: ${typeof parsed}`);
            console.log(`Parse teamName: ${parsed.teamName || 'undefined'}`);
          } catch (parseError) {
            console.log(`❌ Parse failed: ${parseError.message}`);
          }
        }
      }
    }
    
    return { success: true };
    
  } catch (e) {
    console.log("=== RAW HUB DIAGNOSTIC ERROR ===");
    console.log("Error:", e.message);
    return { error: e.message };
  }
}

/**
 * Debug where double-stringification is happening in the sync pipeline
 */
function debugDoubleStringifySource() {
  console.log("=== DOUBLE STRINGIFY ROOT CAUSE DEBUG ===");
  
  try {
    // Step 1: Build atomic data
    console.log("1. Building atomic data...");
    const atomicData = buildAtomicTeamData();
    console.log(`✓ Atomic data type: ${typeof atomicData}`);
    console.log(`✓ Atomic data teamName: ${atomicData.teamName}`);
    
    // Step 2: Test compression
    console.log("2. Testing compression...");
    let compressedData;
    try {
      if (typeof compressForHubStorage === 'function') {
        compressedData = compressForHubStorage(atomicData);
        console.log(`✓ DataContract compression result type: ${typeof compressedData}`);
      } else {
        compressedData = simpleHubCompression(atomicData);
        console.log(`✓ Simple compression result type: ${typeof compressedData}`);
      }
    } catch (compressionError) {
      compressedData = atomicData;
      console.log(`✓ Using direct data (no compression): ${typeof compressedData}`);
    }
    
    console.log(`✓ Compressed data teamName: ${compressedData.teamName}`);
    
    // Step 3: Test JSON.stringify (what updateHubDataSheet does)
    console.log("3. Testing JSON.stringify...");
    const jsonString = JSON.stringify(compressedData);
    console.log(`✓ JSON.stringify result type: ${typeof jsonString}`);
    console.log(`✓ JSON.stringify result length: ${jsonString.length}`);
    console.log(`✓ JSON.stringify starts with: "${jsonString.substring(0, 50)}..."`);
    
    // Step 4: Check if compressedData was already a string
    if (typeof compressedData === 'string') {
      console.log("🚨 ROOT CAUSE FOUND: compressedData is already a string!");
      console.log("🚨 JSON.stringify(string) creates double-stringification");
      console.log("🚨 Fix needed in compression pipeline, not parsing pipeline");
    } else {
      console.log("✓ compressedData is object, JSON.stringify is correct");
    }
    
    // Step 5: Test what hub would store vs what it actually stores
    console.log("4. Comparing expected vs actual hub storage...");
    
    // What we expect to store
    const expectedStorage = JSON.stringify(atomicData);
    console.log(`Expected storage starts: "${expectedStorage.substring(0, 50)}..."`);
    
    // What's actually in hub (first team)
    const hubSheet = SpreadsheetApp.openById(BLOCK_CONFIG.HUB.SPREADSHEET_ID);
    const dataSheet = hubSheet.getSheetByName(BLOCK_CONFIG.HUB.DATA_SHEET);
    const dataValues = dataSheet.getDataRange().getValues();
    
    if (dataValues.length > 1) {
      const actualStorage = dataValues[1][1]; // First team's data
      console.log(`Actual storage starts: "${actualStorage.substring(0, 50)}..."`);
      
      // Compare
      if (expectedStorage === actualStorage) {
        console.log("✓ Hub storage matches expected format");
      } else if (actualStorage.startsWith('""')) {
        console.log("🚨 CONFIRMED: Hub has double-stringified data");
        console.log("🚨 updateHubDataSheet() is double-stringifying");
      } else {
        console.log("? Different issue - hub storage format unexpected");
      }
    }
    
    return {
      success: true,
      rootCause: typeof compressedData === 'string' ? 'compression_returns_string' : 'unknown'
    };
    
  } catch (e) {
    console.log("=== DEBUG ERROR ===");
    console.log("Error:", e.message);
    return { error: e.message };
  }
}

function debugFetchTeamsData() {
  // Use the team ID from your logs
  const teamIds = ["1KLguIqu8lr_KemcFjHWpbBPVcgXuwX78NY0HuiIYABo"];
  
  Logger.log("=== MANUAL DEBUG TEST START ===");
  const result = fetchTeamsData(teamIds);
  Logger.log(`=== MANUAL DEBUG TEST END - Retrieved ${result.length} teams ===`);
  
  return result;
}

function debugFullCycle() {
  Logger.log("=== TESTING STORAGE CYCLE ===");
  
  // First try to push data (this calls updateHubDataSheet with debug logging)
  const pushResult = pushAvailabilityToHub();
  Logger.log(`Push result: ${JSON.stringify(pushResult)}`);
  
  Logger.log("=== NOW TESTING RETRIEVAL ===");
  
  // Then try to fetch the same data
  const teamIds = ["1KLguIqu8lr_KemcFjHWpbBPVcgXuwX78NY0HuiIYABo"];
  const fetchResult = fetchTeamsData(teamIds);
  Logger.log(`Fetch result: ${fetchResult.length} teams`);
  
  return { pushResult, fetchResult };
}

function debugStorageProcess() {
  try {
    Logger.log("=== STORAGE PROCESS DEBUG TEST ===");
    
    // Create a simple test team data object
    const testTeamData = {
      sheetId: SpreadsheetApp.getActiveSpreadsheet().getId(),
      contractVersion: "1.0.0",
      teamName: "DEBUG TEST TEAM",
      teamLeader: Session.getActiveUser().getEmail(),
      division: "Division 1",
      teamType: "slot_based",
      timestamp: new Date().toISOString(),
      version: 1,
      weekAlignment: 21,
      players: [
        {
          slotNumber: 1,
          playerName: "Test Player",
          initials: "TP",
          status: "adopted"
        }
      ],
      weeks: [
        {
          weekNumber: 21,
          startDate: "2025-05-19",
          month: "May",
          availability: {
            grid: [["TP", "", ""], ["", "TP", ""]]
          }
        }
      ],
      syncMetadata: {
        lastSuccessfulSync: new Date().toISOString(),
        syncAttempts: 1,
        conflictsDetected: 0,
        rolloverStatus: "current"
      }
    };
    
    Logger.log("✅ Test data created");
    Logger.log(`Test data type: ${typeof testTeamData}`);
    Logger.log(`Test data teamName: ${testTeamData.teamName}`);
    
    // Open hub and call the debug version of updateHubDataSheet
    const hubSheet = SpreadsheetApp.openById(BLOCK_CONFIG.HUB.SPREADSHEET_ID);
    const dataSheet = hubSheet.getSheetByName(BLOCK_CONFIG.HUB.DATA_SHEET);
    
    if (!dataSheet) {
      Logger.log("❌ Hub data sheet not found");
      return false;
    }
    
    Logger.log("✅ Hub data sheet found, calling updateHubDataSheet...");
    
    // This should trigger all our debug logging
    const result = updateHubDataSheet(dataSheet, testTeamData.sheetId, testTeamData);
    
    Logger.log(`Storage result: ${result}`);
    Logger.log("=== STORAGE PROCESS DEBUG TEST COMPLETE ===");
    
    return result;
    
  } catch (e) {
    Logger.log(`❌ Debug test error: ${e.message}`);
    Logger.log(`❌ Error stack: ${e.stack}`);
    return false;
  }
}

function debugCurrentWeek() {
  const currentWeek = getCurrentWeekNumber();
  Logger.log(`getCurrentWeekNumber() returns: ${currentWeek}`);
  Logger.log(`Expected based on team data: 21`);
  Logger.log(`Today's date: ${new Date()}`);
  return currentWeek;
}

function debugDisplayFailure() {
  Logger.log("=== DEBUGGING DISPLAY FAILURE ===");
  
  try {
    // Get the same team data that the display process uses
    const currentSheetId = SpreadsheetApp.getActiveSpreadsheet().getId();
    const teamIds = [currentSheetId]; // Try to display own team
    
    Logger.log(`Looking for team: ${currentSheetId}`);
    
    const teamsData = fetchTeamsData(teamIds);
    Logger.log(`Retrieved ${teamsData.length} teams`);
    
    if (teamsData.length > 0) {
      const teamData = teamsData[0];
      Logger.log(`Team name: ${teamData.teamName}`);
      Logger.log(`Team has ${teamData.weeks ? teamData.weeks.length : 0} weeks`);
      Logger.log(`Team has ${teamData.players ? teamData.players.length : 0} players`);
      
      // Test the position calculation
      const teamPosition = getStandardBlockPosition(1, false); // Position 1
      Logger.log(`Team position for index 1: ${JSON.stringify(teamPosition)}`);
      
      // Test if we can access the sheet and write to the calculated position
      const sheet = SpreadsheetApp.getActiveSpreadsheet().getActiveSheet();
      const testRow = teamPosition.row;
      
      Logger.log(`Attempting to write to row ${testRow}`);
      
      // Try to write a simple test value
      sheet.getRange(testRow, 1).setValue("TEST");
      Logger.log(`✅ Successfully wrote to row ${testRow}`);
      
      // Clean up
      sheet.getRange(testRow, 1).setValue("");
      
    } else {
      Logger.log("❌ No team data retrieved");
    }
    
  } catch (e) {
    Logger.log(`❌ Debug error: ${e.message}`);
    Logger.log(`❌ Error stack: ${e.stack}`);
  }
}

function debugPlayerCollection() {
  Logger.log("=== DEBUGGING PLAYER DATA COLLECTION ===");
  
  try {
    // Check team type
    const isSlotBased = isSlotBasedTeam();
    Logger.log(`Team type: ${isSlotBased ? 'slot_based' : 'fixed_roster'}`);
    
    if (isSlotBased) {
      Logger.log("Using slot-based player collection...");
      const adoptedPlayers = getAdoptedPlayers();
      Logger.log(`getAdoptedPlayers() returned: ${adoptedPlayers.length} players`);
      adoptedPlayers.forEach((player, i) => {
        Logger.log(`Player ${i+1}: ${JSON.stringify(player)}`);
      });
    } else {
      Logger.log("Using fixed roster player collection...");
      const teamInfo = getTeamInfo();
      Logger.log(`getTeamInfo() returned: ${teamInfo.players.length} players`);
      teamInfo.players.forEach((player, i) => {
        Logger.log(`Player ${i+1}: ${JSON.stringify(player)}`);
      });
    }
    
    // Check what buildAtomicTeamData actually collects
    Logger.log("Testing buildAtomicTeamData player collection...");
    const atomicData = buildAtomicTeamData();
    Logger.log(`buildAtomicTeamData collected: ${atomicData.players.length} players`);
    atomicData.players.forEach((player, i) => {
      Logger.log(`Atomic Player ${i+1}: ${JSON.stringify(player)}`);
    });
    
  } catch (e) {
    Logger.log(`Player collection debug error: ${e.message}`);
  }
}

function debugSlotSystemIntegration() {
  Logger.log("=== DEBUGGING SLOT ADOPTION INTEGRATION ===");
  
  try {
    // Check what's actually stored in slot properties
    const props = PropertiesService.getDocumentProperties();
    const slotData = props.getProperties();
    
    Logger.log("All stored slot data:");
    Object.keys(slotData).forEach(key => {
      if (key.startsWith('slot_') || key.includes('player') || key.includes('adopt')) {
        Logger.log(`${key}: ${slotData[key]}`);
      }
    });
    
    // Check what getAdoptedPlayers() is actually reading
    Logger.log("\ngetAdoptedPlayers() breakdown:");
    for (let slot = 1; slot <= 10; slot++) {
      const playerData = props.getProperty(`slot_${slot}_data`);
      if (playerData) {
        Logger.log(`Slot ${slot}: ${playerData}`);
      } else {
        Logger.log(`Slot ${slot}: empty`);
      }
    }
    
    // Check what's visually in the sheet cells (rows 4-8)
    const sheet = SpreadsheetApp.getActiveSpreadsheet().getActiveSheet();
    Logger.log("\nSheet visual data (B4:B8):");
    for (let row = 4; row <= 8; row++) {
      const playerName = sheet.getRange(row, 2).getValue();
      const playerInitial = sheet.getRange(row, 1).getValue();
      Logger.log(`Row ${row}: "${playerInitial}" | "${playerName}"`);
    }
    
    // Test slot adoption flow
    Logger.log("\nTesting if slot adoption updates sheet...");
    if (typeof getSlotStatus === 'function') {
      const slotStatus = getSlotStatus();
      Logger.log(`Slot status: ${JSON.stringify(slotStatus)}`);
    }
    
    return { slotData, sheetData: "check logs" };
    
  } catch (e) {
    Logger.log(`Debug error: ${e.message}`);
    return { error: e.message };
  }
}
// Run this FIRST to set up test data:
function setupTestDataForPhase1() {
  try {
    Logger.log("=== SETTING UP TEST DATA FOR PHASE 1 ===");
    
    // Step 1: Create basic team structure in SlotManager
    const testTeamName = "Phase 1 Test Team";
    const testPlayers = ["Alice Test", "Bob Test", "Carol Test"];
    const testDivision = "Test Division";
    
    const setupResult = setupTeamDataInSlotManager(testTeamName, testPlayers, testDivision);
    Logger.log(`Team setup result: ${setupResult}`);
    
    // Step 2: Create basic schedule structure if needed
    if (!hasValidSchedule()) {
      Logger.log("Creating schedule structure...");
      createScheduleStructure(testTeamName, testPlayers);
    }
    
    // Step 3: Verify setup
    const teamInfo = getTeamInfo();
    const slotInfo = getSlotOwnershipInfo();
    
    Logger.log(`Team created: ${teamInfo.name}`);
    Logger.log(`Players adopted: ${teamInfo.players.length}`);
    Logger.log(`Data source: ${teamInfo.dataSource}`);
    
    Logger.log("=== TEST DATA SETUP COMPLETE ===");
    return true;
    
  } catch (e) {
    Logger.log(`Setup error: ${e.message}`);
    return false;
  }
}