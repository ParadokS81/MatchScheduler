/**
 * Schedule Manager - Enhanced Roller System (PHASE 3B - CET INTEGRATED)
 * 
 * @version 2.0.0 (Phase 3B)
 * 
 * Description: CET-aware rollover system with week alignment validation
 * PHASE 3B: Integrated CET timezone calculations and week validation
 * ENHANCED: Multi-layer rollover system with failover mechanisms
 */

// ========== ROLLOVER VALIDATION ==========

/**
 * Validates week alignment using CET timezone
 * @param {Object[]} weeks - Array of week objects with weekNumber
 * @return {Object} Validation result
 */
function validateWeekAlignment(weeks) {
  try {
    const currentWeekCET = getCurrentWeekNumberCET();
    const nextWeekCET = currentWeekCET + 1;
    const weekNumbers = weeks.map(w => w.weekNumber);
    
    Logger.log(`RollerSystem: Validating weeks [${weekNumbers.join(', ')}] against CET current: ${currentWeekCET}, next: ${nextWeekCET}`);
    
    const hasCurrentWeek = weekNumbers.includes(currentWeekCET);
    const hasNextWeek = weekNumbers.includes(nextWeekCET);
    const pastWeeks = weekNumbers.filter(w => w < currentWeekCET);
    const futureWeeks = weekNumbers.filter(w => w > nextWeekCET);
    
    let status = 'INVALID';
    let needsRollover = false;
    const errors = [];
    const warnings = [];
    
    // Determine status
    if (hasCurrentWeek && hasNextWeek) {
      status = 'CURRENT';
    } else if (hasCurrentWeek && !hasNextWeek) {
      status = 'PARTIAL';
      warnings.push('Missing next week - should add week ' + nextWeekCET);
    } else if (!hasCurrentWeek && hasNextWeek) {
      status = 'AHEAD';
      warnings.push('Missing current week - unusual but acceptable');
    } else if (pastWeeks.length > 0 && futureWeeks.length === 0) {
      status = 'BEHIND';
      needsRollover = true;
      errors.push(`Behind schedule - latest week: ${Math.max(...weekNumbers)}, current: ${currentWeekCET}`);
    } else if (weekNumbers.length === 0) {
      status = 'EMPTY';
      needsRollover = true;
      errors.push('No week data found - needs complete rollover');
    } else {
      status = 'MIXED';
      warnings.push('Mixed week data - some weeks may be outdated');
    }
    
    // Check for excessive past weeks
    if (pastWeeks.length > 1) {
      warnings.push(`${pastWeeks.length} past weeks detected - consider cleanup`);
    }
    
    // Check for excessive future weeks
    if (futureWeeks.length > 2) {
      warnings.push(`${futureWeeks.length} future weeks detected - may be too far ahead`);
    }
    
    const result = {
      isValid: errors.length === 0,
      status: status,
      needsRollover: needsRollover,
      currentWeekCET: currentWeekCET,
      nextWeekCET: nextWeekCET,
      hasCurrentWeek: hasCurrentWeek,
      hasNextWeek: hasNextWeek,
      pastWeeks: pastWeeks,
      futureWeeks: futureWeeks,
      errors: errors,
      warnings: warnings
    };
    
    Logger.log(`RollerSystem: Week validation result: ${status} (needsRollover: ${needsRollover})`);
    return result;
    
  } catch (e) {
    Logger.log(`RollerSystem: Error validating week alignment: ${e.message}`);
    return {
      isValid: false,
      status: 'ERROR',
      needsRollover: false,
      errors: [`Validation error: ${e.message}`],
      warnings: []
    };
  }
}

/**
 * Calculates rollover status based on CET timing
 * @param {Object[]} weeks - Array of week objects
 * @return {string} Rollover status
 */
function calculateRolloverStatus(weeks) {
  try {
    const validation = validateWeekAlignment(weeks);
    
    switch (validation.status) {
      case 'CURRENT': return 'current';
      case 'BEHIND': return 'behind';
      case 'AHEAD': return 'ahead';
      case 'PARTIAL': return 'partial';
      case 'EMPTY': return 'empty';
      case 'MIXED': return 'mixed';
      default: return 'unknown';
    }
  } catch (e) {
    Logger.log(`RollerSystem: Error calculating rollover status: ${e.message}`);
    return 'error';
  }
}

// ========== ENHANCED ROLLOVER FUNCTIONS ==========

/**
 * Enhanced rollover with CET validation and conflict detection
 * @param {boolean} validateBeforeRoll - Whether to validate weeks before rolling
 * @return {boolean} Success indicator
 */
function rollOneWeekForward(validateBeforeRoll = true) {
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getActiveSheet();
  
  Logger.log(`RollerSystem: Starting CET-aware rollover (validate: ${validateBeforeRoll})`);
  
  try {
    // Pre-rollover validation
    if (validateBeforeRoll) {
      const blocks = findAllBlocks();
      if (blocks.length === 0) {
        Logger.log("RollerSystem: No blocks found for validation");
        SpreadsheetApp.getUi().alert("No week blocks found. Please create a schedule first.");
        return false;
      }
      
      // Validate current week alignment
      const weekObjects = blocks.map(block => ({ weekNumber: block.weekNumber }));
      const validation = validateWeekAlignment(weekObjects);
      
      Logger.log(`RollerSystem: Pre-rollover validation: ${validation.status}`);
      
      // Log validation results
      if (validation.warnings.length > 0) {
        Logger.log(`RollerSystem: Validation warnings: ${validation.warnings.join(', ')}`);
      }
      
      if (!validation.isValid && validation.errors.length > 0) {
        Logger.log(`RollerSystem: Validation errors: ${validation.errors.join(', ')}`);
        const continueAnyway = SpreadsheetApp.getUi().alert(
          'Week Validation Issues',
          `Issues detected:\n${validation.errors.join('\n')}\n\nContinue rollover anyway?`,
          SpreadsheetApp.getUi().ButtonSet.YES_NO
        );
        
        if (continueAnyway !== SpreadsheetApp.getUi().Button.YES) {
          return false;
        }
      }
    }
    
    // Perform the actual rollover (preserve existing logic)
    const rollSuccess = performActualRollover(sheet);
    
    if (rollSuccess) {
      // Post-rollover actions
      Logger.log(`RollerSystem: Rollover completed, performing post-rollover actions`);
      
      // Update version if DataContract is available
      try {
        if (typeof setCurrentDataVersion === 'function' && typeof getCurrentDataVersion === 'function') {
          const currentVersion = getCurrentDataVersion();
          setCurrentDataVersion(currentVersion + 1);
          Logger.log(`RollerSystem: Updated data version to ${currentVersion + 1} after rollover`);
        }
      } catch (e) {
        Logger.log(`RollerSystem: Could not update data version: ${e.message}`);
      }
      
      // Auto-push to hub if team is registered
      setTimeout(() => {
        try {
          if (typeof pushAvailabilityToHub === 'function') {
            const teamInfo = getTeamInfo();
            if (teamInfo.isValid) {
              Logger.log('RollerSystem: Auto-pushing rolled schedule to hub');
              pushAvailabilityToHub();
            }
          }
        } catch (e) {
          Logger.log(`RollerSystem: Could not auto-push after rollover: ${e.message}`);
        }
      }, 2000); // 2-second delay to let UI settle
      
      SpreadsheetApp.getUi().alert("Successfully rolled forward by one week");
      Logger.log("RollerSystem: Enhanced rollover complete!");
      return true;
    }
    
    return false;
    
  } catch (e) {
    Logger.log(`RollerSystem: ERROR in enhanced rollover: ${e.message}`);
    console.error(e);
    SpreadsheetApp.getUi().alert(`Error rolling forward: ${e.message}`);
    return false;
  }
}

/**
 * Performs the actual rollover mechanics (preserved from original)
 * @param {Sheet} sheet - Sheet to modify
 * @return {boolean} Success indicator
 */
function performActualRollover(sheet) {
  try {
    // Find all blocks
    const blocks = findAllBlocks();
    
    if (blocks.length === 0) {
      Logger.log("RollerSystem: No blocks found for rollover");
      return false;
    }
    
    Logger.log(`RollerSystem: Found ${blocks.length} blocks to process`);
    
    // Group blocks by team
    const teamBlocks = groupBlocksByTeam(blocks);
    
    // Process each team
    for (const [teamIndex, teamBlocksArray] of Object.entries(teamBlocks)) {
      Logger.log(`RollerSystem: Processing team at index ${teamIndex} with ${teamBlocksArray.length} blocks`);
      
      if (teamBlocksArray.length < 1) {
        Logger.log(`RollerSystem: Not enough blocks for team ${teamIndex}, skipping`);
        continue;
      }
      
      // Sort blocks by week number (ascending)
      teamBlocksArray.sort((a, b) => a.weekNumber - b.weekNumber);
      
      // Determine the newest week number
      const newerWeekNum = teamBlocksArray[teamBlocksArray.length - 1].weekNumber;
      const newWeekNum = newerWeekNum + 1;
      
      // Take the newer block
      const newerBlock = teamBlocksArray[teamBlocksArray.length - 1];
      
      // Calculate the standard positions for this team
      const leftPosition = getStandardBlockPosition(parseInt(teamIndex), false);
      const rightPosition = getStandardBlockPosition(parseInt(teamIndex), true);
      
      // Save content of the newer week
      const newerWeekContent = saveBlockContent(sheet, newerBlock);
      
      if (!newerWeekContent) {
        Logger.log(`RollerSystem: Failed to save content for block at team ${teamIndex}, skipping`);
        continue;
      }
      
      // Clear both positions
      clearBlockPosition(sheet, leftPosition, newerBlock.gridHeight);
      clearBlockPosition(sheet, rightPosition, newerBlock.gridHeight);
      
      // Restore the newer week to the left position
      Logger.log(`RollerSystem: Restoring newer week to left position`);
      restoreBlockContent(sheet, leftPosition, newerWeekContent);
      
      // Create new week in the right position using CET calculations
      Logger.log(`RollerSystem: Creating new week in right position using CET`);
      const newMondayCET = calculateMondayFromWeekNumberCET(newWeekNum);
      
      // Create the block at the standard right position
      createWeekBlockAtPosition(
        sheet,
        rightPosition.row,
        rightPosition.col,
        rightPosition.timeCol,
        newMondayCET
      );
    }
    
    // Apply colors at the end
    Logger.log(`RollerSystem: Applying colors to updated sheet`);
    if (typeof applyColorsToAllBlocks === 'function') {
      applyColorsToAllBlocks();
    } else if (typeof applyColorToAllBlocks === 'function') {
      applyColorToAllBlocks();
    }
    
    return true;
    
  } catch (e) {
    Logger.log(`RollerSystem: Error in actual rollover: ${e.message}`);
    return false;
  }
}

// ========== ENHANCED AUTO-ROLL SYSTEM ==========

/**
 * Enhanced auto-roll check with CET timing and multi-layer logic
 */
function checkAndAutoRoll() {
  // First, make sure auto-roll is still enabled
  if (!getAutoRoll()) {
    Logger.log('RollerSystem: Auto-roll disabled, skipping check');
    return;
  }
  
  Logger.log('RollerSystem: Running enhanced auto-roll check with CET validation');
  
  try {
    // Check if we're in a rollover window
    const rolloverWindow = isRolloverWindowCET(60); // 60-minute window
    const currentCETTime = getCurrentCETTime();
    
    Logger.log(`RollerSystem: CET time: ${currentCETTime.toISOString()}, In rollover window: ${rolloverWindow.inWindow}`);
    
    // Get current schedule state
    const sheet = SpreadsheetApp.getActiveSpreadsheet().getActiveSheet();
    const blocks = findAllBlocks();
    
    if (blocks.length === 0) {
      Logger.log('RollerSystem: No blocks found for auto-roll check');
      return;
    }
    
    // Validate week alignment using CET
    const weekObjects = blocks.map(block => ({ weekNumber: block.weekNumber }));
    const validation = validateWeekAlignment(weekObjects);
    
    Logger.log(`RollerSystem: Week validation status: ${validation.status}`);
    Logger.log(`RollerSystem: Current CET week: ${validation.currentWeekCET}, Has current: ${validation.hasCurrentWeek}`);
    
    let shouldRoll = false;
    let rollReason = '';
    
    // ENHANCED ROLLOVER LOGIC
    if (validation.needsRollover) {
      shouldRoll = true;
      rollReason = `Week validation indicates rollover needed: ${validation.status}`;
    } else if (!validation.hasCurrentWeek && rolloverWindow.inWindow) {
      shouldRoll = true;
      rollReason = `Missing current week during ${rolloverWindow.rolloverType} rollover window`;
    } else if (validation.status === 'BEHIND') {
      shouldRoll = true;
      rollReason = 'Schedule is behind current CET week';
    } else if (validation.status === 'PARTIAL' && rolloverWindow.inWindow) {
      shouldRoll = true;
      rollReason = 'Partial week data during rollover window - completing rollover';
    }
    
    if (shouldRoll) {
      Logger.log(`RollerSystem: Auto-roll triggered - ${rollReason}`);
      
      // Perform rollover with validation
      const rollSuccess = rollOneWeekForward(true);
      
      if (rollSuccess) {
        Logger.log('RollerSystem: Auto-roll completed successfully');
        
        // Log rollover event for audit trail
        logRolloverEvent('auto', rollReason, validation);
        
      } else {
        Logger.log('RollerSystem: Auto-roll failed');
        
        // Schedule retry for failover window
        if (rolloverWindow.rolloverType === 'primary') {
          Logger.log('RollerSystem: Primary auto-roll failed, failover will retry');
        }
      }
    } else {
      Logger.log(`RollerSystem: No rollover needed - ${validation.status} status is acceptable`);
    }
    
  } catch (e) {
    Logger.log(`RollerSystem: Error in enhanced auto-roll check: ${e.message}`);
    
    // For critical errors during rollover window, attempt emergency rollover
    const rolloverWindow = isRolloverWindowCET(30);
    if (rolloverWindow.inWindow) {
      Logger.log('RollerSystem: Attempting emergency rollover due to error during rollover window');
      try {
        performActualRollover(SpreadsheetApp.getActiveSpreadsheet().getActiveSheet());
      } catch (emergencyError) {
        Logger.log(`RollerSystem: Emergency rollover also failed: ${emergencyError.message}`);
      }
    }
  }
}

/**
 * Logs rollover events for audit trail
 * @param {string} rollType - 'manual' or 'auto'
 * @param {string} reason - Reason for rollover
 * @param {Object} validation - Week validation results
 */
function logRolloverEvent(rollType, reason, validation) {
  try {
    const timestamp = getCurrentCETTime().toISOString();
    const logEntry = {
      timestamp: timestamp,
      type: rollType,
      reason: reason,
      weekStatus: validation.status,
      currentWeekCET: validation.currentWeekCET,
      user: Session.getActiveUser().getEmail()
    };
    
    Logger.log(`ROLLOVER EVENT: ${JSON.stringify(logEntry)}`);
    
    // Store in document properties for history (keep last 10)
    try {
      const props = PropertiesService.getDocumentProperties();
      const historyJson = props.getProperty('rolloverHistory');
      let history = historyJson ? JSON.parse(historyJson) : [];
      
      history.unshift(logEntry);
      if (history.length > 10) {
        history = history.slice(0, 10);
      }
      
      props.setProperty('rolloverHistory', JSON.stringify(history));
    } catch (e) {
      Logger.log(`RollerSystem: Could not store rollover history: ${e.message}`);
    }
    
  } catch (e) {
    Logger.log(`RollerSystem: Error logging rollover event: ${e.message}`);
  }
}

// ========== ENHANCED TRIGGER SYSTEM ==========

/**
 * Sets up CET-aware time-based triggers for multi-layer rollover
 */
function setupAutoRollTrigger() {
  // Check if auto-roll is enabled
  if (!getAutoRoll()) {
    Logger.log('RollerSystem: Auto-roll disabled, not setting up triggers');
    return;
  }
  
  Logger.log('RollerSystem: Setting up enhanced CET-aware auto-roll triggers');
  
  // Remove any existing triggers
  removeAutoRollTrigger();
  
  try {
    // PRIMARY TRIGGER: Monday 00:01 CET (daily check, will only act on Mondays)
    ScriptApp.newTrigger('checkAndAutoRoll')
      .timeBased()
      .everyDays(1)
      .atHour(0)
      .create();
    
    // FAILOVER TRIGGER: Monday 06:00 CET (daily check, will only act on Mondays)
    ScriptApp.newTrigger('checkAndAutoRollFailover')
      .timeBased()
      .everyDays(1)
      .atHour(6)
      .create();
    
    Logger.log('RollerSystem: Enhanced auto-roll triggers set up (primary + failover)');
    
  } catch (e) {
    Logger.log(`RollerSystem: Error setting up enhanced triggers: ${e.message}`);
    
    // Fallback to simple trigger
    try {
      ScriptApp.newTrigger('checkAndAutoRoll')
        .timeBased()
        .everyDays(1)
        .atHour(0)
        .create();
      
      Logger.log('RollerSystem: Fallback trigger set up');
    } catch (fallbackError) {
      Logger.log(`RollerSystem: Even fallback trigger failed: ${fallbackError.message}`);
    }
  }
}

/**
 * Failover auto-roll check (runs 6 hours after primary)
 */
function checkAndAutoRollFailover() {
  if (!getAutoRoll()) {
    Logger.log('RollerSystem: Auto-roll disabled, skipping failover check');
    return;
  }
  
  Logger.log('RollerSystem: Running FAILOVER auto-roll check');
  
  try {
    // Check if we're in failover rollover window
    const rolloverWindow = isRolloverWindowCET(30);
    
    if (rolloverWindow.inWindow && rolloverWindow.rolloverType === 'failover') {
      Logger.log('RollerSystem: In failover rollover window, checking if rollover is needed');
      checkAndAutoRoll(); // Use the same logic but with failover context
    } else {
      Logger.log('RollerSystem: Not in failover window, skipping failover check');
    }
    
  } catch (e) {
    Logger.log(`RollerSystem: Error in failover auto-roll: ${e.message}`);
  }
}

/**
 * Enhanced auto-roll status with CET information
 */
function debugAutoRollStatus() {
  const ui = SpreadsheetApp.getUi();
  
  try {
    const enabled = getAutoRoll();
    const triggers = ScriptApp.getProjectTriggers();
    const autoRollTriggers = triggers.filter(t => 
      t.getHandlerFunction() === 'checkAndAutoRoll' || 
      t.getHandlerFunction() === 'checkAndAutoRollFailover'
    );
    
    // Get CET information
    const cetNow = getCurrentCETTime();
    const currentWeekCET = getCurrentWeekNumberCET();
    const rolloverWindow = isRolloverWindowCET();
    
    // Get week validation
    let weekValidation = null;
    try {
      const blocks = findAllBlocks();
      if (blocks.length > 0) {
        const weekObjects = blocks.map(block => ({ weekNumber: block.weekNumber }));
        weekValidation = validateWeekAlignment(weekObjects);
      }
    } catch (e) {
      // Ignore validation errors for status display
    }
    
    let message = `🔄 ENHANCED AUTO-ROLL STATUS:\n\n`;
    message += `Enabled: ${enabled}\n`;
    message += `Active triggers: ${autoRollTriggers.length}\n`;
    message += `CET Time: ${cetNow.toLocaleString()}\n`;
    message += `CET Week: ${currentWeekCET}\n\n`;
    
    if (rolloverWindow.inWindow) {
      message += `⚠️ IN ROLLOVER WINDOW: ${rolloverWindow.rolloverType.toUpperCase()}\n`;
      message += `Minutes from rollover: ${rolloverWindow.minutesFromRollover}\n\n`;
    } else {
      message += `✅ Outside rollover window\n\n`;
    }
    
    if (weekValidation) {
      message += `📅 WEEK STATUS: ${weekValidation.status}\n`;
      message += `Current week present: ${weekValidation.hasCurrentWeek}\n`;
      message += `Next week present: ${weekValidation.hasNextWeek}\n`;
      message += `Needs rollover: ${weekValidation.needsRollover}\n\n`;
    }
    
    if (autoRollTriggers.length > 0) {
      message += `🕐 TRIGGER DETAILS:\n`;
      autoRollTriggers.forEach((trigger, index) => {
        const funcName = trigger.getHandlerFunction();
        const type = funcName.includes('Failover') ? 'FAILOVER' : 'PRIMARY';
        message += `${index + 1}. ${type}: Daily check\n`;
      });
    } else if (enabled) {
      message += `⚠️ WARNING: Auto-roll enabled but no triggers found!`;
    }
    
    ui.alert("🔄 Enhanced Auto-Roll Status", message, ui.ButtonSet.OK);
    
  } catch (e) {
    ui.alert("Error debugging enhanced auto-roll: " + e.message);
  }
}

// ========== PRESERVED ORIGINAL FUNCTIONS ==========
// These functions are preserved from the original RollerSystem for backward compatibility

/**
 * Group blocks by team index (preserved)
 */
function groupBlocksByTeam(blocks) {
  const teamBlocks = {};
  
  for (const block of blocks) {
    const teamIndex = getTeamIndexFromBlock(block);
    
    if (!teamBlocks[teamIndex]) {
      teamBlocks[teamIndex] = [];
    }
    
    teamBlocks[teamIndex].push(block);
  }
  
  return teamBlocks;
}

/**
 * Determines the team index for a block (preserved)
 */
function getTeamIndexFromBlock(block) {
  const blockRow = block.row;
  const teamSpacing = BLOCK_CONFIG.TEAM_SPACING;
  const firstTeamRow = BLOCK_CONFIG.TEAM_ROW_START;
  
  return Math.floor((blockRow - firstTeamRow) / teamSpacing);
}

/**
 * Saves a block's content (preserved)
 */
function saveBlockContent(sheet, block) {
  try {
    const content = {
      headers: {
        month: sheet.getRange(block.row, block.col - 1).getValue(),
        week: sheet.getRange(block.row, block.col).getValue(),
        days: []
      },
      timeSlots: [],
      grid: []
    };
    
    // Save day headers
    for (let d = 0; d < 7; d++) {
      content.headers.days.push(
        sheet.getRange(block.row + 1, block.col + d).getValue()
      );
    }
    
    // Save time slots and grid content
    for (let t = 0; t < block.gridHeight; t++) {
      const timeRow = block.timeStartRow + t;
      content.timeSlots.push(
        sheet.getRange(timeRow, block.timeCol).getValue()
      );
      
      const gridRow = [];
      for (let d = 0; d < 7; d++) {
        gridRow.push(sheet.getRange(timeRow, block.col + d).getValue());
      }
      content.grid.push(gridRow);
    }
    
    return content;
  } catch (e) {
    Logger.log(`RollerSystem: Error saving block content: ${e.message}`);
    return null;
  }
}

/**
 * Clears a block position (preserved)
 */
function clearBlockPosition(sheet, position, gridHeight) {
  try {
    sheet.getRange(position.row, position.col - 1, 1, 2).clearContent();
    sheet.getRange(position.row + 1, position.col, 1, 7).clearContent();
    sheet.getRange(position.row + 2, position.col, gridHeight, 7).clearContent();
  } catch (e) {
    Logger.log(`RollerSystem: Error clearing block position: ${e.message}`);
  }
}

/**
 * Restores a block's content (preserved)
 */
function restoreBlockContent(sheet, position, content) {
  try {
    sheet.getRange(position.row, position.col - 1).setValue(content.headers.month);
    sheet.getRange(position.row, position.col).setValue(content.headers.week);
    
    for (let d = 0; d < 7; d++) {
      sheet.getRange(position.row + 1, position.col + d)
           .setValue(content.headers.days[d])
           .setBackground(BLOCK_CONFIG.COLORS.DAY_HEADER);
    }
    
    for (let t = 0; t < content.timeSlots.length; t++) {
      sheet.getRange(position.row + 2 + t, position.timeCol)
           .setValue(content.timeSlots[t])
           .setBackground(BLOCK_CONFIG.COLORS.TIME_COLUMN);
      
      for (let d = 0; d < 7; d++) {
        sheet.getRange(position.row + 2 + t, position.col + d)
             .setValue(content.grid[t][d]);
      }
    }
  } catch (e) {
    Logger.log(`RollerSystem: Error restoring block content: ${e.message}`);
  }
}

/**
 * Calculates the next Monday based on a day header (enhanced with CET fallback)
 */
function calculateNextMonday(dayHeader) {
  try {
    const currentDate = parseDayDate(dayHeader);
    
    if (!currentDate) {
      // Enhanced fallback using CET
      const currentWeekCET = getCurrentWeekNumberCET();
      return calculateMondayFromWeekNumberCET(currentWeekCET + 1);
    }
    
    const nextWeekDay = new Date(currentDate);
    nextWeekDay.setDate(currentDate.getDate() + 7);
    
    return nextWeekDay;
  } catch (e) {
    Logger.log(`RollerSystem: Error calculating next Monday: ${e.message}`);
    const currentWeekCET = getCurrentWeekNumberCET();
    return calculateMondayFromWeekNumberCET(currentWeekCET + 1);
  }
}

// ========== AUTO-ROLL SETTINGS (PRESERVED) ==========

/**
 * Sets the auto-roll setting (preserved)
 */
function setAutoRoll(enabled) {
  const userProps = PropertiesService.getUserProperties();
  userProps.setProperty('autoRoll', enabled ? 'true' : 'false');
  Logger.log(`RollerSystem: Auto-roll set to ${enabled}`);
  
  // Update triggers when setting changes
  if (enabled) {
    setupAutoRollTrigger();
  } else {
    removeAutoRollTrigger();
  }
}

/**
 * Gets the current auto-roll setting (preserved)
 */
function getAutoRoll() {
  const userProps = PropertiesService.getUserProperties();
  const setting = userProps.getProperty('autoRoll');
  return setting === 'true';
}

/**
 * Removes auto-roll trigger (enhanced)
 */
function removeAutoRollTrigger() {
  const triggers = ScriptApp.getProjectTriggers();
  
  for (const trigger of triggers) {
    if (trigger.getHandlerFunction() === 'checkAndAutoRoll' || 
        trigger.getHandlerFunction() === 'checkAndAutoRollFailover') {
      ScriptApp.deleteTrigger(trigger);
    }
  }
  
  Logger.log('RollerSystem: All auto-roll triggers removed');
}

// ========== TESTING FUNCTIONS ==========

/**
 * Enhanced test for auto-roll logic with CET validation
 */
function testAutoRollLogic() {
  const ui = SpreadsheetApp.getUi();
  
  try {
    const blocks = findAllBlocks();
    const currentWeekCET = getCurrentWeekNumberCET();
    const cetNow = getCurrentCETTime();
    const rolloverWindow = isRolloverWindowCET();
    
    let weekValidation = null;
    if (blocks.length > 0) {
      const weekObjects = blocks.map(block => ({ weekNumber: block.weekNumber }));
      weekValidation = validateWeekAlignment(weekObjects);
    }
    
    let message = `🧪 ENHANCED AUTO-ROLL LOGIC TEST:\n\n`;
    message += `CET Time: ${cetNow.toLocaleString()}\n`;
    message += `CET Week: ${currentWeekCET}\n`;
    message += `Auto-roll enabled: ${getAutoRoll()}\n\n`;
    
    if (weekValidation) {
      message += `📅 WEEK VALIDATION:\n`;
      message += `Status: ${weekValidation.status}\n`;
      message += `Local weeks: [${blocks.map(b => b.weekNumber).join(', ')}]\n`;
      message += `Has current week: ${weekValidation.hasCurrentWeek}\n`;
      message += `Has next week: ${weekValidation.hasNextWeek}\n`;
      message += `Needs rollover: ${weekValidation.needsRollover}\n\n`;
      
      if (weekValidation.errors.length > 0) {
        message += `❌ ERRORS:\n${weekValidation.errors.join('\n')}\n\n`;
      }
      
      if (weekValidation.warnings.length > 0) {
        message += `⚠️ WARNINGS:\n${weekValidation.warnings.join('\n')}\n\n`;
      }
    }
    
    if (rolloverWindow.inWindow) {
      message += `🕐 ROLLOVER WINDOW: ${rolloverWindow.rolloverType.toUpperCase()}\n`;
      message += `Minutes from rollover: ${rolloverWindow.minutesFromRollover}\n\n`;
    }
    
    // Determine if auto-roll would trigger
    let wouldAutoRoll = false;
    let rollReason = '';
    
    if (weekValidation && weekValidation.needsRollover) {
      wouldAutoRoll = true;
      rollReason = `Week validation indicates rollover needed: ${weekValidation.status}`;
    } else if (weekValidation && !weekValidation.hasCurrentWeek && rolloverWindow.inWindow) {
      wouldAutoRoll = true;
      rollReason = `Missing current week during ${rolloverWindow.rolloverType} rollover window`;
    }
    
    message += `🤖 AUTO-ROLL DECISION:\n`;
    message += `Would auto-roll: ${wouldAutoRoll}\n`;
    if (wouldAutoRoll) {
      message += `Reason: ${rollReason}`;
    } else {
      message += `Reason: Current week alignment is acceptable`;
    }
    
    ui.alert("🧪 Enhanced Auto-Roll Test", message, ui.ButtonSet.OK);
    
  } catch (e) {
    ui.alert("Error testing enhanced auto-roll logic: " + e.message);
  }
}