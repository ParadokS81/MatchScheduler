/**
 * Schedule Manager - Hub Manager System
 * 
 * @version 1.0
 * 
 * Description: Handles communication between team sheets and central hub
 */

// Constants for Central Hub
const HUB = {
  SPREADSHEET_ID: "YOUR_CENTRAL_HUB_SPREADSHEET_ID_HERE", // Replace with actual ID
  MASTERLIST_SHEET: "Masterlist",
  DATA_SHEET: "TeamData",
  
  // Column indices for Masterlist (0-based)
  COLUMNS: {
    TEAM_NAME: 0,        // Column A
    SHEET_URL: 1,        // Column B
    SHEET_ID: 2,         // Column C
    DIVISION: 3,         // Column D
    LAST_UPDATED: 4,     // Column E
    PLAYER_LIST: 5,      // Column F
    SHARING_STATUS: 6,   // Column G
    WEEKS_AVAILABLE: 7   // Column H
  },
  
  // Default weeks to pull/push
  DEFAULT_WEEKS_TO_SHARE: 2
};

/**
 * Registers the current team sheet with the central hub
 * @param {string} teamName - The name of the team
 * @param {string} division - The division the team belongs to
 * @return {boolean} - Success indicator
 */
function registerWithHub(teamName, division) {
  Logger.log(`HubManager: Registering team "${teamName}" (${division}) with hub`);
  
  try {
    // Get current sheet details
    const currentSheet = SpreadsheetApp.getActiveSpreadsheet();
    const sheetId = currentSheet.getId();
    const sheetUrl = currentSheet.getUrl();
    
    // Get player list from row 3
    const sheet = currentSheet.getActiveSheet();
    const playerRange = sheet.getRange("B3:G3");
    const playerValues = playerRange.getValues()[0];
    const playerList = playerValues.filter(p => p && String(p).trim()).join(", ");
    
    // Open the hub spreadsheet
    const hubSheet = SpreadsheetApp.openById(HUB.SPREADSHEET_ID);
    const masterlist = hubSheet.getSheetByName(HUB.MASTERLIST_SHEET);
    
    if (!masterlist) {
      Logger.log("HubManager: ERROR - Masterlist sheet not found in hub");
      return false;
    }
    
    // Check if team already exists
    const teamData = masterlist.getDataRange().getValues();
    let teamRow = -1;
    
    for (let i = 1; i < teamData.length; i++) { // Skip header row
      if (teamData[i][HUB.COLUMNS.SHEET_ID] === sheetId) {
        teamRow = i + 1; // 1-based row index
        break;
      }
    }
    
    // Get current date/time
    const timestamp = new Date().toLocaleString();
    
    if (teamRow > 0) {
      // Update existing team
      Logger.log(`HubManager: Updating team in row ${teamRow}`);
      
      masterlist.getRange(teamRow, HUB.COLUMNS.TEAM_NAME + 1).setValue(teamName);
      masterlist.getRange(teamRow, HUB.COLUMNS.DIVISION + 1).setValue(division);
      masterlist.getRange(teamRow, HUB.COLUMNS.PLAYER_LIST + 1).setValue(playerList);
      masterlist.getRange(teamRow, HUB.COLUMNS.LAST_UPDATED + 1).setValue(timestamp);
      masterlist.getRange(teamRow, HUB.COLUMNS.SHARING_STATUS + 1).setValue("Active");
    } else {
      // Add new team
      Logger.log("HubManager: Adding new team to masterlist");
      
      const newRow = [
        teamName,
        sheetUrl,
        sheetId,
        division,
        timestamp,
        playerList,
        "Active",
        ""  // No weeks available yet
      ];
      
      masterlist.appendRow(newRow);
    }
    
    Logger.log("HubManager: Team registration successful");
    return true;
    
  } catch (e) {
    Logger.log(`HubManager: ERROR during registration - ${e.message}`);
    console.error(e);
    return false;
  }
}

/**
 * Collects available teams from the central hub
 * @return {Object[]} - Array of team information objects
 */
function getAvailableTeams() {
  Logger.log("HubManager: Fetching available teams from hub");
  
  try {
    // Open the hub spreadsheet
    const hubSheet = SpreadsheetApp.openById(HUB.SPREADSHEET_ID);
    const masterlist = hubSheet.getSheetByName(HUB.MASTERLIST_SHEET);
    
    if (!masterlist) {
      Logger.log("HubManager: ERROR - Masterlist sheet not found in hub");
      return [];
    }
    
    // Get all team data
    const teamData = masterlist.getDataRange().getValues();
    
    if (teamData.length <= 1) {
      // Only header row exists
      Logger.log("HubManager: No teams found in masterlist");
      return [];
    }
    
    // Get current sheet ID to exclude self
    const currentSheetId = SpreadsheetApp.getActiveSpreadsheet().getId();
    
    // Process team data (skip header row)
    const teams = [];
    for (let i = 1; i < teamData.length; i++) {
      const row = teamData[i];
      
      const teamId = row[HUB.COLUMNS.SHEET_ID];
      
      // Skip self and inactive teams
      if (teamId === currentSheetId || row[HUB.COLUMNS.SHARING_STATUS] !== "Active") {
        continue;
      }
      
      teams.push({
        name: row[HUB.COLUMNS.TEAM_NAME],
        sheetId: teamId,
        url: row[HUB.COLUMNS.SHEET_URL],
        division: row[HUB.COLUMNS.DIVISION],
        players: row[HUB.COLUMNS.PLAYER_LIST],
        lastUpdated: row[HUB.COLUMNS.LAST_UPDATED],
        weeksAvailable: row[HUB.COLUMNS.WEEKS_AVAILABLE]
      });
    }
    
    Logger.log(`HubManager: Found ${teams.length} available teams`);
    return teams;
    
  } catch (e) {
    Logger.log(`HubManager: ERROR fetching teams - ${e.message}`);
    console.error(e);
    return [];
  }
}

/**
 * Debug function to view current hub status
 */
function debugHubConnectivity() {
  try {
    const hubSheet = SpreadsheetApp.openById(HUB.SPREADSHEET_ID);
    Logger.log(`Successfully connected to hub: "${hubSheet.getName()}"`);
    
    const masterlist = hubSheet.getSheetByName(HUB.MASTERLIST_SHEET);
    if (masterlist) {
      const rows = masterlist.getLastRow();
      Logger.log(`Masterlist has ${rows} rows (including header)`);
    } else {
      Logger.log("Masterlist sheet not found");
    }
    
    const dataSheet = hubSheet.getSheetByName(HUB.DATA_SHEET);
    if (dataSheet) {
      Logger.log(`Data sheet exists with ${dataSheet.getLastRow()} rows`);
    } else {
      Logger.log("Data sheet not found");
    }
    
    return "Hub connectivity check complete - see logs for details";
  } catch (e) {
    Logger.log(`Hub connectivity test failed: ${e.message}`);
    return `ERROR: ${e.message}`;
  }
}