/**
 * Schedule Manager - Data Transfer (Central Hub)
 * 
 * @version 1.1.0 (2025-05-18 16:00)
 * 
 * Description: Handles data processing and exchange on the central hub
 * Change log: Added updateTeamWeeks function to centralize masterlist updates
 */

/**
 * Processes incoming data from a team sheet
 * @param {String} sheetId - ID of the sending sheet
 * @param {Object} data - The data package from the team
 * @return {Boolean} Success indicator
 */
function processTeamData(sheetId, data) {
  Logger.log(`DataTransfer: Processing data from sheet ${sheetId}`);
  
  try {
    // Get the data sheet
    const dataSheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(HUB.DATA_SHEET);
    
    if (!dataSheet) {
      Logger.log("DataTransfer: ERROR - Data sheet not found");
      return false;
    }
    
    // Find if team already has data stored
    const dataValues = dataSheet.getDataRange().getValues();
    let rowIndex = -1;
    
    for (let i = 1; i < dataValues.length; i++) { // Skip header row
      if (dataValues[i][0] === sheetId) {
        rowIndex = i + 1; // 1-based row index
        break;
      }
    }
    
    // Preserve division if not provided in data
    if (!data.division) {
      const teamInfo = getTeamById(sheetId);
      if (teamInfo) {
        data.division = teamInfo.division || "Other";
      }
    }
    
    // Serialize the data to JSON
    const dataJson = JSON.stringify(data);
    
    if (rowIndex > 0) {
      // Update existing row
      dataSheet.getRange(rowIndex, 2).setValue(dataJson);
      Logger.log(`DataTransfer: Updated data for team in row ${rowIndex}`);
    } else {
      // Add new row
      dataSheet.appendRow([sheetId, dataJson]);
      Logger.log(`DataTransfer: Added new data row for team`);
    }
    
    // Get available week numbers
    const weekNumbers = data.weeks.map(w => w.weekNumber).join(", ");
    
    // Update masterlist with weeks info (centralized here)
    return updateTeamWeeks(sheetId, weekNumbers);
    
  } catch (e) {
    Logger.log(`DataTransfer: ERROR processing team data - ${e.message}`);
    console.error(e);
    return false;
  }
}

/**
 * Updates the masterlist with team's available weeks
 * This is the ONLY function that should update the masterlist weeks
 * @param {String} sheetId - ID of the team's sheet
 * @param {String} weekNumbers - Comma-separated list of week numbers
 * @return {Boolean} Success indicator
 */
function updateTeamWeeks(sheetId, weekNumbers) {
  try {
    const masterlist = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(HUB.MASTERLIST_SHEET);
    
    if (!masterlist) {
      Logger.log("DataTransfer: ERROR - Masterlist sheet not found");
      return false;
    }
    
    // Find team in masterlist
    const teamData = masterlist.getDataRange().getValues();
    let teamFound = false;
    
    for (let i = 1; i < teamData.length; i++) { // Skip header row
      if (teamData[i][HUB.COLUMNS.SHEET_ID] === sheetId) {
        const timestamp = new Date().toLocaleString();
        masterlist.getRange(i + 1, HUB.COLUMNS.LAST_UPDATED + 1).setValue(timestamp);
        masterlist.getRange(i + 1, HUB.COLUMNS.WEEKS_AVAILABLE + 1).setValue(weekNumbers);
        Logger.log(`DataTransfer: Updated masterlist for team with weeks ${weekNumbers}`);
        teamFound = true;
        break;
      }
    }
    
    return teamFound;
    
  } catch (e) {
    Logger.log(`DataTransfer: ERROR updating masterlist - ${e.message}`);
    console.error(e);
    return false;
  }
}

/**
 * Updates the masterlist with team's available weeks
 * @param {String} sheetId - ID of the team's sheet
 * @param {Object} data - The data package from the team
 * @deprecated Use updateTeamWeeks instead
 */
function updateMasterlist(sheetId, data) {
  Logger.log("DataTransfer: WARNING - Using deprecated updateMasterlist function");
  
  try {
    // Get available week numbers
    const weekNumbers = data.weeks.map(w => w.weekNumber).join(", ");
    
    // Call the new centralized function
    return updateTeamWeeks(sheetId, weekNumbers);
    
  } catch (e) {
    Logger.log(`DataTransfer: ERROR in deprecated updateMasterlist - ${e.message}`);
    console.error(e);
    return false;
  }
}

/**
 * Gets availability data for specific teams
 * @param {String[]} teamIds - Array of team sheet IDs
 * @return {Object[]} - Array of team data objects
 */
function getTeamsData(teamIds) {
  Logger.log(`DataTransfer: Fetching data for ${teamIds.length} teams`);
  
  try {
    const dataSheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(HUB.DATA_SHEET);
    
    if (!dataSheet) {
      Logger.log("DataTransfer: ERROR - Data sheet not found");
      return [];
    }
    
    // Get all data rows
    const dataValues = dataSheet.getDataRange().getValues();
    
    if (dataValues.length <= 1) {
      Logger.log("DataTransfer: No team data found");
      return [];
    }
    
    // Collect data for requested teams
    const teamsData = [];
    
    for (let i = 1; i < dataValues.length; i++) { // Skip header row
      const sheetId = dataValues[i][0];
      
      if (teamIds.includes(sheetId)) {
        try {
          const jsonData = dataValues[i][1];
          const parsedData = JSON.parse(jsonData);
          
          // Ensure division is included
          if (!parsedData.division) {
            const teamInfo = getTeamById(sheetId);
            if (teamInfo) {
              parsedData.division = teamInfo.division || "Other";
            } else {
              parsedData.division = "Other";
            }
          }
          
          teamsData.push(parsedData);
          Logger.log(`DataTransfer: Retrieved data for team ID ${sheetId}`);
        } catch (e) {
          Logger.log(`DataTransfer: ERROR parsing data for team ID ${sheetId} - ${e.message}`);
        }
      }
    }
    
    return teamsData;
    
  } catch (e) {
    Logger.log(`DataTransfer: ERROR fetching teams data - ${e.message}`);
    console.error(e);
    return [];
  }
}

/**
 * Gets team information by sheet ID
 * @param {String} sheetId - The team's sheet ID
 * @return {Object|null} - Team information or null if not found
 */
function getTeamById(sheetId) {
  try {
    const masterlist = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(HUB.MASTERLIST_SHEET);
    
    if (!masterlist) {
      Logger.log("DataTransfer: ERROR - Masterlist sheet not found");
      return null;
    }
    
    // Find team in masterlist
    const teamData = masterlist.getDataRange().getValues();
    
    for (let i = 1; i < teamData.length; i++) { // Skip header row
      if (teamData[i][HUB.COLUMNS.SHEET_ID] === sheetId) {
        return {
          name: teamData[i][HUB.COLUMNS.TEAM_NAME],
          sheetId: sheetId,
          url: teamData[i][HUB.COLUMNS.SHEET_URL],
          division: teamData[i][HUB.COLUMNS.DIVISION],
          players: teamData[i][HUB.COLUMNS.PLAYER_LIST],
          lastUpdated: teamData[i][HUB.COLUMNS.LAST_UPDATED],
          weeksAvailable: teamData[i][HUB.COLUMNS.WEEKS_AVAILABLE],
          status: teamData[i][HUB.COLUMNS.SHARING_STATUS]
        };
      }
    }
    
    return null;
    
  } catch (e) {
    Logger.log(`DataTransfer: ERROR finding team - ${e.message}`);
    console.error(e);
    return null;
  }
}

/**
 * Gets teams that have specific week(s) available
 * @param {Number[]} weekNumbers - Array of week numbers to look for
 * @return {Object[]} - Array of team information objects
 */
function getTeamsWithWeeks(weekNumbers) {
  Logger.log(`DataTransfer: Finding teams with weeks ${weekNumbers.join(', ')}`);
  
  try {
    const masterlist = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(HUB.MASTERLIST_SHEET);
    
    if (!masterlist) {
      Logger.log("DataTransfer: ERROR - Masterlist sheet not found");
      return [];
    }
    
    // Get all team data
    const teamData = masterlist.getDataRange().getValues();
    
    if (teamData.length <= 1) {
      Logger.log("DataTransfer: No teams found in masterlist");
      return [];
    }
    
    // Process team data (skip header row)
    const matchingTeams = [];
    
    for (let i = 1; i < teamData.length; i++) {
      const weeksAvailable = String(teamData[i][HUB.COLUMNS.WEEKS_AVAILABLE] || "");
      const status = teamData[i][HUB.COLUMNS.SHARING_STATUS];
      
      // Skip if not active
      if (status !== "Active") continue;
      
      // Check if any requested week is available
      const hasMatchingWeek = weekNumbers.some(weekNum => 
        weeksAvailable.includes(String(weekNum))
      );
      
      if (hasMatchingWeek) {
        matchingTeams.push({
          name: teamData[i][HUB.COLUMNS.TEAM_NAME],
          sheetId: teamData[i][HUB.COLUMNS.SHEET_ID],
          url: teamData[i][HUB.COLUMNS.SHEET_URL],
          division: teamData[i][HUB.COLUMNS.DIVISION],
          players: teamData[i][HUB.COLUMNS.PLAYER_LIST],
          lastUpdated: teamData[i][HUB.COLUMNS.LAST_UPDATED],
          weeksAvailable: weeksAvailable
        });
      }
    }
    
    Logger.log(`DataTransfer: Found ${matchingTeams.length} teams with matching weeks`);
    return matchingTeams;
    
  } catch (e) {
    Logger.log(`DataTransfer: ERROR finding teams with weeks - ${e.message}`);
    console.error(e);
    return [];
  }
}