/**
 * PATCH: Schedule Manager - Hub Integration Fix
 * 
 * @version 1.1.1 (2025-05-20)
 * 
 * This patch fixes the duplication issue where both team sheets and hub
 * were updating the masterlist metadata.
 */

// ============================================================================
// TEAM SHEET SIDE CHANGES (HubConnector.gs)
// ============================================================================

/**
 * UPDATED: Pushes current team's availability data to the central hub
 * CHANGE: Removed masterlist update logic - hub handles this now
 * @return {boolean} Success indicator
 */
function pushAvailabilityToHub() {
  const ui = SpreadsheetApp.getUi();
  Logger.log("HubConnector: Pushing availability data to hub");
  
  // Get team info
  const teamInfo = getTeamInfo();
  
  if (!teamInfo.isValid) {
    showValidationError();
    return false;
  }
  
  try {
    const ss = SpreadsheetApp.getActiveSpreadsheet();
    const sheet = ss.getActiveSheet();
    
    // Find all blocks - Use position-based detection
    const blocks = findAllBlocks();
    
    if (blocks.length === 0) {
      ui.alert("No week blocks found. Please check your schedule format.");
      Logger.log("HubConnector: No week blocks found, aborting push");
      return false;
    }
    
    // Prepare weeks data
    const weeks = [];
    for (const block of blocks) {
      const weekData = collectWeekData(sheet, block);
      if (weekData) {
        weeks.push(weekData);
      }
    }
    
    if (weeks.length === 0) {
      ui.alert("No valid week data found. Please check your schedule format.");
      Logger.log("HubConnector: No valid week data collected, aborting push");
      return false;
    }
    
    // Get week numbers for display
    const weekNumbers = weeks.map(w => w.weekNumber).join(", ");
    
    // Create final data package
    const availabilityData = {
      teamName: teamInfo.name,
      sheetId: ss.getId(),
      timestamp: new Date().toISOString(),
      players: teamInfo.players.map(p => p.name),
      weeks: weeks
    };
    
    // Push to central hub
    const hubSheet = SpreadsheetApp.openById(BLOCK_CONFIG.HUB.SPREADSHEET_ID);
    
    // Check and create the TeamData sheet if it doesn't exist
    let dataSheet = hubSheet.getSheetByName(BLOCK_CONFIG.HUB.DATA_SHEET);
    if (!dataSheet) {
      Logger.log("HubConnector: Data sheet not found in hub, creating it now");
      dataSheet = hubSheet.insertSheet(BLOCK_CONFIG.HUB.DATA_SHEET);
      
      // Set up the data sheet with headers
      dataSheet.getRange("A1:B1").setValues([["Sheet ID", "Data JSON"]]);
      dataSheet.getRange("A1:B1").setFontWeight("bold").setBackground("#f2f2f2");
      dataSheet.setColumnWidth(1, 300);  // Sheet ID column
      dataSheet.setColumnWidth(2, 500);  // JSON Data column
    }
    
    // Store as JSON in the data sheet
    const dataJson = JSON.stringify(availabilityData);
    
    // Find existing row or add new one
    const sheetId = ss.getId();
    let dataRows;
    try {
      if (dataSheet.getLastRow() > 1) {
        dataRows = dataSheet.getRange("A2:B" + dataSheet.getLastRow()).getValues();
      } else {
        dataRows = [];
      }
    } catch (e) {
      Logger.log("Error reading data rows: " + e.message);
      dataRows = [];
    }
    
    let rowIndex = -1;
    
    for (let i = 0; i < dataRows.length; i++) {
      if (dataRows[i][0] === sheetId) {
        rowIndex = i + 2; // +2 for 1-based index and header row
        break;
      }
    }
    
    if (rowIndex > 0) {
      // Update existing row
      dataSheet.getRange(rowIndex, 2).setValue(dataJson);
      Logger.log(`HubConnector: Updated data for team ${teamInfo.name}`);
    } else {
      // Add new row
      dataSheet.appendRow([sheetId, dataJson]);
      Logger.log(`HubConnector: Added new data for team ${teamInfo.name}`);
    }
    
    // REMOVED: Masterlist update logic - hub handles this now via trigger
    
    // UPDATED: Just verify team is registered, don't update masterlist
    const masterlist = hubSheet.getSheetByName(BLOCK_CONFIG.HUB.MASTERLIST_SHEET);
    if (masterlist) {
      const masterData = masterlist.getRange("A2:C" + masterlist.getLastRow()).getValues();
      let teamExists = false;
      
      for (let i = 0; i < masterData.length; i++) {
        if (masterData[i][2] === sheetId) {
          teamExists = true;
          break;
        }
      }
      
      if (!teamExists) {
        ui.alert("Your team was not found in the hub masterlist. Please register first.");
        return false;
      }
    }
    
    Logger.log(`HubConnector: Push completed successfully for weeks ${weekNumbers}`);
    ui.alert(`Success! Your team's availability for Week(s) ${weekNumbers} has been shared.`);
    return true;
    
  } catch (e) {
    Logger.log(`HubConnector: ERROR during push - ${e.message}`);
    console.error(e);
    ui.alert("Error sharing availability: " + e.message);
    return false;
  }
}

// ============================================================================
// HUB SIDE CHANGES 
// ============================================================================

/**
 * NEW: Trigger function to update masterlist when data changes
 * This should be set as an onChange trigger on the TeamData sheet
 */
function onTeamDataChange(e) {
  Logger.log("Hub: TeamData sheet changed, updating masterlist");
  updateAllTeamMasterlistEntries();
}

/**
 * NEW: Updates masterlist entries for all teams with current data
 */
function updateAllTeamMasterlistEntries() {
  try {
    const ss = SpreadsheetApp.getActiveSpreadsheet();
    const dataSheet = ss.getSheetByName(HUB.DATA_SHEET);
    const masterlist = ss.getSheetByName(HUB.MASTERLIST_SHEET);
    
    if (!dataSheet || !masterlist) {
      Logger.log("Hub: Missing required sheets for masterlist update");
      return;
    }
    
    // Get all data entries
    if (dataSheet.getLastRow() <= 1) {
      Logger.log("Hub: No team data to process");
      return;
    }
    
    const dataValues = dataSheet.getRange("A2:B" + dataSheet.getLastRow()).getValues();
    
    // Process each team's data
    for (let i = 0; i < dataValues.length; i++) {
      const sheetId = dataValues[i][0];
      const jsonData = dataValues[i][1];
      
      try {
        const teamData = JSON.parse(jsonData);
        updateSingleTeamMasterlistEntry(sheetId, teamData);
      } catch (e) {
        Logger.log(`Hub: Error parsing data for team ${sheetId}: ${e.message}`);
      }
    }
    
    Logger.log("Hub: Masterlist update completed");
    
  } catch (e) {
    Logger.log(`Hub: Error updating masterlist entries: ${e.message}`);
  }
}

/**
 * NEW: Updates masterlist entry for a single team
 * @param {string} sheetId - Team's sheet ID
 * @param {Object} teamData - Parsed team data
 */
function updateSingleTeamMasterlistEntry(sheetId, teamData) {
  try {
    const masterlist = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(HUB.MASTERLIST_SHEET);
    
    if (!masterlist) {
      Logger.log("Hub: Masterlist sheet not found");
      return;
    }
    
    // Find team in masterlist
    const teamRows = masterlist.getDataRange().getValues();
    
    for (let i = 1; i < teamRows.length; i++) { // Skip header row
      if (teamRows[i][HUB.COLUMNS.SHEET_ID] === sheetId) {
        const timestamp = new Date().toLocaleString();
        const weekNumbers = teamData.weeks.map(w => w.weekNumber).join(", ");
        
        // Update timestamp and available weeks
        masterlist.getRange(i + 1, HUB.COLUMNS.LAST_UPDATED + 1).setValue(timestamp);
        masterlist.getRange(i + 1, HUB.COLUMNS.WEEKS_AVAILABLE + 1).setValue(weekNumbers);
        
        Logger.log(`Hub: Updated masterlist for team ${teamData.teamName} with weeks ${weekNumbers}`);
        break;
      }
    }
    
  } catch (e) {
    Logger.log(`Hub: Error updating masterlist for team ${sheetId}: ${e.message}`);
  }
}

/**
 * UPDATED: processTeamData now calls masterlist update
 * @param {String} sheetId - ID of the sending sheet
 * @param {Object} data - The data package from the team
 * @return {Boolean} Success indicator
 */
function processTeamData(sheetId, data) {
  Logger.log(`DataTransfer: Processing data from sheet ${sheetId}`);
  
  try {
    // Get the data sheet
    const dataSheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(HUB.DATA_SHEET);
    
    if (!dataSheet) {
      Logger.log("DataTransfer: ERROR - Data sheet not found");
      return false;
    }
    
    // Find if team already has data stored
    const dataValues = dataSheet.getDataRange().getValues();
    let rowIndex = -1;
    
    for (let i = 1; i < dataValues.length; i++) { // Skip header row
      if (dataValues[i][0] === sheetId) {
        rowIndex = i + 1; // 1-based row index
        break;
      }
    }
    
    // Serialize the data to JSON
    const dataJson = JSON.stringify(data);
    
    if (rowIndex > 0) {
      // Update existing row
      dataSheet.getRange(rowIndex, 2).setValue(dataJson);
      Logger.log(`DataTransfer: Updated data for team in row ${rowIndex}`);
    } else {
      // Add new row
      dataSheet.appendRow([sheetId, dataJson]);
      Logger.log(`DataTransfer: Added new data row for team`);
    }
    
    // UPDATED: Update masterlist with weeks info
    updateSingleTeamMasterlistEntry(sheetId, data);
    
    return true;
    
  } catch (e) {
    Logger.log(`DataTransfer: ERROR processing team data - ${e.message}`);
    console.error(e);
    return false;
  }
}

// ============================================================================
// INSTALLATION INSTRUCTIONS
// ============================================================================

/**
 * NEW: Setup function to install the trigger
 * Run this once to set up the automatic masterlist updates
 */
function setupHubTriggers() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  
  // Delete existing triggers for this spreadsheet
  const triggers = ScriptApp.getProjectTriggers();
  triggers.forEach(trigger => {
    if (trigger.getHandlerFunction() === 'onTeamDataChange') {
      ScriptApp.deleteTrigger(trigger);
    }
  });
  
  // Create new onChange trigger for TeamData sheet
  ScriptApp.newTrigger('onTeamDataChange')
    .onEdit()
    .create();
    
  Logger.log("Hub: Triggers installed successfully");
  
  return "Hub triggers installed successfully!";
}